# Role Matrix v0.1

| Capability | Admin | Accounting | Personnel | Viewer |
|---|---:|---:|---:|---:|
| Finance dashboard | Full | Full | Payroll-only | Read |
| Counterparties | CRUD | CRUD | No | Read |
| Invoices / payments | CRUD | CRUD | No | Read |
| Payables | CRUD | CRUD | No | Read |
| Cash / bank | CRUD | CRUD | No | Read |
| Personnel obligations | Full | Full | CRUD personnel fields | Read |
| User roles | Full | No | No | No |
| Audit log | Read | Read | Own scope | No |
| Archive restore | Full | Limited | No | No |
