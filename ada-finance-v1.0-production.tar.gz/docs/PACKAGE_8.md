# Paket 8 — Bütçe, Kârlılık ve 13 Haftalık Nakit Planlama

## Amaç
Yönetimin yalnız geçmişi görmesini değil, gelecek nakdi ve plan-gerçekleşen farklarını yönetmesini sağlamak.

## 1. Bütçe / Gerçekleşen
- Bütçe planı: ad, para birimi, başlangıç ve bitiş ayı, durum.
- Aylık bütçe satırı: ciro, gider, nakit giriş ve nakit çıkış hedefi.
- Gerçekleşenler mevcut fatura, tahsilat, onaylı masraf ve ödeme kayıtlarından gelir.
- Farklar aylık ve toplam hesaplanır.

## 2. Kârlılık
Sipariş kalemlerine satış birim fiyatı ve direkt birim maliyet eklenir.
- Sipariş bazında brüt kâr ve brüt marj
- Müşteri bazında brüt kâr ve brüt marj
- Ürün bazında brüt kâr ve brüt marj

Not: Bu metrik net kâr değildir. Genel yönetim, finansman, vergi ve dağıtılmamış genel giderler eklenmediği için `gross_profit` / brüt katkı olarak yorumlanmalıdır.

## 3. 13 Haftalık Nakit Akışı
Başlangıç nakdi + tahsil edilecek alacaklar - açık borçlar - açık personel yükümlülükleri.

Varsayılan tahsilat senaryoları:
- Kötü: %50
- Baz: %80
- İyi: %100

Bu oranlar API üzerinden değiştirilebilir. Borç/personel çıkışları tam ödeme kabul edilir.

## 4. Opportunity OS bağlantısı
Sipariş ve ürünlerde mevcut ortak kimlik alanları korunur:
- `orders.opportunity_order_id`
- `orders.opportunity_id`
- `products.opportunity_product_id`

## 5. API
- `GET /api/planning/cash-13-week`
- `GET /api/profitability`
- `GET|POST /api/orders`
- `POST /api/order-items`
- `GET|POST /api/products`
- `GET|POST /api/budgets`
- `POST /api/budget-lines`
- `GET /api/budgets/:id/report`

## Test
Paket 8 dahil toplam 48 otomatik test başarılıdır. HTTP smoke testinde bootstrap, login, bütçe planı, 13 haftalık nakit ve kârlılık endpointleri doğrulanmıştır.
