# Package 6 — File Archive, Extraction Adapters & Operations Metrics

## Scope
- Authenticated binary file upload (15 MB request limit)
- Private filesystem archive with SHA-256, MIME, size, uploader and audit metadata
- Receipt/invoice/bank-statement categories
- Extraction job queue
- Native text extraction
- Optional local PDF text extraction (`pdftotext` when installed)
- Optional image OCR adapter (`tesseract` when installed)
- Explicit `needs_external_ocr` state when a local engine is unavailable
- External OCR/vision text hand-off endpoint
- Bank file → extraction → bank review batch
- Receipt/invoice file → extraction → document staging
- No automatic accounting posting from OCR/extraction
- Dashboard: monthly approved expense, draft expenses, pending extraction, low-stock count

## Security/Accounting rule
Uploaded bytes are archived; extracted values are proposals. No uploaded or OCR-derived document creates a payment or payable automatically. A human review remains required.

## Production note
The local filesystem adapter is appropriate for single-node/self-hosted use. Multi-instance production should swap storage to an object store while keeping the same `file_objects` metadata/API contract.
