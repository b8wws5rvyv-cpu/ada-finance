# Package 9 — Cost Centers & Controllable Net Profitability

## Scope
- Cost center master data
- Expense-to-cost-center allocation
- Optional cost center targeting to order/customer/product
- Exact minor-unit overhead allocation
- Period allocation runs with audit history
- Order and customer net contribution reports

## Allocation bases
- `revenue`: proportional to order revenue
- `direct_cost`: proportional to order direct cost
- `equal`: equal split across eligible orders

Unassigned approved expenses are included as general overhead and distributed by revenue. If no eligible order exists, the amount remains `unallocated`.

## Accounting interpretation
The output is a management contribution report, not statutory net profit. Gross profit is sales less direct item cost. Net contribution is gross profit less allocated approved expenses.
