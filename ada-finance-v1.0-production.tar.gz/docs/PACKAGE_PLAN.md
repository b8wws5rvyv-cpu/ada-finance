# Development packaging plan

## Package 1 — Finance Core (this package)
Data model, due dates, receivables/payables, payment allocation, personnel payment bridge, cash-flow, audit/archive, role contract.

## Package 2 — Production UI
Management dashboard, receivable aging, payable calendar, 7/30/60/90 cash-flow, counterparty 360, statement PDF/Excel.

## Package 3 — Document Automation
Bank statement PDF import, expense receipt/invoice OCR-assist, review queue. No auto-post without human confirmation.

## Package 4 — Opportunity OS Integration
Shared Company/Product/Order IDs and deep links. Opportunity → Proposal → Order → Invoice → Due Date → Payment traceability.

## Package 5 — Inventory / Costing
Stock, purchasing, consumption, product cost, gross margin. Kept separate from Package 1 to avoid delaying finance acceptance criteria.
