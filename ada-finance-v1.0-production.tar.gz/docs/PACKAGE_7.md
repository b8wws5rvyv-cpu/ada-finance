# Package 7 — Management Reporting & Finance Analytics

## Added
- 1 / 3 / 6 / 12 month management report API.
- Monthly accrual revenue vs. cash collection separation.
- Approved expense reporting and cash-out reporting.
- Monthly bank/cash balance trend.
- Customer revenue / collection / open receivable / overdue performance.
- Customer concentration risk: Top-1, Top-3 and HHI.
- Expense breakdown by category and department.
- Responsive `Finans Raporları` screen.

## Accounting semantics
- **Revenue** = sales invoices by invoice date (accrual view).
- **Collections** = incoming payments by payment date (cash view).
- **Expense** = approved/paid expense records by expense date.
- **Cash out** = outgoing payments by payment date.
- Revenue and collections are intentionally not treated as the same metric.
- Expense and cash-out are intentionally not treated as the same metric.

## API
`GET /api/reports/management?months=1|3|6|12&currency=TRY&asOf=YYYY-MM-DD`

The endpoint requires `dashboard:read` permission and therefore follows the existing role model.
