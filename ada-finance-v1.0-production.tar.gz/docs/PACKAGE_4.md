# Paket 4 — Banka İçe Aktarım, Belge Staging, Stok Temeli

## Banka ekstresi
- CSV/TSV metni staging'e alınır; doğrudan muhasebeleştirilmez.
- Her satır için müşteri/fatura eşleşme önerisi üretilir.
- Kullanıcı Onayla / Düzelt / Reddet kararı verir.
- Onaylanan satır ancak o anda `payments` ve gerekirse `payment_allocations` kaydına dönüşür.
- Kaynak satır ve karar geçmişi korunur; sessiz overwrite yoktur.

## PDF ve görsel belgeler
V0.4 OCR motorunu zorunlu kılmaz. PDF/fiş/fatura dosyaları `document_staging` kaydı olarak tutulabilecek veri modeline sahiptir. OCR/vision çıktısı daha sonra `extracted_text` / `extracted_json` alanlarına yazılır ve insan onayı olmadan muhasebe kaydı yaratmaz.

## Stok
- Birim: adet / m / m2 / kg / paket / set / diğer.
- Hareket defteri giriş/çıkış/düzeltme mantığındadır.
- Stok miktarı hareketlerden hesaplanır; item üzerinde mutable stok sayısı tutulmaz.
- Opportunity OS Product ID için bağlantı alanı vardır.
