# Package 5 — Expense Automation, Document Review, Bank PDF Text Adapter, Stock/Production Link

## Principles
- OCR/vision output is proposed data, not accounting truth.
- Documents enter staging first; human approval is required before posting.
- Bank PDF text extraction feeds the same review queue as CSV imports.
- Inventory movements are immutable ledger rows and may reference purchase/production sources.
- Production issues and outputs share one production job ID.

## New flows
1. Receipt/invoice text → document staging → parser proposal → expense draft → approve/reject → payment/payable.
2. Bank PDF extracted text → parser → match suggestions → approve/edit/reject → payment allocation.
3. Purchase/expense can carry inventory source references.
4. Production job → material issue → finished goods receipt.

## Not yet included
- Vendor-specific OCR engine credentials.
- Direct binary PDF/image OCR in the Node server.
- E-invoice/e-archive provider integration.
These are deliberately adapters/backlog items; accounting posting remains human-approved.
