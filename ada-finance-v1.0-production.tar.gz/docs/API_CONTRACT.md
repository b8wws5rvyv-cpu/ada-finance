# Finance API Contract v0.1

All mutation endpoints require an authenticated user and append an audit_log record.
All delete actions are archive operations unless explicitly documented otherwise.

## Shared Identity
- `GET /api/integrations/opportunity/company/:remoteId`
- `POST /api/integrations/opportunity/link`
  - localEntityType: counterparty | product | order
  - localEntityId
  - remoteEntityType: company | product | order | opportunity
  - remoteEntityId

## Dashboard
- `GET /api/dashboard?asOf=YYYY-MM-DD`
  - bankCashByCurrency
  - receivablesTotal
  - overdueReceivablesTotal
  - payablesTotal
  - payrollDue
  - cashflow7
  - cashflow30
  - cashflow60
  - cashflow90

## Counterparties
- `GET /api/counterparties`
- `POST /api/counterparties`
- `PATCH /api/counterparties/:id`
- `POST /api/counterparties/:id/archive`
- `GET /api/counterparties/:id/statement?from=&to=`

## Invoices
- `GET /api/invoices?direction=&status=&from=&to=`
- `POST /api/invoices`
- `PATCH /api/invoices/:id`
- `POST /api/invoices/:id/archive`

## Payments
- `POST /api/payments`
- `POST /api/payments/:id/allocate`
- `GET /api/payments?from=&to=&accountId=`

## Payables
- `GET /api/payables?status=&from=&to=`
- `POST /api/payables`
- `PATCH /api/payables/:id`
- `POST /api/payables/:id/archive`

## Personnel obligations
- `POST /api/personnel-obligations/generate`
- `GET /api/personnel-obligations?period=YYYY-MM`
- `POST /api/personnel-obligations/:id/pay-bank`
- `POST /api/personnel-obligations/:id/pay-cash`

## Audit
- `GET /api/audit?entityType=&entityId=&from=&to=`

## Paket 4 API

- `GET /api/bank-imports`
- `POST /api/bank-imports` — `{accountId, sourceName, sourceType, text, currency}`
- `GET /api/bank-imports/:id`
- `POST /api/bank-import-rows/:id/decision` — `{decision: approved|edited|rejected, counterpartyId?, invoiceId?, accountId?}`
- `GET /api/documents/staging`
- `POST /api/documents/staging`
- `GET /api/inventory`
- `POST /api/inventory`
- `POST /api/inventory/movements`

Banka içe aktarım satırları `pending` olarak başlar; yalnızca approved/edited kararı ödeme ve fatura tahsis kaydı üretir.

## Package 8 Planning APIs
- `GET /api/planning/cash-13-week?asOf=YYYY-MM-DD&currency=TRY&bad=0.5&base=0.8&good=1`
- `GET /api/profitability`
- `GET /api/orders`
- `POST /api/orders`
- `POST /api/order-items`
- `GET /api/products`
- `POST /api/products`
- `GET /api/budgets`
- `POST /api/budgets`
- `POST /api/budget-lines`
- `GET /api/budgets/:id/report?asOf=YYYY-MM-DD`


## Package 9 — cost & profitability
- `GET /api/cost-centers`
- `POST /api/cost-centers`
- `POST /api/cost-centers/assign-expense`
- `POST /api/cost-centers/link`
- `GET /api/cost-centers/report?period=YYYY-MM&currency=TRY`
- `GET /api/cost-allocation-runs`
- `POST /api/cost-allocation-runs`
- `GET /api/net-profitability?period=YYYY-MM&currency=TRY`
