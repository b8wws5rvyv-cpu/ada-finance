# ADA Finance & Operations v1.0 — Production Runbook

## 1. Production topology
- One application instance behind HTTPS reverse proxy.
- Persistent `/data` volume.
- SQLite database: `/data/ada-finance.sqlite`.
- Private uploads: `/data/uploads`.
- Backups: `/data/backups`.
- Application itself is stateless apart from `/data`.

## 2. First deployment
1. Copy `.env.example` to `.env`.
2. Set PORT / backup retention / backup hour if needed.
3. `docker compose up -d --build`
4. Open `/api/health` and `/api/ready`.
5. Open the web UI and create the first admin user.
6. Before importing legacy data, take one empty baseline backup.

## 3. Legacy migration
Export the existing ADA Finance state as JSON. Do not delete or overwrite the old system before reconciliation.

`docker compose exec ada-finance node scripts/import-legacy.mjs /data/import/legacy.json`

Then reconcile counts and totals: counterparties, invoices, payments, account balances, employees and adjustments. Keep the old system read-only until reconciliation is signed off.

## 4. Backup
Automatic scheduled backup runs once daily at `ADA_AUTO_BACKUP_HOUR` (server local time). Manual backup is available in System Management or with:

`docker compose exec ada-finance npm run backup`

Backups use SQLite `VACUUM INTO`, SHA-256, history logging and retention. Default retention is 30 days.

## 5. Restore
Restore is intentionally offline. Never overwrite the active database from a browser request.

1. Stop application: `docker compose stop ada-finance`
2. Make a copy of `/data/ada-finance.sqlite`.
3. Run: `npm run restore-backup -- /data/backups/<backup>.sqlite`
4. Start application.
5. Check `/api/ready` and core financial totals.

The restore script runs SQLite integrity check first and creates a pre-restore copy when a current database exists.

## 6. User roles
- admin: full access, user/backup management.
- accounting: finance, personnel, bank import, expenses, stock/production, costing.
- personnel: personnel-only operational access.
- viewer: read-only business data.

The last active admin cannot be disabled or demoted.

## 7. Go-live rule
Do not switch off the existing application on the same day as migration. Run old system read-only and v1.0 in parallel for one reconciliation cycle. After balances match, v1.0 becomes canonical.
