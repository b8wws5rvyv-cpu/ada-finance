# Paket 3 — Persistence, Migration, Auth/RBAC ve Canlı API

## Amaç
v0.2 hesaplama çekirdeğini demo veriden çıkarıp kalıcı veritabanı ve API üzerinde çalıştırmak.

## Teslim edilenler
- SQLite ilişkisel şema ve migration başlangıcı
- Kullanıcı hesabı, şifre hash (scrypt), 7 günlük oturum tokenı
- Admin / Accounting / Personnel / Viewer backend yetki matrisi
- Audit log ve destructive delete yerine archive
- Counterparty, invoice, account, payment, allocation, payable, employee ve personnel adjustment persistence
- Gerçek dashboard API
- Customer 360 API
- Opportunity OS ortak Company/Order/Product kimlik alanları
- Legacy ADA Finans JSON importer
- Mevcut personel maaş/SGK/mesai/avans/kesinti mantığının persistence katmanına taşınması
- Responsive API tabanlı UI; demo veri kaldırıldı

## Legacy taşıma
Eski sistemden alınan JSON yedeği:

```bash
npm run import-legacy -- /path/to/legacy.json
```

Importer şu alanları taşır: cariler, yetkililer, hesaplar, faturalar, kasaHareketleri ve faturaya bağlı tahsilatlar, personel, mesai/avans/kesinti hareketleri.

Importer duplicate-safe olacak şekilde `legacy_<id>` kullanır ve tekrar çalıştırıldığında ana kayıtların çoğunu çoğaltmaz. Üretim migrationında önce yedek alınmalıdır.

## Bilinçli olarak Paket 4'e bırakılanlar
- Banka PDF/CSV/OCR staging + eşleştirme ve onay ekranı
- Fiş/fatura görsel okuma staging
- Stok
- e-Fatura/e-Arşiv özel entegratör bağlantısı
- Otomatik günlük yedek hedefi (deployment ortamına göre)
