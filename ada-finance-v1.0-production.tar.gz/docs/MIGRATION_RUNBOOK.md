# Canlı Geçiş Runbook

1. Mevcut ADA Finans sisteminden JSON yedeği alın.
2. Yedeği tarih-saat damgasıyla değiştirilemez kopya olarak saklayın.
3. `npm run init-db` ile boş veritabanını oluşturun.
4. İlk admin hesabını web arayüzünden oluşturun.
5. `npm run import-legacy -- legacy.json` ile kayıtları staging veritabanına aktarın.
6. Kontrol toplamlarını karşılaştırın: cari sayısı, fatura sayısı, banka/kasa açılışları, açık alacak toplamı, personel sayısı.
7. Kudret negatif maaş farkı, Begmyrat mesai/avans/kesinti örneği ve banka/elden toplamlarını kontrol edin.
8. Opportunity OS Company ID eşleştirmelerini yalnız doğrulanmış kayıtlar için girin.
9. Staging onayı sonrası aynı migrationı üretim veritabanında çalıştırın.
10. Eski sistemi 7 gün salt-okunur arşiv olarak tutun; sonra erişimi kapatın, yedeği koruyun.
