# Package 2 — Finance Decision UI

Implements the next block from the ADA Opportunity OS-aligned Finance roadmap.

## Delivered
- Executive finance dashboard
- Receivables and overdue radar
- Payables calendar
- 30/60/90 cash-flow projection
- Customer 360 financial view with Opportunity OS Company ID
- Personnel-to-finance obligation bridge
- Employee debt preservation
- Unit tests for all new aggregate logic

## Important boundary
This UI uses demo data and the pure finance core. Production persistence/authentication must be wired to the existing ADA Finance server before live financial use.
