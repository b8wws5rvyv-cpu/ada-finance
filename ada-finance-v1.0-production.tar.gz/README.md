# ADA Group Finance & Operations v1.0

Production-ready release candidate built from ADA Finance Core v0.9 and aligned with ADA Opportunity OS integration boundaries.

## What v1.0 adds
- Production user management: roles, disable/enable, password reset, session revoke, logout.
- Last-admin protection.
- Login throttling for repeated failed attempts.
- Security headers and same-origin web UI.
- SQLite WAL + busy timeout for multi-user web access.
- `/api/health` and `/api/ready`.
- Persistent application error log.
- Daily scheduled backups, manual backup, SHA-256 and retention history.
- Backup download from admin UI.
- Offline integrity-checked restore with automatic pre-restore copy.
- Graceful SIGTERM/SIGINT shutdown.
- Dockerfile, docker-compose, `.env.example`, preflight script.
- Existing v0.9 finance, personnel, bank import, document, expense, stock, planning and profitability functions are retained.

## Commands
```bash
npm run init-db
npm run preflight
npm test
npm start
npm run backup
npm run restore-backup -- /path/to/backup.sqlite
npm run import-legacy -- legacy.json
```

## Deployment
Use `docs/PRODUCTION_RUNBOOK.md`. The database, uploads and backups must live on a persistent volume.

## Migration safety
The legacy ADA Finance instance is not assumed migrated until its actual JSON/database export is available and reconciliation succeeds. Migration must preserve the old instance as read-only until customer balances, invoices, bank/cash balances and payroll totals match.
