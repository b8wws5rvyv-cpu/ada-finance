PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS organizations (
  id TEXT PRIMARY KEY,
  legal_name TEXT NOT NULL,
  tax_number TEXT,
  tax_office TEXT,
  country_code TEXT DEFAULT 'TR',
  default_currency TEXT NOT NULL DEFAULT 'TRY',
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Shared identity bridge to Opportunity OS. One finance customer can map to one Opportunity OS company.
CREATE TABLE IF NOT EXISTS counterparties (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  opportunity_company_id TEXT,
  legal_name TEXT NOT NULL,
  brand_name TEXT,
  counterparty_type TEXT NOT NULL CHECK(counterparty_type IN ('customer','supplier','both','other')),
  tax_number TEXT,
  tax_office TEXT,
  currency TEXT NOT NULL DEFAULT 'TRY',
  payment_term_days INTEGER NOT NULL DEFAULT 0,
  credit_limit_minor INTEGER,
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive','archived')),
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_counterparty_org_opp_company
  ON counterparties(organization_id, opportunity_company_id)
  WHERE opportunity_company_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS counterparty_contacts (
  id TEXT PRIMARY KEY,
  counterparty_id TEXT NOT NULL,
  full_name TEXT NOT NULL,
  title TEXT,
  phone TEXT,
  email TEXT,
  is_primary INTEGER NOT NULL DEFAULT 0,
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (counterparty_id) REFERENCES counterparties(id)
);

CREATE TABLE IF NOT EXISTS finance_products (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  opportunity_product_id TEXT,
  sku TEXT,
  name TEXT NOT NULL,
  unit TEXT NOT NULL DEFAULT 'adet',
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_fin_product_opp_product
  ON finance_products(organization_id, opportunity_product_id)
  WHERE opportunity_product_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  opportunity_order_id TEXT,
  opportunity_id TEXT,
  counterparty_id TEXT NOT NULL,
  order_no TEXT,
  order_date TEXT NOT NULL,
  currency TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('draft','open','partially_invoiced','invoiced','cancelled','archived')),
  total_minor INTEGER NOT NULL DEFAULT 0,
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id),
  FOREIGN KEY (counterparty_id) REFERENCES counterparties(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_orders_opportunity_order
  ON orders(organization_id, opportunity_order_id)
  WHERE opportunity_order_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  counterparty_id TEXT NOT NULL,
  order_id TEXT,
  invoice_no TEXT,
  direction TEXT NOT NULL CHECK(direction IN ('sales','purchase')),
  invoice_date TEXT NOT NULL,
  due_date TEXT,
  expected_payment_date TEXT,
  currency TEXT NOT NULL,
  subtotal_minor INTEGER NOT NULL DEFAULT 0,
  tax_minor INTEGER NOT NULL DEFAULT 0,
  total_minor INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('draft','open','partial','paid','overdue','cancelled','archived')),
  notes TEXT,
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id),
  FOREIGN KEY (counterparty_id) REFERENCES counterparties(id),
  FOREIGN KEY (order_id) REFERENCES orders(id)
);
CREATE INDEX IF NOT EXISTS idx_invoices_due ON invoices(organization_id, direction, status, due_date);

CREATE TABLE IF NOT EXISTS cash_accounts (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  name TEXT NOT NULL,
  account_type TEXT NOT NULL CHECK(account_type IN ('cash','bank')),
  currency TEXT NOT NULL,
  iban TEXT,
  opening_balance_minor INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive','archived')),
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id)
);

CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  counterparty_id TEXT,
  account_id TEXT NOT NULL,
  direction TEXT NOT NULL CHECK(direction IN ('in','out')),
  payment_date TEXT NOT NULL,
  currency TEXT NOT NULL,
  amount_minor INTEGER NOT NULL CHECK(amount_minor >= 0),
  method TEXT,
  reference TEXT,
  notes TEXT,
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id),
  FOREIGN KEY (counterparty_id) REFERENCES counterparties(id),
  FOREIGN KEY (account_id) REFERENCES cash_accounts(id)
);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(organization_id, payment_date);

CREATE TABLE IF NOT EXISTS payment_allocations (
  id TEXT PRIMARY KEY,
  payment_id TEXT NOT NULL,
  invoice_id TEXT NOT NULL,
  amount_minor INTEGER NOT NULL CHECK(amount_minor > 0),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (payment_id) REFERENCES payments(id),
  FOREIGN KEY (invoice_id) REFERENCES invoices(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_payment_invoice_alloc ON payment_allocations(payment_id, invoice_id);

CREATE TABLE IF NOT EXISTS payables (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  counterparty_id TEXT,
  payable_type TEXT NOT NULL CHECK(payable_type IN ('supplier','tax','social_security','rent','payroll','other')),
  title TEXT NOT NULL,
  due_date TEXT NOT NULL,
  currency TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  paid_minor INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','partial','paid','overdue','cancelled','archived')),
  source_type TEXT,
  source_id TEXT,
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id),
  FOREIGN KEY (counterparty_id) REFERENCES counterparties(id)
);
CREATE INDEX IF NOT EXISTS idx_payables_due ON payables(organization_id, status, due_date);

CREATE TABLE IF NOT EXISTS personnel_obligations (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  personnel_id TEXT NOT NULL,
  period TEXT NOT NULL,
  due_date TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'TRY',
  bank_amount_minor INTEGER NOT NULL DEFAULT 0,
  cash_amount_minor INTEGER NOT NULL DEFAULT 0,
  employee_debt_minor INTEGER NOT NULL DEFAULT 0,
  overtime_minor INTEGER NOT NULL DEFAULT 0,
  advance_minor INTEGER NOT NULL DEFAULT 0,
  deduction_minor INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','partial','paid','archived')),
  archived_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_personnel_obligation_period ON personnel_obligations(organization_id, personnel_id, period);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  email TEXT NOT NULL,
  display_name TEXT,
  role TEXT NOT NULL CHECK(role IN ('admin','accounting','personnel','viewer')),
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_user_org_email ON users(organization_id, email);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  actor_user_id TEXT,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  action TEXT NOT NULL,
  before_json TEXT,
  after_json TEXT,
  request_id TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id),
  FOREIGN KEY (actor_user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(organization_id, entity_type, entity_id, created_at);

CREATE TABLE IF NOT EXISTS integration_links (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  local_entity_type TEXT NOT NULL,
  local_entity_id TEXT NOT NULL,
  remote_system TEXT NOT NULL DEFAULT 'opportunity_os',
  remote_entity_type TEXT NOT NULL,
  remote_entity_id TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'linked' CHECK(sync_status IN ('linked','pending','conflict','disabled')),
  last_synced_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organization_id) REFERENCES organizations(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_integration_remote ON integration_links(organization_id, remote_system, remote_entity_type, remote_entity_id);
