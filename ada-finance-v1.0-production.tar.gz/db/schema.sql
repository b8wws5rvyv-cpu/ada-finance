PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin','accounting','personnel','viewer')),
  password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','disabled')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  revoked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS counterparties (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'customer' CHECK(type IN ('customer','vendor','both')),
  tax_office TEXT,
  tax_no TEXT,
  country TEXT,
  currency TEXT NOT NULL DEFAULT 'TRY',
  payment_term_days INTEGER NOT NULL DEFAULT 0,
  opening_minor INTEGER NOT NULL DEFAULT 0,
  opening_date TEXT,
  opportunity_company_id TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_counterparties_name ON counterparties(name);
CREATE INDEX IF NOT EXISTS idx_counterparties_remote ON counterparties(opportunity_company_id);

CREATE TABLE IF NOT EXISTS contacts (
  id TEXT PRIMARY KEY,
  counterparty_id TEXT NOT NULL REFERENCES counterparties(id),
  name TEXT NOT NULL,
  title TEXT,
  function TEXT,
  phone TEXT,
  email TEXT,
  linkedin_url TEXT,
  is_primary INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_contacts_counterparty ON contacts(counterparty_id);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  sku TEXT,
  opportunity_product_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  counterparty_id TEXT NOT NULL REFERENCES counterparties(id),
  order_no TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  currency TEXT NOT NULL DEFAULT 'TRY',
  total_minor INTEGER NOT NULL DEFAULT 0,
  opportunity_order_id TEXT,
  opportunity_id TEXT,
  order_date TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_orders_counterparty ON orders(counterparty_id);

CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  counterparty_id TEXT NOT NULL REFERENCES counterparties(id),
  order_id TEXT REFERENCES orders(id),
  direction TEXT NOT NULL CHECK(direction IN ('sales','purchase')),
  number TEXT,
  invoice_date TEXT NOT NULL,
  due_date TEXT,
  expected_payment_date TEXT,
  currency TEXT NOT NULL DEFAULT 'TRY',
  net_minor INTEGER NOT NULL DEFAULT 0,
  tax_minor INTEGER NOT NULL DEFAULT 0,
  total_minor INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','cancelled')),
  description TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_invoices_counterparty ON invoices(counterparty_id);
CREATE INDEX IF NOT EXISTS idx_invoices_due ON invoices(due_date);

CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('cash','bank')),
  currency TEXT NOT NULL DEFAULT 'TRY',
  opening_minor INTEGER NOT NULL DEFAULT 0,
  iban TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);

CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  counterparty_id TEXT REFERENCES counterparties(id),
  account_id TEXT REFERENCES accounts(id),
  direction TEXT NOT NULL CHECK(direction IN ('in','out')),
  payment_date TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'TRY',
  amount_minor INTEGER NOT NULL,
  category TEXT,
  description TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);

CREATE TABLE IF NOT EXISTS payment_allocations (
  id TEXT PRIMARY KEY,
  payment_id TEXT NOT NULL REFERENCES payments(id),
  invoice_id TEXT NOT NULL REFERENCES invoices(id),
  amount_minor INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_alloc_invoice ON payment_allocations(invoice_id);

CREATE TABLE IF NOT EXISTS payables (
  id TEXT PRIMARY KEY,
  counterparty_id TEXT REFERENCES counterparties(id),
  vendor_name TEXT,
  category TEXT NOT NULL,
  due_date TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'TRY',
  original_minor INTEGER NOT NULL,
  remaining_minor INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','paid','cancelled')),
  description TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_payables_due ON payables(due_date);

CREATE TABLE IF NOT EXISTS employees (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  pay_cycle TEXT NOT NULL DEFAULT 'monthly' CHECK(pay_cycle IN ('monthly','weekly')),
  real_salary_minor INTEGER NOT NULL DEFAULT 0,
  bank_sgk_minor INTEGER NOT NULL DEFAULT 0,
  weekly_wage_minor INTEGER NOT NULL DEFAULT 0,
  insured INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);

CREATE TABLE IF NOT EXISTS personnel_adjustments (
  id TEXT PRIMARY KEY,
  employee_id TEXT NOT NULL REFERENCES employees(id),
  period TEXT NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('overtime','advance','deduction','extra')),
  hours REAL,
  rate_minor INTEGER,
  amount_minor INTEGER NOT NULL,
  reason TEXT,
  event_date TEXT,
  created_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_adjustments_period ON personnel_adjustments(period,employee_id);

CREATE TABLE IF NOT EXISTS personnel_obligations (
  id TEXT PRIMARY KEY,
  employee_id TEXT NOT NULL REFERENCES employees(id),
  period TEXT NOT NULL,
  due_date TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'TRY',
  bank_amount_minor INTEGER NOT NULL DEFAULT 0,
  cash_amount_minor INTEGER NOT NULL DEFAULT 0,
  employee_debt_minor INTEGER NOT NULL DEFAULT 0,
  net_minor INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','partial','paid')),
  bank_paid_at TEXT,
  cash_paid_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT,
  UNIQUE(employee_id, period)
);
CREATE INDEX IF NOT EXISTS idx_personnel_obligation_period ON personnel_obligations(period);

CREATE TABLE IF NOT EXISTS integration_links (
  id TEXT PRIMARY KEY,
  local_entity_type TEXT NOT NULL,
  local_entity_id TEXT NOT NULL,
  remote_system TEXT NOT NULL DEFAULT 'opportunity_os',
  remote_entity_type TEXT NOT NULL,
  remote_entity_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  archived_at TEXT,
  UNIQUE(local_entity_type,local_entity_id,remote_system,remote_entity_type)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  before_json TEXT,
  after_json TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity_type,entity_id,created_at);

CREATE TABLE IF NOT EXISTS bank_import_batches (
  id TEXT PRIMARY KEY,
  account_id TEXT REFERENCES accounts(id),
  source_name TEXT,
  source_type TEXT NOT NULL DEFAULT 'csv',
  imported_by TEXT REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'review' CHECK(status IN ('review','completed','archived')),
  row_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  archived_at TEXT
);

CREATE TABLE IF NOT EXISTS bank_import_rows (
  id TEXT PRIMARY KEY,
  batch_id TEXT NOT NULL REFERENCES bank_import_batches(id),
  row_no INTEGER NOT NULL,
  txn_date TEXT,
  description TEXT,
  reference TEXT,
  direction TEXT CHECK(direction IN ('in','out')),
  amount_minor INTEGER NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'TRY',
  suggested_counterparty_id TEXT REFERENCES counterparties(id),
  suggested_invoice_id TEXT REFERENCES invoices(id),
  confidence REAL NOT NULL DEFAULT 0,
  decision TEXT NOT NULL DEFAULT 'pending' CHECK(decision IN ('pending','approved','rejected','edited')),
  payment_id TEXT REFERENCES payments(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT,
  UNIQUE(batch_id,row_no)
);
CREATE INDEX IF NOT EXISTS idx_bank_import_rows_batch ON bank_import_rows(batch_id,decision);

CREATE TABLE IF NOT EXISTS document_staging (
  id TEXT PRIMARY KEY,
  source_name TEXT NOT NULL,
  mime_type TEXT,
  document_type TEXT NOT NULL DEFAULT 'unknown',
  counterparty_id TEXT REFERENCES counterparties(id),
  extracted_text TEXT,
  extracted_json TEXT,
  status TEXT NOT NULL DEFAULT 'staged' CHECK(status IN ('staged','reviewed','posted','rejected')),
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);

CREATE TABLE IF NOT EXISTS inventory_items (
  id TEXT PRIMARY KEY,
  sku TEXT UNIQUE,
  name TEXT NOT NULL,
  unit TEXT NOT NULL DEFAULT 'adet' CHECK(unit IN ('adet','m','m2','kg','paket','set','diger')),
  category TEXT,
  min_level REAL NOT NULL DEFAULT 0,
  opportunity_product_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);

CREATE TABLE IF NOT EXISTS inventory_movements (
  id TEXT PRIMARY KEY,
  item_id TEXT NOT NULL REFERENCES inventory_items(id),
  movement_date TEXT NOT NULL,
  direction TEXT NOT NULL CHECK(direction IN ('in','out','adjustment')),
  quantity REAL NOT NULL,
  unit_cost_minor INTEGER,
  counterparty_id TEXT REFERENCES counterparties(id),
  order_id TEXT REFERENCES orders(id),
  description TEXT,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  source_type TEXT,
  source_id TEXT,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_inventory_movements_item ON inventory_movements(item_id,movement_date);

-- Package 5: expense automation, document review and stock source linkage
CREATE TABLE IF NOT EXISTS expenses (
  id TEXT PRIMARY KEY,
  counterparty_id TEXT REFERENCES counterparties(id),
  document_id TEXT REFERENCES document_staging(id),
  expense_date TEXT NOT NULL,
  category TEXT NOT NULL,
  department TEXT,
  currency TEXT NOT NULL DEFAULT 'TRY',
  net_minor INTEGER NOT NULL DEFAULT 0,
  tax_minor INTEGER NOT NULL DEFAULT 0,
  total_minor INTEGER NOT NULL,
  payment_mode TEXT NOT NULL DEFAULT 'unpaid' CHECK(payment_mode IN ('unpaid','cash','bank','payable')),
  account_id TEXT REFERENCES accounts(id),
  due_date TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','approved','paid','rejected')),
  description TEXT,
  created_by TEXT REFERENCES users(id),
  approved_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date,status);
CREATE INDEX IF NOT EXISTS idx_expenses_counterparty ON expenses(counterparty_id);

CREATE TABLE IF NOT EXISTS production_jobs (
  id TEXT PRIMARY KEY,
  job_no TEXT,
  order_id TEXT REFERENCES orders(id),
  output_item_id TEXT REFERENCES inventory_items(id),
  planned_qty REAL NOT NULL DEFAULT 0,
  produced_qty REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','in_progress','completed','cancelled')),
  started_at TEXT,
  completed_at TEXT,
  description TEXT,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);

-- Package 6: binary file archive, extraction queue and dashboard operating metrics
CREATE TABLE IF NOT EXISTS file_objects (
  id TEXT PRIMARY KEY,
  original_name TEXT NOT NULL,
  mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
  size_bytes INTEGER NOT NULL DEFAULT 0,
  sha256 TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'document' CHECK(category IN ('document','bank_statement','receipt','invoice','other')),
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_file_objects_sha ON file_objects(sha256,storage_path);

CREATE TABLE IF NOT EXISTS extraction_jobs (
  id TEXT PRIMARY KEY,
  file_id TEXT NOT NULL REFERENCES file_objects(id),
  purpose TEXT NOT NULL DEFAULT 'document' CHECK(purpose IN ('document','bank_statement')),
  engine TEXT NOT NULL DEFAULT 'auto',
  status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued','processing','completed','needs_external_ocr','failed')),
  extracted_text TEXT,
  error_message TEXT,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  completed_at TEXT,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_extraction_jobs_status ON extraction_jobs(status,created_at);

CREATE TABLE IF NOT EXISTS file_links (
  id TEXT PRIMARY KEY,
  file_id TEXT NOT NULL REFERENCES file_objects(id),
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_file_links_entity ON file_links(entity_type,entity_id);

-- Package 8: budgeting, profitability and 13-week cash planning
CREATE TABLE IF NOT EXISTS order_items (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES orders(id),
  product_id TEXT REFERENCES products(id),
  description TEXT,
  quantity REAL NOT NULL DEFAULT 0,
  sales_unit_minor INTEGER NOT NULL DEFAULT 0,
  direct_unit_cost_minor INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product ON order_items(product_id);

CREATE TABLE IF NOT EXISTS budget_plans (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'TRY',
  start_month TEXT NOT NULL,
  end_month TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','active','archived')),
  notes TEXT,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);

CREATE TABLE IF NOT EXISTS budget_lines (
  id TEXT PRIMARY KEY,
  plan_id TEXT NOT NULL REFERENCES budget_plans(id),
  month TEXT NOT NULL,
  revenue_budget_minor INTEGER NOT NULL DEFAULT 0,
  expense_budget_minor INTEGER NOT NULL DEFAULT 0,
  cash_in_budget_minor INTEGER NOT NULL DEFAULT 0,
  cash_out_budget_minor INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT,
  UNIQUE(plan_id, month)
);
CREATE INDEX IF NOT EXISTS idx_budget_lines_plan_month ON budget_lines(plan_id,month);

-- Package 9: cost centers, overhead allocation and controllable net profitability
CREATE TABLE IF NOT EXISTS cost_centers (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'overhead' CHECK(kind IN ('overhead','department','production','sales','admin')),
  default_basis TEXT NOT NULL DEFAULT 'revenue' CHECK(default_basis IN ('revenue','direct_cost','equal')),
  description TEXT,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT
);

CREATE TABLE IF NOT EXISTS expense_cost_center_allocations (
  id TEXT PRIMARY KEY,
  expense_id TEXT NOT NULL REFERENCES expenses(id),
  cost_center_id TEXT NOT NULL REFERENCES cost_centers(id),
  amount_minor INTEGER NOT NULL,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_exp_cc_expense ON expense_cost_center_allocations(expense_id);
CREATE INDEX IF NOT EXISTS idx_exp_cc_center ON expense_cost_center_allocations(cost_center_id);

CREATE TABLE IF NOT EXISTS cost_center_links (
  id TEXT PRIMARY KEY,
  cost_center_id TEXT NOT NULL REFERENCES cost_centers(id),
  entity_type TEXT NOT NULL CHECK(entity_type IN ('order','customer','product','department')),
  entity_id TEXT NOT NULL,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  archived_at TEXT,
  UNIQUE(cost_center_id,entity_type,entity_id)
);
CREATE INDEX IF NOT EXISTS idx_cc_links_center ON cost_center_links(cost_center_id,entity_type);

CREATE TABLE IF NOT EXISTS cost_allocation_runs (
  id TEXT PRIMARY KEY,
  period TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'TRY',
  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','posted','archived')),
  total_overhead_minor INTEGER NOT NULL DEFAULT 0,
  allocated_minor INTEGER NOT NULL DEFAULT 0,
  unallocated_minor INTEGER NOT NULL DEFAULT 0,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL,
  posted_at TEXT,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_cost_runs_period ON cost_allocation_runs(period,currency,status);

CREATE TABLE IF NOT EXISTS cost_allocations (
  id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL REFERENCES cost_allocation_runs(id),
  cost_center_id TEXT REFERENCES cost_centers(id),
  expense_id TEXT REFERENCES expenses(id),
  order_id TEXT REFERENCES orders(id),
  amount_minor INTEGER NOT NULL,
  basis TEXT NOT NULL CHECK(basis IN ('revenue','direct_cost','equal','unallocated')),
  created_at TEXT NOT NULL,
  archived_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_cost_alloc_run ON cost_allocations(run_id);
CREATE INDEX IF NOT EXISTS idx_cost_alloc_order ON cost_allocations(order_id);

-- v1.0 production hardening
CREATE TABLE IF NOT EXISTS app_error_log (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  request_method TEXT,
  request_path TEXT,
  error_code TEXT,
  message TEXT NOT NULL,
  stack TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_error_log_created ON app_error_log(created_at DESC);

CREATE TABLE IF NOT EXISTS backup_history (
  id TEXT PRIMARY KEY,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  size_bytes INTEGER NOT NULL DEFAULT 0,
  sha256 TEXT,
  trigger_type TEXT NOT NULL CHECK(trigger_type IN ('manual','scheduled','pre_restore')),
  status TEXT NOT NULL DEFAULT 'completed' CHECK(status IN ('completed','failed')),
  created_by TEXT,
  created_at TEXT NOT NULL,
  notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_backup_history_created ON backup_history(created_at DESC);
