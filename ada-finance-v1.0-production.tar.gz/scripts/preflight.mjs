import fs from 'node:fs'; import path from 'node:path'; import {FinanceDb} from '../server/db.mjs';
const root=path.resolve(import.meta.dirname,'..'); const dbFile=process.env.ADA_DB || path.resolve(root,'data/ada-finance.sqlite');
fs.mkdirSync(path.dirname(dbFile),{recursive:true}); const db=new FinanceDb(dbFile);
try{
  const checks={node:process.version,database:dbFile,integrity:db.integrityCheck(),users:db.userCount(),writeable:true};
  const probe=path.join(path.dirname(dbFile),'.write-probe'); fs.writeFileSync(probe,'ok'); fs.rmSync(probe);
  console.log(JSON.stringify({ok:Object.values(checks).every(x=>x!==false),checks},null,2)); if(!checks.integrity)process.exitCode=3;
} finally{db.close();}
