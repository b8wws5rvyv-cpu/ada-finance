import fs from 'node:fs'; import path from 'node:path'; import {FinanceDb} from '../server/db.mjs';
const [, , legacyFile] = process.argv; if(!legacyFile){ console.error('Kullanım: npm run import-legacy -- legacy.json'); process.exit(2); }
const file=process.env.ADA_DB || path.resolve('data/ada-finance.sqlite'); const db=new FinanceDb(file); const state=JSON.parse(fs.readFileSync(legacyFile,'utf8')); console.log(db.importLegacy(state)); db.close();
