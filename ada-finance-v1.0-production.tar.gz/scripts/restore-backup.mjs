import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';

const [, , sourceArg] = process.argv;
if(!sourceArg){ console.error('Usage: npm run restore-backup -- /path/to/backup.sqlite'); process.exit(2); }
const root=path.resolve(import.meta.dirname,'..');
const dbFile=process.env.ADA_DB || path.resolve(root,'data/ada-finance.sqlite');
const source=path.resolve(sourceArg);
if(!fs.existsSync(source)){ console.error('Backup not found:',source); process.exit(2); }
const test=new DatabaseSync(source,{readOnly:true});
const check=test.prepare('PRAGMA integrity_check').get(); test.close();
if(Object.values(check||{})[0]!=='ok'){ console.error('Backup integrity check failed'); process.exit(3); }
fs.mkdirSync(path.dirname(dbFile),{recursive:true});
if(fs.existsSync(dbFile)){
  const pre=`${dbFile}.pre-restore-${new Date().toISOString().replace(/[:.]/g,'-')}`;
  fs.copyFileSync(dbFile,pre);
  console.log('Pre-restore copy:',pre);
}
for(const suffix of ['-wal','-shm']) fs.rmSync(dbFile+suffix,{force:true});
fs.copyFileSync(source,dbFile);
const bytes=fs.readFileSync(dbFile); const sha=crypto.createHash('sha256').update(bytes).digest('hex');
console.log(JSON.stringify({ok:true,restoredTo:dbFile,source,sha256:sha},null,2));
