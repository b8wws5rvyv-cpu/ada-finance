import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {FinanceDb} from '../server/db.mjs';

const root=path.resolve(import.meta.dirname,'..');
const dbFile=process.env.ADA_DB || path.resolve(root,'data/ada-finance.sqlite');
const backupDir=process.env.ADA_BACKUP_DIR || path.resolve(path.dirname(dbFile),'backups');
const keepDays=Math.max(1,Number(process.env.ADA_BACKUP_KEEP_DAYS)||30);
fs.mkdirSync(backupDir,{recursive:true});
if(!fs.existsSync(dbFile)){ console.error('Database not found:',dbFile); process.exit(2); }
const db=new FinanceDb(dbFile);
try{
  db.db.exec('PRAGMA wal_checkpoint(TRUNCATE);');
  const stamp=new Date().toISOString().replace(/[:.]/g,'-');
  const name=`ada-finance-${stamp}.sqlite`;
  const target=path.join(backupDir,name);
  const safe=target.replaceAll("'","''");
  db.db.exec(`VACUUM INTO '${safe}'`);
  const bytes=fs.readFileSync(target);
  const sha=crypto.createHash('sha256').update(bytes).digest('hex');
  db.recordBackup({fileName:name,filePath:target,sizeBytes:bytes.length,sha256:sha,triggerType:process.env.ADA_BACKUP_TRIGGER||'manual',notes:'SQLite VACUUM INTO verified backup'});
  const cutoff=Date.now()-keepDays*86400000;
  for(const f of fs.readdirSync(backupDir)){
    if(!/^ada-finance-.*\.sqlite$/.test(f))continue;
    const fp=path.join(backupDir,f); if(fs.statSync(fp).mtimeMs<cutoff && fp!==target) fs.rmSync(fp,{force:true});
  }
  console.log(JSON.stringify({ok:true,file:target,sizeBytes:bytes.length,sha256:sha,keepDays},null,2));
} finally { db.close(); }
