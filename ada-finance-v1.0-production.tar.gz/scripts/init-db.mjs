import path from 'node:path'; import fs from 'node:fs'; import {FinanceDb} from '../server/db.mjs';
const file=process.env.ADA_DB || path.resolve('data/ada-finance.sqlite'); fs.mkdirSync(path.dirname(file),{recursive:true}); const db=new FinanceDb(file); console.log(`DB hazır: ${file}`); db.close();
