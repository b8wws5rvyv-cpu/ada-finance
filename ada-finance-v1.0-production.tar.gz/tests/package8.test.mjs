import test from 'node:test';
import assert from 'node:assert/strict';
import {budgetVsActual,profitabilityAnalysis,thirteenWeekCashFlow} from '../src/finance-core.mjs';
import {FinanceDb} from '../server/db.mjs';

test('budget vs actual computes variances',()=>{
  const r=budgetVsActual({budgetLines:[{month:'2026-09',revenueBudgetMinor:100000,expenseBudgetMinor:40000,cashInBudgetMinor:80000,cashOutBudgetMinor:30000}],monthlyActual:[{month:'2026-09',revenueMinor:120000,expenseMinor:50000,collectionsMinor:70000,cashOutMinor:25000}]});
  assert.equal(r.rows[0].revenueVarianceMinor,20000);
  assert.equal(r.rows[0].expenseVarianceMinor,10000);
});

test('profitability aggregates order, customer and product',()=>{
  const r=profitabilityAnalysis({orders:[{id:'o1',counterpartyId:'c1'}],orderItems:[{orderId:'o1',productId:'p1',quantity:10,salesUnitMinor:1000,directUnitCostMinor:600}],counterparties:[{id:'c1',name:'A'}],products:[{id:'p1',name:'Bag'}]});
  assert.equal(r.totals.revenueMinor,10000); assert.equal(r.totals.directCostMinor,6000); assert.equal(r.totals.grossProfitMinor,4000); assert.equal(r.byCustomer[0].grossProfitMinor,4000);
});

test('13-week scenarios scale collections but not outflows',()=>{
  const r=thirteenWeekCashFlow({openingMinor:10000,fromDate:'2026-09-14',receivables:[{remainingMinor:10000,dueDate:'2026-09-15'}],payables:[{remainingMinor:4000,dueDate:'2026-09-16'}],personnel:[]});
  assert.equal(r.good[0].endingMinor,16000); assert.equal(r.base[0].endingMinor,14000); assert.equal(r.bad[0].endingMinor,11000);
});

test('database package 8 planning flow works',()=>{
  const db=new FinanceDb(':memory:');
  const u=db.createUser({email:'a@a.com',displayName:'A',role:'admin',password:'password123'});
  const c=db.createCounterparty({name:'Customer',type:'customer'},u.id);
  const p=db.createProduct({name:'Cargo Bag',sku:'CB'},u.id);
  const o=db.createOrder({counterpartyId:c.id,orderNo:'O-1',orderDate:'2026-09-01'},u.id);
  db.addOrderItem({orderId:o.id,productId:p.id,quantity:100,salesUnitMinor:65000,directUnitCostMinor:40000},u.id);
  const prof=db.getProfitability(); assert.equal(prof.totals.grossProfitMinor,2500000);
  const b=db.createBudgetPlan({name:'2026 Plan',startMonth:'2026-09',endMonth:'2026-12',status:'active'},u.id);
  db.upsertBudgetLine({planId:b.id,month:'2026-09',revenueBudgetMinor:1000000},u.id);
  const br=db.getBudgetReport(b.id,'2026-09-30'); assert.equal(br.rows.length,1);
  db.close();
});
