import test from 'node:test';
import assert from 'node:assert/strict';
import {receivablesSummary,payablesCalendar,customer360,dashboardSummary,buildPersonnelObligation} from '../src/finance-core.mjs';

test('receivables summary separates overdue and not-due',()=>{
  const invoices=[
    {id:'i1',companyId:'c1',direction:'sales',totalMinor:100000,dueDate:'2026-09-01',status:'open'},
    {id:'i2',companyId:'c1',direction:'sales',totalMinor:200000,dueDate:'2026-10-01',status:'open'}
  ];
  const s=receivablesSummary(invoices,[], '2026-09-14');
  assert.equal(s.totalMinor,300000); assert.equal(s.overdueMinor,100000); assert.equal(s.notDueMinor,200000);
});

test('payables calendar includes overdue and next 30 days only',()=>{
  const p=[
    {id:'p1',remainingMinor:100,dueDate:'2026-09-01'},
    {id:'p2',remainingMinor:200,dueDate:'2026-09-20'},
    {id:'p3',remainingMinor:300,dueDate:'2026-11-20'}
  ];
  assert.deepEqual(payablesCalendar(p,'2026-09-14',30).map(x=>x.id),['p1','p2']);
});

test('customer 360 aggregates sales and open receivable',()=>{
  const c=customer360({company:{id:'c1',name:'Aras'}, invoices:[{id:'i1',companyId:'c1',direction:'sales',totalMinor:1000,dueDate:'2026-09-01',status:'open'}], allocations:[{invoiceId:'i1',amountMinor:250}], orders:[],contacts:[], today:'2026-09-14'});
  assert.equal(c.totalSalesMinor,1000); assert.equal(c.openReceivableMinor,750); assert.equal(c.overdueMinor,750);
});

test('dashboard summary includes balances and obligations',()=>{
  const d=dashboardSummary({accounts:[{currency:'TRY',openingMinor:10000}],transactions:[{currency:'TRY',direction:'out',amountMinor:1000}], invoices:[], allocations:[], payables:[{remainingMinor:2000,dueDate:'2026-09-20'}], personnelObligations:[{bankAmountMinor:3000,cashAmountMinor:4000,status:'open'}],today:'2026-09-14'});
  assert.equal(d.balances.TRY,9000); assert.equal(d.payable30Minor,2000); assert.equal(d.personnelOpenMinor,7000);
});

test('personnel obligation preserves employee debt',()=>{
  const p=buildPersonnelObligation({id:'po1',employeeId:'kudret',employeeName:'Kudret',dueDate:'2026-09-30',realSalaryMinor:3900000,bankSgkMinor:3988000});
  assert.equal(p.employeeDebtMinor,88000); assert.equal(p.cashAmountMinor,0); assert.equal(p.netMinor,-88000);
});
