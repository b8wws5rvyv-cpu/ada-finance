import test from 'node:test';
import assert from 'node:assert/strict';
import {managementMonthlySeries,expenseBreakdown,customerPerformance,concentrationRisk,accountBalanceTrend,monthRange} from '../src/finance-core.mjs';
import {FinanceDb} from '../server/db.mjs';

test('monthRange builds requested rolling periods',()=>{
  assert.deepEqual(monthRange('2026-09-14',3),['2026-07','2026-08','2026-09']);
});

test('management monthly series separates accrual revenue and cash collections',()=>{
  const x=managementMonthlySeries({asOf:'2026-09-14',months:3,currency:'TRY',
    invoices:[{direction:'sales',invoiceDate:'2026-08-02',currency:'TRY',totalMinor:100000,status:'open'}],
    payments:[{direction:'in',paymentDate:'2026-09-03',currency:'TRY',amountMinor:60000}],
    expenses:[{expenseDate:'2026-09-05',currency:'TRY',totalMinor:10000,status:'approved'}]});
  assert.equal(x[1].revenueMinor,100000); assert.equal(x[2].collectionsMinor,60000); assert.equal(x[2].expenseMinor,10000);
});

test('expense breakdown groups category and department',()=>{
  const e=expenseBreakdown([{expenseDate:'2026-09-01',currency:'TRY',status:'approved',totalMinor:30000,category:'Kira',department:'Genel'},{expenseDate:'2026-09-02',currency:'TRY',status:'paid',totalMinor:10000,category:'Kira',department:'Genel'}],{fromDate:'2026-09-01',toDate:'2026-09-30'});
  assert.equal(e.totalMinor,40000); assert.equal(e.byCategory[0].amountMinor,40000); assert.equal(e.byCategory[0].share,1);
});

test('customer performance calculates sales collection open and concentration',()=>{
  const counterparties=[{id:'c1',name:'A',type:'customer'},{id:'c2',name:'B',type:'customer'}];
  const invoices=[{id:'i1',counterpartyId:'c1',direction:'sales',invoiceDate:'2026-09-01',dueDate:'2026-09-10',currency:'TRY',totalMinor:80000,status:'open'},{id:'i2',counterpartyId:'c2',direction:'sales',invoiceDate:'2026-09-01',dueDate:'2026-09-30',currency:'TRY',totalMinor:20000,status:'open'}];
  const allocations=[{invoiceId:'i1',paymentId:'p1',amountMinor:30000}];
  const payments=[{id:'p1',paymentDate:'2026-09-12'}];
  const rows=customerPerformance({counterparties,invoices,allocations,payments,asOf:'2026-09-14',months:1});
  assert.equal(rows[0].name,'A'); assert.equal(rows[0].openMinor,50000); assert.equal(rows[0].overdueMinor,50000); assert.equal(rows[0].collectionRate,0.375);
  const c=concentrationRisk(rows); assert.equal(c.top1Share,0.8); assert.equal(c.top3Share,1); assert.equal(c.hhi,6800);
});

test('account balance trend produces month-end balances',()=>{
  const rows=accountBalanceTrend({asOf:'2026-09-14',months:2,currency:'TRY',accounts:[{currency:'TRY',openingMinor:100000}],payments:[{currency:'TRY',direction:'in',paymentDate:'2026-08-03',amountMinor:20000},{currency:'TRY',direction:'out',paymentDate:'2026-09-03',amountMinor:10000}]});
  assert.deepEqual(rows.map(x=>x.balanceMinor),[120000,110000]);
});

test('database management report integrates real persisted finance records',()=>{
  const db=new FinanceDb(':memory:');
  const cp=db.createCounterparty({name:'Aras',type:'customer'});
  const acc=db.createAccount({name:'Banka',type:'bank',openingMinor:100000});
  const inv=db.createInvoice({counterpartyId:cp.id,direction:'sales',invoiceDate:'2026-09-01',dueDate:'2026-09-10',currency:'TRY',totalMinor:50000});
  const pay=db.createPayment({counterpartyId:cp.id,accountId:acc.id,direction:'in',paymentDate:'2026-09-05',currency:'TRY',amountMinor:20000});
  db.allocatePayment({paymentId:pay.id,invoiceId:inv.id,amountMinor:20000});
  db.createExpense({expenseDate:'2026-09-06',category:'Kira',currency:'TRY',totalMinor:10000,status:'approved'});
  const r=db.getManagementReport('2026-09-14',1,'TRY');
  assert.equal(r.totals.revenueMinor,50000); assert.equal(r.totals.collectionsMinor,20000); assert.equal(r.totals.expenseMinor,10000); assert.equal(r.customers[0].openMinor,30000);
  db.close();
});
