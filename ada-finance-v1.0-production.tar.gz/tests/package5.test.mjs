import test from 'node:test';
import assert from 'node:assert/strict';
import {FinanceDb} from '../server/db.mjs';
import {extractExpenseProposal,parseBankStatementText} from '../src/document-extract.mjs';
const db=()=>new FinanceDb(':memory:');

test('expense extractor proposes date total tax and net from Turkish receipt text',()=>{
  const p=extractExpenseProposal('ABC TEKSTİL\nTarih: 14.09.2026\nKDV 250,00\nGENEL TOPLAM 1.250,00');
  assert.equal(p.date,'2026-09-14'); assert.equal(p.totalMinor,125000); assert.equal(p.taxMinor,25000); assert.equal(p.netMinor,100000); assert.ok(p.confidence>=.8);
});

test('document proposal becomes expense draft without posting payment',()=>{
  const d=db(); const doc=d.stageDocument({sourceName:'fis.txt',documentType:'expense_receipt',extractedText:'ABC\n14.09.2026\nKDV 20,00\nTOPLAM 120,00'}); const exp=d.createExpenseFromDocument(doc.id); assert.equal(exp.status,'draft'); assert.equal(exp.total_minor,12000); assert.equal(d.all('SELECT * FROM payments').length,0); d.close();
});

test('approved bank-paid expense posts exactly one outgoing payment',()=>{
  const d=db(); const a=d.createAccount({name:'Banka',type:'bank'}); const e=d.createExpense({expenseDate:'2026-09-14',category:'Malzeme',totalMinor:50000,paymentMode:'bank',accountId:a.id}); const out=d.reviewExpense(e.id,{decision:'approved'}); assert.equal(out.status,'paid'); const ps=d.all('SELECT * FROM payments'); assert.equal(ps.length,1); assert.equal(ps[0].direction,'out'); assert.equal(ps[0].amount_minor,50000); d.close();
});

test('approved payable expense creates payable, not immediate payment',()=>{
  const d=db(); const e=d.createExpense({expenseDate:'2026-09-14',category:'Kira',totalMinor:100000,paymentMode:'payable',dueDate:'2026-09-30'}); const out=d.reviewExpense(e.id,{decision:'approved'}); assert.equal(out.status,'approved'); assert.equal(d.all('SELECT * FROM payments').length,0); assert.equal(d.all('SELECT * FROM payables').length,1); d.close();
});

test('rejected expense creates no financial movement',()=>{
  const d=db(); const e=d.createExpense({expenseDate:'2026-09-14',category:'Diğer',totalMinor:10000}); const out=d.reviewExpense(e.id,{decision:'rejected'}); assert.equal(out.status,'rejected'); assert.equal(d.all('SELECT * FROM payments').length,0); assert.equal(d.all('SELECT * FROM payables').length,0); d.close();
});

test('bank PDF extracted text adapter parses transaction rows',()=>{
  const rows=parseBankStatementText('14.09.2026 ARAS KARGO F-10 +10.000,00\n15.09.2026 KİRA -25.000,00'); assert.equal(rows.length,2); assert.equal(rows[0].amountMinor,1000000); assert.equal(rows[0].direction,'in'); assert.equal(rows[1].direction,'out');
});

test('bank PDF text import remains in review queue',()=>{
  const d=db(); const b=d.createBankImportFromText({sourceName:'ekstre.pdf',text:'14.09.2026 ARAS KARGO +1.000,00'}); assert.equal(b.source_type,'pdf_text'); assert.equal(b.rows.length,1); assert.equal(b.rows[0].decision,'pending'); assert.equal(d.all('SELECT * FROM payments').length,0); d.close();
});

test('production job links material issue and finished goods receipt',()=>{
  const d=db(); const raw=d.createInventoryItem({sku:'HAM-1',name:'Kumaş',unit:'m2'}); const out=d.createInventoryItem({sku:'MAM-1',name:'Kargo Torbası',unit:'adet'}); d.addInventoryMovement({itemId:raw.id,movementDate:'2026-09-01',direction:'in',quantity:100}); const j=d.createProductionJob({jobNo:'U-001',outputItemId:out.id,plannedQty:10}); d.issueToProduction({jobId:j.id,itemId:raw.id,quantity:20,movementDate:'2026-09-14'}); d.receiveProduction({jobId:j.id,quantity:10,movementDate:'2026-09-14',complete:true}); const stock=Object.fromEntries(d.listInventory().map(x=>[x.sku,x.quantity])); assert.equal(stock['HAM-1'],80); assert.equal(stock['MAM-1'],10); const job=d.listProductionJobs()[0]; assert.equal(job.status,'completed'); assert.equal(job.produced_qty,10); d.close();
});
