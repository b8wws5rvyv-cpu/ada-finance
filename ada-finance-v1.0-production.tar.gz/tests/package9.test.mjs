import test from 'node:test';
import assert from 'node:assert/strict';
import {allocateMinorExact,netProfitabilityAnalysis} from '../src/finance-core.mjs';
import {FinanceDb} from '../server/db.mjs';

test('exact overhead allocation preserves every minor unit',()=>{
  const r=allocateMinorExact(100,[{orderId:'a',revenueMinor:1},{orderId:'b',revenueMinor:1},{orderId:'c',revenueMinor:1}],'revenue');
  assert.equal(r.allocations.reduce((s,x)=>s+x.amountMinor,0),100);
  assert.deepEqual(r.allocations.map(x=>x.amountMinor),[33,33,34]);
});

test('net profitability subtracts allocated overhead from gross profit',()=>{
  const r=netProfitabilityAnalysis({
    orders:[{id:'o1',counterpartyId:'c1'}],
    orderItems:[{orderId:'o1',productId:'p1',quantity:10,salesUnitMinor:1000,directUnitCostMinor:600}],
    counterparties:[{id:'c1',name:'Müşteri'}],products:[{id:'p1',name:'Ürün'}],
    overheadAllocations:[{orderId:'o1',amountMinor:1500}]
  });
  assert.equal(r.totals.grossProfitMinor,4000);
  assert.equal(r.totals.overheadMinor,1500);
  assert.equal(r.totals.netContributionMinor,2500);
});

test('package 9 cost center allocation and customer real profitability work',()=>{
  const db=new FinanceDb(':memory:');
  const u=db.createUser({email:'admin@test.local',displayName:'Admin',role:'admin',password:'password123'});
  const c=db.createCounterparty({name:'Aras Test',type:'customer'},u.id);
  const p=db.createProduct({name:'Cargo Bag',sku:'CB'},u.id);
  const o1=db.createOrder({counterpartyId:c.id,orderNo:'S-1',currency:'TRY',orderDate:'2026-09-05'},u.id);
  db.addOrderItem({orderId:o1.id,productId:p.id,quantity:100,salesUnitMinor:1000,directUnitCostMinor:600},u.id);
  const o2=db.createOrder({counterpartyId:c.id,orderNo:'S-2',currency:'TRY',orderDate:'2026-09-10'},u.id);
  db.addOrderItem({orderId:o2.id,productId:p.id,quantity:50,salesUnitMinor:1000,directUnitCostMinor:600},u.id);
  const e=db.createExpense({expenseDate:'2026-09-12',category:'Kira',currency:'TRY',totalMinor:15000,status:'approved'},u.id);
  const cc=db.createCostCenter({code:'GEN',name:'Genel Yönetim',defaultBasis:'revenue'},u.id);
  db.assignExpenseCostCenter({expenseId:e.id,costCenterId:cc.id,amountMinor:15000},u.id);
  const run=db.createCostAllocationRun({period:'2026-09',currency:'TRY'},u.id);
  assert.equal(run.total_overhead_minor,15000);
  assert.equal(run.allocated_minor,15000);
  assert.equal(run.unallocated_minor,0);
  const np=db.getNetProfitability('2026-09','TRY',run.id);
  assert.equal(np.totals.revenueMinor,150000);
  assert.equal(np.totals.directCostMinor,90000);
  assert.equal(np.totals.grossProfitMinor,60000);
  assert.equal(np.totals.overheadMinor,15000);
  assert.equal(np.totals.netContributionMinor,45000);
  assert.equal(np.byCustomer[0].netContributionMinor,45000);
  db.close();
});

test('cost center link can restrict an overhead pool to one order',()=>{
  const db=new FinanceDb(':memory:');
  const u=db.createUser({email:'admin2@test.local',displayName:'Admin',role:'admin',password:'password123'});
  const c=db.createCounterparty({name:'Müşteri',type:'customer'},u.id);
  const p=db.createProduct({name:'Ürün'},u.id);
  const o1=db.createOrder({counterpartyId:c.id,orderNo:'A',currency:'TRY',orderDate:'2026-09-01'},u.id);
  const o2=db.createOrder({counterpartyId:c.id,orderNo:'B',currency:'TRY',orderDate:'2026-09-02'},u.id);
  db.addOrderItem({orderId:o1.id,productId:p.id,quantity:1,salesUnitMinor:10000,directUnitCostMinor:4000},u.id);
  db.addOrderItem({orderId:o2.id,productId:p.id,quantity:1,salesUnitMinor:10000,directUnitCostMinor:4000},u.id);
  const e=db.createExpense({expenseDate:'2026-09-03',category:'Özel operasyon',currency:'TRY',totalMinor:2000,status:'approved'},u.id);
  const cc=db.createCostCenter({name:'Sipariş A operasyonu',defaultBasis:'equal'},u.id);
  db.assignExpenseCostCenter({expenseId:e.id,costCenterId:cc.id,amountMinor:2000},u.id);
  db.linkCostCenter({costCenterId:cc.id,entityType:'order',entityId:o1.id},u.id);
  const run=db.createCostAllocationRun({period:'2026-09',currency:'TRY'},u.id);
  const rows=run.allocations.filter(x=>x.order_id);
  assert.equal(rows.length,1);
  assert.equal(rows[0].order_id,o1.id);
  assert.equal(rows[0].amount_minor,2000);
  db.close();
});
