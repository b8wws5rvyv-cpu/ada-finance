import test from 'node:test';
import assert from 'node:assert/strict';
import {
  invoiceRemainingMinor,
  invoiceComputedStatus,
  payrollBreakdown,
  cashFlowProjection,
  agingBuckets,
} from '../src/finance-core.mjs';

test('partial invoice remaining and status', () => {
  const inv = {id:'i1', totalMinor:100000, dueDate:'2026-09-30', status:'open'};
  const allocations = [{invoiceId:'i1', amountMinor:25000}];
  assert.equal(invoiceRemainingMinor(inv, allocations), 75000);
  assert.equal(invoiceComputedStatus(inv, allocations, '2026-09-14'), 'partial');
});

test('overdue invoice status', () => {
  const inv = {id:'i1', totalMinor:100000, dueDate:'2026-09-01', status:'open'};
  assert.equal(invoiceComputedStatus(inv, [], '2026-09-14'), 'overdue');
});

test('Kudret debt is preserved instead of clamped to zero', () => {
  const b = payrollBreakdown({realSalaryMinor:3900000, bankSgkMinor:3988000});
  assert.equal(b.cashMinor, 0);
  assert.equal(b.employeeDebtMinor, 88000);
  assert.equal(b.netMinor, -88000);
});

test('cash-flow 30/60/90 includes receivable/payable/personnel', () => {
  const r = cashFlowProjection({
    openingByCurrency:{TRY:10000000},
    receivables:[{remainingMinor:5000000,currency:'TRY',dueDate:'2026-09-20'}],
    payables:[{remainingMinor:2000000,currency:'TRY',dueDate:'2026-09-25'}],
    personnel:[{bankAmountMinor:1000000,cashAmountMinor:500000,currency:'TRY',dueDate:'2026-09-30',status:'open'}],
    fromDate:'2026-09-14', horizons:[30]
  });
  assert.equal(r[30].TRY, 11500000);
});

test('aging buckets separate overdue bands', () => {
  const invoices = [
    {id:'a',direction:'sales',totalMinor:100,status:'open',dueDate:'2026-09-10'},
    {id:'b',direction:'sales',totalMinor:200,status:'open',dueDate:'2026-08-01'},
    {id:'c',direction:'sales',totalMinor:300,status:'open',dueDate:'2026-10-01'}
  ];
  const a = agingBuckets(invoices, [], '2026-09-14');
  assert.deepEqual(a,{not_due:300,'1_30':100,'31_60':200,'61_90':0,'90_plus':0});
});
