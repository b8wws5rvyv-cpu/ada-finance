import test from 'node:test';
import assert from 'node:assert/strict';
import {FinanceDb} from '../server/db.mjs';
import {parseBankCsv,suggestMatches} from '../src/bank-import.mjs';

const db=()=>new FinanceDb(':memory:');

test('bank CSV parser handles Turkish semicolon and decimal comma',()=>{
  const rows=parseBankCsv('Tarih;Açıklama;Tutar\n14.09.2026;ARAS KARGO;125.000,50');
  assert.equal(rows.length,1); assert.equal(rows[0].txnDate,'2026-09-14'); assert.equal(rows[0].amountMinor,12500050); assert.equal(rows[0].direction,'in');
});

test('bank matcher suggests counterparty and invoice',()=>{
  const row={description:'ARAS KARGO FAT F-100',reference:'',amountMinor:500000};
  const x=suggestMatches(row,{counterparties:[{id:'c1',name:'Aras Kargo'}],invoices:[{id:'i1',counterparty_id:'c1',number:'F-100',total_minor:500000,remaining_minor:500000,status:'open'}]});
  assert.equal(x.counterpartyId,'c1'); assert.equal(x.invoiceId,'i1'); assert.ok(x.confidence>.9);
});

test('bank import stays pending until human approval',()=>{
  const d=db(); const c=d.createCounterparty({name:'Aras Kargo'}); const a=d.createAccount({name:'Banka',type:'bank'}); const i=d.createInvoice({counterpartyId:c.id,direction:'sales',number:'F-1',invoiceDate:'2026-09-01',dueDate:'2026-09-14',totalMinor:1000000});
  const b=d.createBankImportBatch({accountId:a.id,sourceName:'x.csv',text:'Tarih;Açıklama;Tutar\n14.09.2026;ARAS KARGO F-1;10000,00'});
  assert.equal(b.rows[0].decision,'pending'); assert.equal(d.all('SELECT * FROM payments').length,0);
  d.decideBankImportRow(b.rows[0].id,{decision:'approved'},'u1');
  assert.equal(d.all('SELECT * FROM payments').length,1); assert.equal(d.one('SELECT decision FROM bank_import_rows WHERE id=?',b.rows[0].id).decision,'approved');
  assert.equal(d.getDashboard('2026-09-14').receivables.totalMinor,0); d.close();
});

test('rejected bank row never creates payment',()=>{
  const d=db(); const b=d.createBankImportBatch({sourceName:'x.csv',text:'Tarih;Açıklama;Tutar\n14.09.2026;Bilinmeyen;250,00'}); d.decideBankImportRow(b.rows[0].id,{decision:'rejected'}); assert.equal(d.all('SELECT * FROM payments').length,0); d.close();
});

test('document staging stores extraction without posting accounting record',()=>{
  const d=db(); const x=d.stageDocument({sourceName:'fis.jpg',mimeType:'image/jpeg',documentType:'expense_receipt',extractedText:'TOPLAM 1.250,00'}); assert.equal(x.status,'staged'); assert.equal(d.all('SELECT * FROM payments').length,0); d.close();
});

test('inventory balance derives from immutable movements',()=>{
  const d=db(); const i=d.createInventoryItem({sku:'KMS-01',name:'Kumaş',unit:'m2',minLevel:20}); d.addInventoryMovement({itemId:i.id,movementDate:'2026-09-01',direction:'in',quantity:100}); d.addInventoryMovement({itemId:i.id,movementDate:'2026-09-02',direction:'out',quantity:35}); const x=d.listInventory()[0]; assert.equal(x.quantity,65); d.close();
});
