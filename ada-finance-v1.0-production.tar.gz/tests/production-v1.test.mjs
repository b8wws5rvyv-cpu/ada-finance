import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {FinanceDb} from '../server/db.mjs';

function tempDb(){ const dir=fs.mkdtempSync(path.join(os.tmpdir(),'ada-v1-')); const file=path.join(dir,'db.sqlite'); return {dir,file,db:new FinanceDb(file)}; }

test('user management protects last active admin',()=>{const x=tempDb();try{const a=x.db.createUser({email:'admin@test',displayName:'Admin',role:'admin',password:'12345678'});assert.throws(()=>x.db.updateUser(a.id,{status:'disabled'},a.id),/LAST_ADMIN_PROTECTED/);const b=x.db.createUser({email:'admin2@test',displayName:'Admin 2',role:'admin',password:'12345678'},a.id);x.db.updateUser(a.id,{status:'disabled'},b.id);assert.equal(x.db.getUser(a.id).status,'disabled');}finally{x.db.close();fs.rmSync(x.dir,{recursive:true,force:true});}});

test('password reset revokes existing sessions',()=>{const x=tempDb();try{const a=x.db.createUser({email:'admin@test',displayName:'Admin',role:'admin',password:'12345678'});const login=x.db.login('admin@test','12345678');assert.ok(x.db.authenticate(login.token));x.db.resetUserPassword(a.id,'abcdefgh',a.id);assert.equal(x.db.authenticate(login.token),undefined);assert.ok(x.db.login('admin@test','abcdefgh'));}finally{x.db.close();fs.rmSync(x.dir,{recursive:true,force:true});}});

test('error log is persistent and readable',()=>{const x=tempDb();try{x.db.logError({method:'GET',path:'/bad',message:'boom'});const rows=x.db.listErrors();assert.equal(rows.length,1);assert.equal(rows[0].message,'boom');}finally{x.db.close();fs.rmSync(x.dir,{recursive:true,force:true});}});

test('backup history records sha and trigger',()=>{const x=tempDb();try{const r=x.db.recordBackup({fileName:'a.sqlite',filePath:'/tmp/a.sqlite',sizeBytes:12,sha256:'abc',triggerType:'manual'});assert.equal(r.trigger_type,'manual');assert.equal(x.db.listBackups()[0].sha256,'abc');}finally{x.db.close();fs.rmSync(x.dir,{recursive:true,force:true});}});

test('database production pragmas and integrity are healthy',()=>{const x=tempDb();try{assert.equal(x.db.quickCheck(),true);assert.equal(x.db.integrityCheck(),true);assert.equal(x.db.one('PRAGMA journal_mode').journal_mode,'wal');}finally{x.db.close();fs.rmSync(x.dir,{recursive:true,force:true});}});
