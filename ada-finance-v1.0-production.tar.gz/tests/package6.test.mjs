import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {FinanceDb} from '../server/db.mjs';

const db=()=>new FinanceDb(':memory:');

test('binary archive stores exact bytes and metadata',()=>{
  const d=db(); const buf=Buffer.from('ADA test belge','utf8');
  const f=d.storeFile({originalName:'fis.txt',mimeType:'text/plain',buffer:buf,category:'receipt'});
  const x=d.readFileBytes(f.id); assert.equal(x.meta.original_name,'fis.txt'); assert.deepEqual(x.buffer,buf); assert.equal(x.meta.size_bytes,buf.length); d.close();
});

test('text receipt upload extraction creates staging document, not accounting payment',()=>{
  const d=db(); const f=d.storeFile({originalName:'fis.txt',mimeType:'text/plain',buffer:Buffer.from('ABC MARKET\n14.09.2026\nKDV 20,00\nTOPLAM 120,00'),category:'receipt'});
  const j=d.createExtractionJob({fileId:f.id,purpose:'document'}); assert.equal(j.status,'completed');
  const docs=d.listStagedDocuments(); assert.equal(docs.length,1); assert.equal(docs[0].source_name,'fis.txt'); assert.equal(d.all('SELECT * FROM payments').length,0); d.close();
});

test('bank statement file extraction creates review batch and no payment',()=>{
  const d=db(); const f=d.storeFile({originalName:'ekstre.txt',mimeType:'text/plain',buffer:Buffer.from('14.09.2026 ARAS KARGO +1.000,00'),category:'bank_statement'});
  const j=d.createExtractionJob({fileId:f.id,purpose:'bank_statement'}); assert.equal(j.status,'completed');
  const batches=d.listBankImportBatches(); assert.equal(batches.length,1); const b=d.getBankImportBatch(batches[0].id); assert.equal(b.rows.length,1); assert.equal(b.rows[0].decision,'pending'); assert.equal(d.all('SELECT * FROM payments').length,0); d.close();
});

test('external extraction text can complete a pending OCR job',()=>{
  const d=db(); const f=d.storeFile({originalName:'scan.bin',mimeType:'application/octet-stream',buffer:Buffer.from([1,2,3]),category:'receipt'});
  const j=d.createExtractionJob({fileId:f.id,purpose:'document'}); assert.equal(j.status,'needs_external_ocr');
  const x=d.supplyExtractionText(j.id,'ABC\n14.09.2026\nTOPLAM 250,00'); assert.equal(x.status,'completed'); assert.equal(x.engine,'external'); assert.equal(d.listStagedDocuments().length,1); d.close();
});

test('dashboard operations metrics include expenses, pending extraction and low stock',()=>{
  const d=db(); const e=d.createExpense({expenseDate:'2026-09-14',category:'Kira',totalMinor:100000,status:'approved'}); assert.ok(e.id);
  d.createInventoryItem({sku:'A',name:'Kumaş',unit:'m2',minLevel:10});
  const f=d.storeFile({originalName:'x.bin',mimeType:'application/octet-stream',buffer:Buffer.from([7]),category:'document'}); d.createExtractionJob({fileId:f.id,purpose:'document'});
  const x=d.getDashboard('2026-09-14'); assert.equal(x.operations.monthExpenseMinor,100000); assert.equal(x.operations.lowStockCount,1); assert.equal(x.operations.pendingExtraction,1); d.close();
});
