import test from 'node:test';
import assert from 'node:assert/strict';
import {FinanceDb} from '../server/db.mjs';
import {can} from '../server/rbac.mjs';

function db(){return new FinanceDb(':memory:');}

test('bootstrap user login and session auth',()=>{const d=db();const u=d.createUser({email:'admin@ada.test',displayName:'Admin',role:'admin',password:'secret123'});assert.equal(d.userCount(),1);const x=d.login('admin@ada.test','secret123');assert.ok(x.token);const a=d.authenticate(x.token);assert.equal(a.id,u.id);assert.equal(a.role,'admin');d.close();});

test('wrong password rejected',()=>{const d=db();d.createUser({email:'a@b.com',displayName:'A',role:'admin',password:'right'});assert.equal(d.login('a@b.com','wrong'),null);d.close();});

test('role matrix enforces personnel isolation',()=>{assert.equal(can('personnel','personnel:write'),true);assert.equal(can('personnel','invoice:read'),false);assert.equal(can('viewer','invoice:read'),true);assert.equal(can('viewer','invoice:write'),false);});

test('counterparty archive is non destructive and audited',()=>{const d=db();const c=d.createCounterparty({name:'Test Müşteri'},'u1');assert.equal(d.listCounterparties().length,1);d.archiveCounterparty(c.id,'u1');assert.equal(d.listCounterparties().length,0);assert.ok(d.one('SELECT * FROM counterparties WHERE id=?',c.id).archived_at);const a=d.auditRows();assert.equal(a[0].action,'archive');d.close();});

test('invoice/payment allocation feeds dashboard receivable',()=>{const d=db();const c=d.createCounterparty({name:'Aras',type:'customer'});const a=d.createAccount({name:'Banka',type:'bank',openingMinor:100000});const i=d.createInvoice({counterpartyId:c.id,direction:'sales',number:'F1',invoiceDate:'2026-09-01',dueDate:'2026-09-10',totalMinor:500000});const p=d.createPayment({counterpartyId:c.id,accountId:a.id,direction:'in',paymentDate:'2026-09-12',amountMinor:200000});d.allocatePayment({paymentId:p.id,invoiceId:i.id,amountMinor:200000});const x=d.getDashboard('2026-09-14');assert.equal(x.receivables.totalMinor,300000);assert.equal(x.receivables.overdueMinor,300000);assert.equal(x.balances.TRY,300000);d.close();});

test('personnel obligation generation keeps Kudret debt',()=>{const d=db();const e=d.upsertEmployee({name:'Kudret',payCycle:'monthly',realSalaryMinor:3900000,bankSgkMinor:3988000,insured:true});const rows=d.generatePersonnelObligations('2026-09','2026-09-30');const k=rows.find(x=>x.employee_id===e.id);assert.equal(k.employee_debt_minor,88000);assert.equal(k.cash_amount_minor,0);assert.equal(k.net_minor,-88000);d.close();});

test('overtime, advance and deduction are included in obligation',()=>{const d=db();const e=d.upsertEmployee({name:'Begmyrat',payCycle:'monthly',realSalaryMinor:5000000,bankSgkMinor:3988000,insured:true});d.addPersonnelAdjustment({employeeId:e.id,period:'2026-09',type:'overtime',hours:6,rateMinor:15000,amountMinor:90000});d.addPersonnelAdjustment({employeeId:e.id,period:'2026-09',type:'advance',amountMinor:200000});d.addPersonnelAdjustment({employeeId:e.id,period:'2026-09',type:'deduction',amountMinor:50000});const [x]=d.generatePersonnelObligations('2026-09','2026-09-30');assert.equal(x.cash_amount_minor,852000);d.close();});

test('legacy importer carries core finance/personnel records',()=>{const d=db();const state={cariler:[{id:'c1',unvan:'Müşteri A',tur:'musteri',paraBirimi:'TRY',vade:30,yetkili:'Ali'}],hesaplar:[{id:'h1',ad:'Banka',tur:'banka',paraBirimi:'TRY',acilis:1000}],faturalar:[{id:'f1',cariId:'c1',yon:'satis',no:'F1',tarih:'2026-09-01',vade:'2026-09-30',paraBirimi:'TRY',toplam:500}],kasaHareketleri:[{id:'k1',cariId:'c1',hesapId:'h1',faturaId:'f1',yon:'giris',tarih:'2026-09-10',paraBirimi:'TRY',tutar:100}],personel:[{id:'p1',ad:'Kudret',odemeTipi:'aylik',gercekMaas:39000,sgkMaas:39880,sigorta:true}],hareketler:[{personelId:'p1',tip:'mesai',ay:'2026-09',saat:2,saatUcreti:150,tutar:300}]};const s=d.importLegacy(state);assert.deepEqual(s,{counterparties:1,contacts:1,accounts:1,invoices:1,payments:1,employees:1,adjustments:1});const dash=d.getDashboard('2026-09-14');assert.equal(dash.receivables.totalMinor,40000);assert.equal(d.listEmployees()[0].real_salary_minor,3900000);d.close();});

test('customer 360 returns opportunity company id and finance totals',()=>{const d=db();const c=d.createCounterparty({name:'Kolay Gelsin',opportunityCompanyId:'opp-kg'});d.createInvoice({counterpartyId:c.id,direction:'sales',invoiceDate:'2026-09-01',dueDate:'2026-09-10',totalMinor:100000});const x=d.getCounterparty360(c.id,'2026-09-14');assert.equal(x.opportunityCompanyId,'opp-kg');assert.equal(x.openReceivableMinor,100000);assert.equal(x.overdueMinor,100000);d.close();});
