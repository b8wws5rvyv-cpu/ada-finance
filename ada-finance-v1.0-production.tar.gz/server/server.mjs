import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {FinanceDb} from './db.mjs';
import {requirePermission} from './rbac.mjs';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(__dirname,'..');
const dbFile=process.env.ADA_DB || path.resolve(root,'data/ada-finance.sqlite');
fs.mkdirSync(path.dirname(dbFile),{recursive:true});
const db=new FinanceDb(dbFile);
const PORT=Number(process.env.PORT)||8080;
const VERSION='1.0.0';
const AUTO_BACKUP_HOUR=Math.max(0,Math.min(23,Number(process.env.ADA_AUTO_BACKUP_HOUR ?? 3)));
const loginAttempts=new Map();

const securityHeaders={'x-content-type-options':'nosniff','x-frame-options':'DENY','referrer-policy':'no-referrer','permissions-policy':'camera=(), microphone=(), geolocation=()','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"};
const json=(res,status,obj)=>{res.writeHead(status,{...securityHeaders,'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(obj));};
const text=(res,status,body,type='text/plain; charset=utf-8')=>{res.writeHead(status,{...securityHeaders,'content-type':type});res.end(body);};
const body=async req=>{let s='';for await(const c of req){s+=c;if(s.length>2_000_000)throw Object.assign(new Error('BODY_TOO_LARGE'),{statusCode:413});}return s?JSON.parse(s):{};};
const rawBody=async(req,max=15_000_000)=>{const chunks=[];let n=0;for await(const c of req){n+=c.length;if(n>max)throw Object.assign(new Error('FILE_TOO_LARGE'),{statusCode:413});chunks.push(c);}return Buffer.concat(chunks);};
const bearer=req=>{const h=req.headers.authorization||'';return h.startsWith('Bearer ')?h.slice(7):null;};
const auth=req=>db.authenticate(bearer(req));
const today=()=>new Date().toISOString().slice(0,10);
const clientKey=req=>`${req.socket.remoteAddress||'ip'}|${(req.headers['x-forwarded-for']||'').toString().split(',')[0].trim()}`;
function loginAllowed(req,email){ const key=clientKey(req)+'|'+String(email||'').toLowerCase(); const x=loginAttempts.get(key); if(!x)return true; if(Date.now()-x.first>10*60_000){loginAttempts.delete(key);return true;} return x.count<5; }
function loginFailed(req,email){ const key=clientKey(req)+'|'+String(email||'').toLowerCase(),now=Date.now(),x=loginAttempts.get(key); if(!x||now-x.first>10*60_000)loginAttempts.set(key,{count:1,first:now}); else x.count++; }
function loginClear(req,email){ loginAttempts.delete(clientKey(req)+'|'+String(email||'').toLowerCase()); }
function runBackup(trigger='manual'){ const r=spawnSync(process.execPath,[path.resolve(root,'scripts/backup-db.mjs')],{env:{...process.env,ADA_DB:dbFile,ADA_BACKUP_TRIGGER:trigger},encoding:'utf8',timeout:120000}); if(r.status!==0)throw new Error(`BACKUP_FAILED: ${r.stderr||r.stdout}`); try{return JSON.parse(r.stdout)}catch{return {ok:true,output:r.stdout.trim()};} }

function serveStatic(res,urlPath){
  const rel=urlPath==='/'?'ui/index.html':urlPath.replace(/^\//,'');
  const full=path.resolve(root,rel);
  if(!full.startsWith(root)||!fs.existsSync(full)||fs.statSync(full).isDirectory()) return false;
  const ext=path.extname(full); const types={'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8'};
  text(res,200,fs.readFileSync(full),types[ext]||'application/octet-stream'); return true;
}

const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,`http://${req.headers.host||'localhost'}`), p=u.pathname;
    if(p==='/api/health') return json(res,200,{ok:true,version:VERSION});
    if(p==='/api/ready') return json(res,db.quickCheck()?200:503,{ok:db.quickCheck(),version:VERSION,database:path.basename(dbFile)});
    if(p==='/api/bootstrap-status') return json(res,200,{needsBootstrap:db.userCount()===0});
    if(p==='/api/bootstrap'&&req.method==='POST'){
      if(db.userCount()!==0) return json(res,409,{error:'ALREADY_BOOTSTRAPPED'});
      const b=await body(req); if(!b.email||!b.displayName||!b.password) return json(res,400,{error:'MISSING_FIELDS'});
      if(String(b.password).length<8) return json(res,400,{error:'PASSWORD_TOO_SHORT'});
      db.createUser({email:b.email,displayName:b.displayName,role:'admin',password:b.password}); return json(res,201,{ok:true});
    }
    if(p==='/api/login'&&req.method==='POST'){ const b=await body(req); if(!loginAllowed(req,b.email))return json(res,429,{error:'TOO_MANY_ATTEMPTS'}); const x=db.login(b.email||'',b.password||''); if(x){loginClear(req,b.email);return json(res,200,x);} loginFailed(req,b.email); return json(res,401,{error:'INVALID_CREDENTIALS'}); }
    if(p.startsWith('/api/')){
      const user=auth(req); if(!user) return json(res,401,{error:'UNAUTHENTICATED'});
      if(p==='/api/me') return json(res,200,{id:user.id,email:user.email,displayName:user.display_name,role:user.role});
      if(p==='/api/logout'&&req.method==='POST'){ db.logout(bearer(req)); return json(res,200,{ok:true}); }
      if(p==='/api/users'&&req.method==='GET'){ requirePermission(user,'user:manage'); return json(res,200,db.listUsers()); }
      if(p==='/api/users'&&req.method==='POST'){ requirePermission(user,'user:manage'); const b=await body(req); if(!b.email||!b.displayName||!b.password)return json(res,400,{error:'MISSING_FIELDS'}); if(String(b.password).length<8)return json(res,400,{error:'PASSWORD_TOO_SHORT'}); return json(res,201,db.createUser(b,user.id)); }
      const uu=p.match(/^\/api\/users\/([^/]+)$/); if(uu&&req.method==='PATCH'){ requirePermission(user,'user:manage'); return json(res,200,db.updateUser(uu[1],await body(req),user.id)); }
      const ur=p.match(/^\/api\/users\/([^/]+)\/reset-password$/); if(ur&&req.method==='POST'){ requirePermission(user,'user:manage'); const b=await body(req); db.resetUserPassword(ur[1],b.password||'',user.id); return json(res,200,{ok:true}); }
      const us=p.match(/^\/api\/users\/([^/]+)\/revoke-sessions$/); if(us&&req.method==='POST'){ requirePermission(user,'user:manage'); return json(res,200,{ok:true,revoked:db.revokeAllSessions(us[1],user.id)}); }
      if(p==='/api/backups'&&req.method==='GET'){ requirePermission(user,'backup:manage'); return json(res,200,db.listBackups(Number(u.searchParams.get('limit'))||100)); }
      if(p==='/api/backups'&&req.method==='POST'){ requirePermission(user,'backup:manage'); const x=runBackup('manual'); return json(res,201,x); }
      const bd=p.match(/^\/api\/backups\/([^/]+)\/download$/); if(bd&&req.method==='GET'){ requirePermission(user,'backup:manage'); const x=db.getBackup(bd[1]); if(!x||!fs.existsSync(x.file_path))return json(res,404,{error:'NOT_FOUND'}); const st=fs.statSync(x.file_path); res.writeHead(200,{...securityHeaders,'content-type':'application/vnd.sqlite3','content-length':st.size,'content-disposition':`attachment; filename*=UTF-8''${encodeURIComponent(x.file_name)}`,'cache-control':'private, no-store'}); return fs.createReadStream(x.file_path).pipe(res); }
      if(p==='/api/errors'&&req.method==='GET'){ requirePermission(user,'audit:read'); return json(res,200,db.listErrors(Number(u.searchParams.get('limit'))||200)); }

      if(p==='/api/dashboard'&&req.method==='GET'){ requirePermission(user,'dashboard:read'); return json(res,200,db.getDashboard(u.searchParams.get('asOf')||today())); }
      if(p==='/api/reports/management'&&req.method==='GET'){ requirePermission(user,'dashboard:read'); return json(res,200,db.getManagementReport(u.searchParams.get('asOf')||today(),Number(u.searchParams.get('months'))||12,u.searchParams.get('currency')||'TRY')); }
      if(p==='/api/planning/cash-13-week'&&req.method==='GET'){ requirePermission(user,'dashboard:read'); const sc={bad:Number(u.searchParams.get('bad'))||0.5,base:Number(u.searchParams.get('base'))||0.8,good:Number(u.searchParams.get('good'))||1}; return json(res,200,db.getCashPlan13(u.searchParams.get('asOf')||today(),u.searchParams.get('currency')||'TRY',sc)); }
      if(p==='/api/profitability'&&req.method==='GET'){ requirePermission(user,'dashboard:read'); return json(res,200,db.getProfitability()); }
      if(p==='/api/cost-centers'&&req.method==='GET'){ requirePermission(user,'cost:read'); return json(res,200,db.listCostCenters()); }
      if(p==='/api/cost-centers'&&req.method==='POST'){ requirePermission(user,'cost:write'); return json(res,201,db.createCostCenter(await body(req),user.id)); }
      if(p==='/api/cost-centers/assign-expense'&&req.method==='POST'){ requirePermission(user,'cost:write'); return json(res,201,db.assignExpenseCostCenter(await body(req),user.id)); }
      if(p==='/api/cost-centers/link'&&req.method==='POST'){ requirePermission(user,'cost:write'); return json(res,201,db.linkCostCenter(await body(req),user.id)); }
      if(p==='/api/cost-centers/report'&&req.method==='GET'){ requirePermission(user,'cost:read'); return json(res,200,db.getCostCenterPeriodReport(u.searchParams.get('period')||today().slice(0,7),u.searchParams.get('currency')||'TRY')); }
      if(p==='/api/cost-allocation-runs'&&req.method==='GET'){ requirePermission(user,'cost:read'); return json(res,200,db.listCostAllocationRuns()); }
      if(p==='/api/cost-allocation-runs'&&req.method==='POST'){ requirePermission(user,'cost:write'); return json(res,201,db.createCostAllocationRun(await body(req),user.id)); }
      if(p==='/api/net-profitability'&&req.method==='GET'){ requirePermission(user,'cost:read'); return json(res,200,db.getNetProfitability(u.searchParams.get('period')||today().slice(0,7),u.searchParams.get('currency')||'TRY',u.searchParams.get('runId')||null)); }
      if(p==='/api/orders'&&req.method==='GET'){ requirePermission(user,'invoice:read'); return json(res,200,db.listOrders()); }
      if(p==='/api/orders'&&req.method==='POST'){ requirePermission(user,'invoice:write'); return json(res,201,db.createOrder(await body(req),user.id)); }
      if(p==='/api/order-items'&&req.method==='POST'){ requirePermission(user,'invoice:write'); return json(res,201,db.addOrderItem(await body(req),user.id)); }
      if(p==='/api/products'&&req.method==='GET'){ requirePermission(user,'inventory:read'); return json(res,200,db.listProducts()); }
      if(p==='/api/products'&&req.method==='POST'){ requirePermission(user,'inventory:write'); return json(res,201,db.createProduct(await body(req),user.id)); }
      if(p==='/api/budgets'&&req.method==='GET'){ requirePermission(user,'dashboard:read'); return json(res,200,db.listBudgetPlans()); }
      if(p==='/api/budgets'&&req.method==='POST'){ requirePermission(user,'expense:write'); return json(res,201,db.createBudgetPlan(await body(req),user.id)); }
      if(p==='/api/budget-lines'&&req.method==='POST'){ requirePermission(user,'expense:write'); return json(res,201,db.upsertBudgetLine(await body(req),user.id)); }
      const br=p.match(/^\/api\/budgets\/([^/]+)\/report$/); if(br&&req.method==='GET'){ requirePermission(user,'dashboard:read'); const x=db.getBudgetReport(br[1],u.searchParams.get('asOf')||today()); return x?json(res,200,x):json(res,404,{error:'NOT_FOUND'}); }
      if(p==='/api/counterparties'&&req.method==='GET'){ requirePermission(user,'counterparty:read'); return json(res,200,db.listCounterparties()); }
      if(p==='/api/counterparties'&&req.method==='POST'){ requirePermission(user,'counterparty:write'); return json(res,201,db.createCounterparty(await body(req),user.id)); }
      const m360=p.match(/^\/api\/counterparties\/([^/]+)\/360$/); if(m360&&req.method==='GET'){ requirePermission(user,'counterparty:read'); const x=db.getCounterparty360(m360[1],u.searchParams.get('asOf')||today()); return x?json(res,200,x):json(res,404,{error:'NOT_FOUND'}); }
      const march=p.match(/^\/api\/counterparties\/([^/]+)\/archive$/); if(march&&req.method==='POST'){ requirePermission(user,'counterparty:write'); return json(res,db.archiveCounterparty(march[1],user.id)?200:404,{ok:true}); }
      if(p==='/api/invoices'&&req.method==='POST'){ requirePermission(user,'invoice:write'); return json(res,201,db.createInvoice(await body(req),user.id)); }
      if(p==='/api/accounts'&&req.method==='POST'){ requirePermission(user,'account:write'); return json(res,201,db.createAccount(await body(req),user.id)); }
      if(p==='/api/payments'&&req.method==='POST'){ requirePermission(user,'payment:write'); return json(res,201,db.createPayment(await body(req),user.id)); }
      if(p==='/api/payment-allocations'&&req.method==='POST'){ requirePermission(user,'payment:write'); return json(res,201,db.allocatePayment(await body(req),user.id)); }
      if(p==='/api/payables'&&req.method==='POST'){ requirePermission(user,'payable:write'); return json(res,201,db.createPayable(await body(req),user.id)); }
      if(p==='/api/employees'&&req.method==='GET'){ requirePermission(user,'personnel:read'); return json(res,200,db.listEmployees()); }
      if(p==='/api/employees'&&req.method==='POST'){ requirePermission(user,'personnel:write'); return json(res,201,db.upsertEmployee(await body(req),user.id)); }
      if(p==='/api/personnel-adjustments'&&req.method==='POST'){ requirePermission(user,'personnel:write'); return json(res,201,db.addPersonnelAdjustment(await body(req),user.id)); }
      if(p==='/api/personnel-obligations/generate'&&req.method==='POST'){ requirePermission(user,'personnel:write'); const b=await body(req); return json(res,200,db.generatePersonnelObligations(b.period,b.dueDate,user.id)); }
      if(p==='/api/accounts'&&req.method==='GET'){ requirePermission(user,'account:read'); return json(res,200,db.listAccounts()); }
      if(p==='/api/invoices'&&req.method==='GET'){ requirePermission(user,'invoice:read'); return json(res,200,db.listInvoices()); }
      if(p==='/api/bank-imports'&&req.method==='GET'){ requirePermission(user,'bank_import:read'); return json(res,200,db.listBankImportBatches()); }
      if(p==='/api/bank-imports'&&req.method==='POST'){ requirePermission(user,'bank_import:write'); return json(res,201,db.createBankImportBatch(await body(req),user.id)); }
      if(p==='/api/bank-imports/pdf-text'&&req.method==='POST'){ requirePermission(user,'bank_import:write'); return json(res,201,db.createBankImportFromText(await body(req),user.id)); }
      const mb=p.match(/^\/api\/bank-imports\/([^/]+)$/); if(mb&&req.method==='GET'){ requirePermission(user,'bank_import:read'); const x=db.getBankImportBatch(mb[1]); return x?json(res,200,x):json(res,404,{error:'NOT_FOUND'}); }
      const mr=p.match(/^\/api\/bank-import-rows\/([^/]+)\/decision$/); if(mr&&req.method==='POST'){ requirePermission(user,'bank_import:write'); const x=db.decideBankImportRow(mr[1],await body(req),user.id); return x?json(res,200,x):json(res,404,{error:'NOT_FOUND'}); }
      if(p==='/api/files'&&req.method==='GET'){ requirePermission(user,'document:read'); return json(res,200,db.listFiles(Number(u.searchParams.get('limit'))||100)); }
      if(p==='/api/files/upload'&&req.method==='POST'){ requirePermission(user,'document:write'); const buf=await rawBody(req); const originalName=decodeURIComponent(req.headers['x-file-name']||'dosya'); const mimeType=req.headers['content-type']||'application/octet-stream'; const category=req.headers['x-file-category']||'document'; const f=db.storeFile({originalName,mimeType,buffer:buf,category},user.id); let job=null; if(req.headers['x-auto-extract']!=='0') job=db.createExtractionJob({fileId:f.id,purpose:req.headers['x-extract-purpose']|| (category==='bank_statement'?'bank_statement':'document')},user.id); return json(res,201,{file:f,extraction:job}); }
      const fd=p.match(/^\/api\/files\/([^/]+)\/download$/); if(fd&&req.method==='GET'){ requirePermission(user,'document:read'); const x=db.readFileBytes(fd[1]); if(!x)return json(res,404,{error:'NOT_FOUND'}); res.writeHead(200,{'content-type':x.meta.mime_type,'content-length':x.buffer.length,'content-disposition':`attachment; filename*=UTF-8''${encodeURIComponent(x.meta.original_name)}`,'cache-control':'private, no-store'}); return res.end(x.buffer); }
      if(p==='/api/extractions'&&req.method==='GET'){ requirePermission(user,'document:read'); return json(res,200,db.listExtractionJobs(Number(u.searchParams.get('limit'))||100)); }
      const xr=p.match(/^\/api\/extractions\/([^/]+)\/run$/); if(xr&&req.method==='POST'){ requirePermission(user,'document:write'); const x=db.runExtractionJob(xr[1],user.id); return x?json(res,200,x):json(res,404,{error:'NOT_FOUND'}); }
      const xt=p.match(/^\/api\/extractions\/([^/]+)\/text$/); if(xt&&req.method==='POST'){ requirePermission(user,'document:write'); const b=await body(req); const x=db.supplyExtractionText(xt[1],b.text||'',user.id); return x?json(res,200,x):json(res,404,{error:'NOT_FOUND'}); }
      if(p==='/api/documents/staging'&&req.method==='GET'){ requirePermission(user,'document:read'); return json(res,200,db.listStagedDocuments()); }
      if(p==='/api/documents/staging'&&req.method==='POST'){ requirePermission(user,'document:write'); return json(res,201,db.stageDocument(await body(req),user.id)); }
      const da=p.match(/^\/api\/documents\/staging\/([^/]+)\/analyze$/); if(da&&req.method==='POST'){ requirePermission(user,'document:write'); const x=db.analyzeStagedDocument(da[1],user.id); return x?json(res,200,x):json(res,404,{error:'NOT_FOUND'}); }
      const de=p.match(/^\/api\/documents\/staging\/([^/]+)\/expense$/); if(de&&req.method==='POST'){ requirePermission(user,'expense:write'); const x=db.createExpenseFromDocument(de[1],await body(req),user.id); return x?json(res,201,x):json(res,404,{error:'NOT_FOUND'}); }
      if(p==='/api/expenses'&&req.method==='GET'){ requirePermission(user,'expense:read'); return json(res,200,db.listExpenses()); }
      if(p==='/api/expenses'&&req.method==='POST'){ requirePermission(user,'expense:write'); return json(res,201,db.createExpense(await body(req),user.id)); }
      const er=p.match(/^\/api\/expenses\/([^/]+)\/review$/); if(er&&req.method==='POST'){ requirePermission(user,'expense:write'); const x=db.reviewExpense(er[1],await body(req),user.id); return x?json(res,200,x):json(res,404,{error:'NOT_FOUND'}); }
      if(p==='/api/inventory'&&req.method==='GET'){ requirePermission(user,'inventory:read'); return json(res,200,db.listInventory()); }
      if(p==='/api/inventory'&&req.method==='POST'){ requirePermission(user,'inventory:write'); return json(res,201,db.createInventoryItem(await body(req),user.id)); }
      if(p==='/api/inventory/movements'&&req.method==='POST'){ requirePermission(user,'inventory:write'); return json(res,201,db.addInventoryMovement(await body(req),user.id)); }
      if(p==='/api/production-jobs'&&req.method==='GET'){ requirePermission(user,'production:read'); return json(res,200,db.listProductionJobs()); }
      if(p==='/api/production-jobs'&&req.method==='POST'){ requirePermission(user,'production:write'); return json(res,201,db.createProductionJob(await body(req),user.id)); }
      const pi=p.match(/^\/api\/production-jobs\/([^/]+)\/issue$/); if(pi&&req.method==='POST'){ requirePermission(user,'production:write'); const b=await body(req); return json(res,201,db.issueToProduction({...b,jobId:pi[1]},user.id)); }
      const pr=p.match(/^\/api\/production-jobs\/([^/]+)\/receive$/); if(pr&&req.method==='POST'){ requirePermission(user,'production:write'); const b=await body(req); return json(res,201,db.receiveProduction({...b,jobId:pr[1]},user.id)); }
      if(p==='/api/audit'&&req.method==='GET'){ requirePermission(user,'audit:read'); return json(res,200,db.auditRows(Number(u.searchParams.get('limit'))||200)); }
      return json(res,404,{error:'NOT_FOUND'});
    }
    if(!serveStatic(res,p)) json(res,404,{error:'NOT_FOUND'});
  }catch(e){ console.error(e); try{ const u=auth(req); db.logError({userId:u?.id||null,method:req.method,path:req.url,code:e.code||null,message:e.message||'SERVER_ERROR',stack:process.env.NODE_ENV==='production'?null:e.stack}); }catch{} json(res,e.statusCode||500,{error:e.message||'SERVER_ERROR'}); }
});
let lastBackupDate='';
const backupTimer=setInterval(()=>{ const n=new Date(); const d=n.toISOString().slice(0,10); if(n.getHours()===AUTO_BACKUP_HOUR && d!==lastBackupDate){ try{runBackup('scheduled');lastBackupDate=d;console.log('Scheduled backup completed',d);}catch(e){console.error('Scheduled backup failed',e);} } },15*60_000);
backupTimer.unref();
const cleanupTimer=setInterval(()=>{try{db.cleanupSessions();}catch(e){console.error('Session cleanup failed',e);}},6*60*60_000); cleanupTimer.unref();
function shutdown(sig){ console.log('Shutdown',sig); clearInterval(backupTimer); clearInterval(cleanupTimer); try{db.close();}catch{} server.close(()=>process.exit(0)); setTimeout(()=>process.exit(1),5000).unref(); }
process.on('SIGTERM',()=>shutdown('SIGTERM')); process.on('SIGINT',()=>shutdown('SIGINT'));
server.listen(PORT,()=>console.log(`ADA Finance & Operations v${VERSION} http://localhost:${PORT}`));
