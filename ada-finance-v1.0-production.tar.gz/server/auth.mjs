import {randomBytes, scryptSync, timingSafeEqual, createHash} from 'node:crypto';

export const nowIso = () => new Date().toISOString();
export const id = (p='id') => `${p}_${Date.now().toString(36)}_${randomBytes(4).toString('hex')}`;

export function hashPassword(password, salt = randomBytes(16).toString('hex')) {
  const hash = scryptSync(String(password), salt, 64).toString('hex');
  return {salt, hash};
}
export function verifyPassword(password, salt, expectedHex) {
  const actual = scryptSync(String(password), salt, 64);
  const expected = Buffer.from(expectedHex, 'hex');
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
export function tokenHash(token) { return createHash('sha256').update(token).digest('hex'); }
export function createToken() { return randomBytes(32).toString('hex'); }
