const grants = {
  admin: new Set(['*']),
  accounting: new Set([
    'dashboard:read','counterparty:read','counterparty:write','invoice:read','invoice:write','payment:read','payment:write',
    'payable:read','payable:write','account:read','account:write','personnel:read','personnel:write','audit:read','integration:read','integration:write','bank_import:read','bank_import:write','document:read','document:write','inventory:read','inventory:write','expense:read','expense:write','production:read','production:write','cost:read','cost:write'
  ]),
  personnel: new Set(['dashboard:payroll','personnel:read','personnel:write']),
  viewer: new Set(['dashboard:read','counterparty:read','invoice:read','payment:read','payable:read','account:read','personnel:read','integration:read','bank_import:read','document:read','inventory:read','expense:read','production:read','cost:read'])
};
export function can(role, permission) {
  const set = grants[role] || new Set();
  return set.has('*') || set.has(permission);
}
export function requirePermission(user, permission) {
  if (!user || !can(user.role, permission)) {
    const e = new Error('FORBIDDEN'); e.statusCode = 403; throw e;
  }
}
