import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {fileURLToPath} from 'node:url';
import {id, nowIso, hashPassword, verifyPassword, tokenHash, createToken} from './auth.mjs';
import {buildPersonnelObligation, dashboardSummary, receivablesSummary, cashFlowProjection, customer360, payablesCalendar, managementMonthlySeries, expenseBreakdown, customerPerformance, concentrationRisk, accountBalanceTrend, monthRange, budgetVsActual, profitabilityAnalysis, thirteenWeekCashFlow, allocateMinorExact, netProfitabilityAnalysis} from '../src/finance-core.mjs';
import {parseBankCsv, suggestMatches} from '../src/bank-import.mjs';
import {extractExpenseProposal, parseBankStatementText} from '../src/document-extract.mjs';
import {extractFileText} from '../src/file-extract.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const schemaPath = path.resolve(__dirname, '../db/schema.sql');
const qMarks = n => Array(n).fill('?').join(',');
const toMinor = v => Math.round((Number(v)||0)*100);
const fromDbBool = v => !!v;

export class FinanceDb {
  constructor(filename=':memory:') {
    this.db = new DatabaseSync(filename);
    this.db.exec('PRAGMA foreign_keys = ON;');
    this.db.exec('PRAGMA journal_mode = WAL;');
    this.db.exec('PRAGMA busy_timeout = 5000;');
    this.db.exec(fs.readFileSync(schemaPath,'utf8'));
    this.ensurePackage5Schema();
    this.storageRoot = filename===':memory:' ? path.resolve(__dirname,'../data/test-uploads') : path.resolve(path.dirname(filename),'uploads');
    fs.mkdirSync(this.storageRoot,{recursive:true});
  }
  ensurePackage5Schema(){
    const cols=this.all(`PRAGMA table_info(inventory_movements)`).map(x=>x.name);
    if(!cols.includes('source_type')) this.db.exec(`ALTER TABLE inventory_movements ADD COLUMN source_type TEXT`);
    if(!cols.includes('source_id')) this.db.exec(`ALTER TABLE inventory_movements ADD COLUMN source_id TEXT`);
  }
  close(){ this.db.close(); }
  tx(fn){ this.db.exec('BEGIN IMMEDIATE'); try{ const x=fn(); this.db.exec('COMMIT'); return x; } catch(e){ this.db.exec('ROLLBACK'); throw e; } }
  one(sql,...params){ return this.db.prepare(sql).get(...params); }
  all(sql,...params){ return this.db.prepare(sql).all(...params); }
  run(sql,...params){ return this.db.prepare(sql).run(...params); }
  audit({userId=null,action,entityType,entityId=null,before=null,after=null}){
    this.run(`INSERT INTO audit_log(id,user_id,action,entity_type,entity_id,before_json,after_json,created_at) VALUES(?,?,?,?,?,?,?,?)`,
      id('aud'),userId,action,entityType,entityId,before?JSON.stringify(before):null,after?JSON.stringify(after):null,nowIso());
  }
  userCount(){ return Number(this.one('SELECT COUNT(*) n FROM users WHERE archived_at IS NULL')?.n||0); }
  createUser({email,displayName,role='viewer',password}, actorId=null){
    const ts=nowIso(), uid=id('usr'), {salt,hash}=hashPassword(password);
    this.run(`INSERT INTO users(id,email,display_name,role,password_salt,password_hash,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)`,uid,email.trim(),displayName.trim(),role,salt,hash,'active',ts,ts);
    const u=this.getUser(uid); this.audit({userId:actorId,action:'create',entityType:'user',entityId:uid,after:{email:u.email,displayName:u.display_name,role:u.role}}); return u;
  }
  getUser(uid){ return this.one('SELECT * FROM users WHERE id=? AND archived_at IS NULL',uid); }
  login(email,password){
    const u=this.one("SELECT * FROM users WHERE email=? COLLATE NOCASE AND archived_at IS NULL AND status='active'",email.trim());
    if(!u || !verifyPassword(password,u.password_salt,u.password_hash)) return null;
    const token=createToken(), sid=id('ses'), created=nowIso(), exp=new Date(Date.now()+7*86400000).toISOString();
    this.run('INSERT INTO sessions(id,user_id,token_hash,created_at,expires_at) VALUES(?,?,?,?,?)',sid,u.id,tokenHash(token),created,exp);
    return {token,user:{id:u.id,email:u.email,displayName:u.display_name,role:u.role},expiresAt:exp};
  }
  authenticate(token){
    if(!token) return null;
    return this.one(`SELECT u.id,u.email,u.display_name,u.role FROM sessions s JOIN users u ON u.id=s.user_id
      WHERE s.token_hash=? AND s.revoked_at IS NULL AND s.expires_at>? AND u.status='active' AND u.archived_at IS NULL`, tokenHash(token), nowIso());
  }
  listUsers(){ return this.all(`SELECT id,email,display_name,role,status,created_at,updated_at,archived_at FROM users WHERE archived_at IS NULL ORDER BY display_name,email`); }
  updateUser(uid,{displayName,role,status},actorId=null){
    const before=this.getUser(uid); if(!before)return null; const ts=nowIso();
    const nextName=displayName??before.display_name, nextRole=role??before.role, nextStatus=status??before.status;
    if(!['admin','accounting','personnel','viewer'].includes(nextRole)) throw Object.assign(new Error('INVALID_ROLE'),{statusCode:400});
    if(!['active','disabled'].includes(nextStatus)) throw Object.assign(new Error('INVALID_STATUS'),{statusCode:400});
    if(before.role==='admin' && (nextRole!=='admin'||nextStatus!=='active') && this.activeAdminCount()<=1) throw Object.assign(new Error('LAST_ADMIN_PROTECTED'),{statusCode:409});
    this.run(`UPDATE users SET display_name=?,role=?,status=?,updated_at=? WHERE id=?`,nextName,nextRole,nextStatus,ts,uid);
    if(nextStatus==='disabled') this.run(`UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL`,ts,uid);
    const after=this.getUser(uid); this.audit({userId:actorId,action:'update',entityType:'user',entityId:uid,before:{displayName:before.display_name,role:before.role,status:before.status},after:{displayName:after.display_name,role:after.role,status:after.status}}); return after;
  }
  activeAdminCount(){ return Number(this.one(`SELECT COUNT(*) n FROM users WHERE role='admin' AND status='active' AND archived_at IS NULL`)?.n||0); }
  resetUserPassword(uid,password,actorId=null){ const u=this.getUser(uid); if(!u)return false; if(!password||password.length<8) throw Object.assign(new Error('PASSWORD_TOO_SHORT'),{statusCode:400}); const {salt,hash}=hashPassword(password),ts=nowIso(); this.run(`UPDATE users SET password_salt=?,password_hash=?,updated_at=? WHERE id=?`,salt,hash,ts,uid); this.run(`UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL`,ts,uid); this.audit({userId:actorId,action:'password_reset',entityType:'user',entityId:uid,after:{sessionsRevoked:true}}); return true; }
  logout(token){ if(!token)return false; const r=this.run(`UPDATE sessions SET revoked_at=? WHERE token_hash=? AND revoked_at IS NULL`,nowIso(),tokenHash(token)); return Number(r.changes||0)>0; }
  revokeAllSessions(uid,actorId=null){ const ts=nowIso(); const r=this.run(`UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL`,ts,uid); this.audit({userId:actorId,action:'revoke_sessions',entityType:'user',entityId:uid,after:{revoked:Number(r.changes||0)}}); return Number(r.changes||0); }
  cleanupSessions(){ const ts=nowIso(); return Number(this.run(`DELETE FROM sessions WHERE expires_at<? OR revoked_at IS NOT NULL`,ts).changes||0); }
  logError({userId=null,method=null,path=null,code=null,message,stack=null}){ const eid=id('err'); this.run(`INSERT INTO app_error_log(id,user_id,request_method,request_path,error_code,message,stack,created_at) VALUES(?,?,?,?,?,?,?,?)`,eid,userId,method,path,code,message||'Unknown error',stack||null,nowIso()); return eid; }
  listErrors(limit=200){ return this.all(`SELECT id,user_id,request_method,request_path,error_code,message,created_at FROM app_error_log ORDER BY created_at DESC LIMIT ?`,Number(limit)||200); }
  integrityCheck(){ const result=this.one(`PRAGMA integrity_check`); return Object.values(result||{})[0]==='ok'; }
  recordBackup({fileName,filePath,sizeBytes=0,sha256=null,triggerType='manual',status='completed',createdBy=null,notes=null}){ const bid=id('bak'); this.run(`INSERT INTO backup_history(id,file_name,file_path,size_bytes,sha256,trigger_type,status,created_by,created_at,notes) VALUES(?,?,?,?,?,?,?,?,?,?)`,bid,fileName,filePath,Number(sizeBytes)||0,sha256,triggerType,status,createdBy,nowIso(),notes); return this.one(`SELECT * FROM backup_history WHERE id=?`,bid); }
  listBackups(limit=100){ return this.all(`SELECT * FROM backup_history ORDER BY created_at DESC LIMIT ?`,Number(limit)||100); }
  getBackup(bid){ return this.one(`SELECT * FROM backup_history WHERE id=?`,bid); }
  quickCheck(){ try{ this.one(`SELECT 1 ok`); return true; }catch{return false;} }

  listCounterparties(){ return this.all('SELECT * FROM counterparties WHERE archived_at IS NULL ORDER BY name'); }
  createCounterparty(data,userId=null){
    const ts=nowIso(), cid=data.id||id('cp');
    this.run(`INSERT INTO counterparties(id,name,type,tax_office,tax_no,country,currency,payment_term_days,opening_minor,opening_date,opportunity_company_id,notes,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, cid,data.name,data.type||'customer',data.taxOffice||null,data.taxNo||null,data.country||null,data.currency||'TRY',Number(data.paymentTermDays)||0,Number(data.openingMinor)||0,data.openingDate||null,data.opportunityCompanyId||null,data.notes||null,ts,ts);
    const row=this.one('SELECT * FROM counterparties WHERE id=?',cid); this.audit({userId,action:'create',entityType:'counterparty',entityId:cid,after:row}); return row;
  }
  archiveCounterparty(cid,userId=null){ const before=this.one('SELECT * FROM counterparties WHERE id=?',cid); if(!before)return false; const ts=nowIso(); this.run('UPDATE counterparties SET archived_at=?,updated_at=? WHERE id=?',ts,ts,cid); this.audit({userId,action:'archive',entityType:'counterparty',entityId:cid,before,after:{...before,archived_at:ts}}); return true; }
  createInvoice(data,userId=null){
    const ts=nowIso(), iid=data.id||id('inv');
    this.run(`INSERT INTO invoices(id,counterparty_id,order_id,direction,number,invoice_date,due_date,expected_payment_date,currency,net_minor,tax_minor,total_minor,status,description,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,iid,data.counterpartyId,data.orderId||null,data.direction,data.number||null,data.invoiceDate,data.dueDate||null,data.expectedPaymentDate||null,data.currency||'TRY',Number(data.netMinor)||0,Number(data.taxMinor)||0,Number(data.totalMinor)||0,data.status||'open',data.description||null,ts,ts);
    const row=this.one('SELECT * FROM invoices WHERE id=?',iid); this.audit({userId,action:'create',entityType:'invoice',entityId:iid,after:row}); return row;
  }
  createAccount(data,userId=null){ const ts=nowIso(), aid=data.id||id('acc'); this.run(`INSERT INTO accounts(id,name,type,currency,opening_minor,iban,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)`,aid,data.name,data.type||'bank',data.currency||'TRY',Number(data.openingMinor)||0,data.iban||null,ts,ts); const row=this.one('SELECT * FROM accounts WHERE id=?',aid); this.audit({userId,action:'create',entityType:'account',entityId:aid,after:row}); return row; }
  createPayment(data,userId=null){ const ts=nowIso(), pid=data.id||id('pay'); this.run(`INSERT INTO payments(id,counterparty_id,account_id,direction,payment_date,currency,amount_minor,category,description,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`,pid,data.counterpartyId||null,data.accountId||null,data.direction,data.paymentDate,data.currency||'TRY',Number(data.amountMinor)||0,data.category||null,data.description||null,ts,ts); const row=this.one('SELECT * FROM payments WHERE id=?',pid); this.audit({userId,action:'create',entityType:'payment',entityId:pid,after:row}); return row; }
  allocatePayment({paymentId,invoiceId,amountMinor},userId=null){ const ts=nowIso(), aid=id('alloc'); this.run('INSERT INTO payment_allocations(id,payment_id,invoice_id,amount_minor,created_at) VALUES(?,?,?,?,?)',aid,paymentId,invoiceId,Number(amountMinor)||0,ts); const row=this.one('SELECT * FROM payment_allocations WHERE id=?',aid); this.audit({userId,action:'allocate',entityType:'payment_allocation',entityId:aid,after:row}); return row; }
  createPayable(data,userId=null){ const ts=nowIso(), pid=data.id||id('pbl'), amount=Number(data.originalMinor??data.remainingMinor)||0; this.run(`INSERT INTO payables(id,counterparty_id,vendor_name,category,due_date,currency,original_minor,remaining_minor,status,description,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`,pid,data.counterpartyId||null,data.vendorName||null,data.category,data.dueDate,data.currency||'TRY',amount,Number(data.remainingMinor??amount)||0,data.status||'open',data.description||null,ts,ts); const row=this.one('SELECT * FROM payables WHERE id=?',pid); this.audit({userId,action:'create',entityType:'payable',entityId:pid,after:row}); return row; }
  listEmployees(){ return this.all('SELECT * FROM employees WHERE archived_at IS NULL ORDER BY name'); }
  upsertEmployee(data,userId=null){
    const ts=nowIso(), eid=data.id||id('emp'), before=this.one('SELECT * FROM employees WHERE id=?',eid);
    if(before) this.run(`UPDATE employees SET name=?,pay_cycle=?,real_salary_minor=?,bank_sgk_minor=?,weekly_wage_minor=?,insured=?,status=?,updated_at=? WHERE id=?`,data.name,data.payCycle||'monthly',Number(data.realSalaryMinor)||0,Number(data.bankSgkMinor)||0,Number(data.weeklyWageMinor)||0,data.insured?1:0,data.status||'active',ts,eid);
    else this.run(`INSERT INTO employees(id,name,pay_cycle,real_salary_minor,bank_sgk_minor,weekly_wage_minor,insured,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)`,eid,data.name,data.payCycle||'monthly',Number(data.realSalaryMinor)||0,Number(data.bankSgkMinor)||0,Number(data.weeklyWageMinor)||0,data.insured?1:0,data.status||'active',ts,ts);
    const row=this.one('SELECT * FROM employees WHERE id=?',eid); this.audit({userId,action:before?'update':'create',entityType:'employee',entityId:eid,before,after:row}); return row;
  }
  addPersonnelAdjustment(data,userId=null){ const ts=nowIso(), aid=data.id||id('adj'); this.run(`INSERT INTO personnel_adjustments(id,employee_id,period,type,hours,rate_minor,amount_minor,reason,event_date,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)`,aid,data.employeeId,data.period,data.type,data.hours??null,data.rateMinor??null,Number(data.amountMinor)||0,data.reason||null,data.eventDate||null,ts); const row=this.one('SELECT * FROM personnel_adjustments WHERE id=?',aid); this.audit({userId,action:'create',entityType:'personnel_adjustment',entityId:aid,after:row}); return row; }
  generatePersonnelObligations(period,dueDate,userId=null){
    const employees=this.all("SELECT * FROM employees WHERE archived_at IS NULL AND status='active' AND pay_cycle='monthly'");
    return this.tx(()=>employees.map(e=>{
      const adj=this.all('SELECT * FROM personnel_adjustments WHERE employee_id=? AND period=? AND archived_at IS NULL',e.id,period);
      const overtime=adj.filter(x=>x.type==='overtime'||x.type==='extra').reduce((s,x)=>s+x.amount_minor,0);
      const advances=adj.filter(x=>x.type==='advance').reduce((s,x)=>s+x.amount_minor,0);
      const deductions=adj.filter(x=>x.type==='deduction').reduce((s,x)=>s+x.amount_minor,0);
      const built=buildPersonnelObligation({id:id('po'),employeeId:e.id,employeeName:e.name,dueDate,currency:'TRY',realSalaryMinor:e.real_salary_minor,bankSgkMinor:e.bank_sgk_minor,overtimeMinor:overtime,advanceMinor:advances,deductionMinor:deductions});
      const ts=nowIso();
      this.run(`INSERT INTO personnel_obligations(id,employee_id,period,due_date,currency,bank_amount_minor,cash_amount_minor,employee_debt_minor,net_minor,status,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(employee_id,period) DO UPDATE SET due_date=excluded.due_date,bank_amount_minor=excluded.bank_amount_minor,cash_amount_minor=excluded.cash_amount_minor,employee_debt_minor=excluded.employee_debt_minor,net_minor=excluded.net_minor,updated_at=excluded.updated_at`,built.id,e.id,period,dueDate,'TRY',built.bankAmountMinor,built.cashAmountMinor,built.employeeDebtMinor,built.netMinor,'open',ts,ts);
      const row=this.one('SELECT * FROM personnel_obligations WHERE employee_id=? AND period=?',e.id,period); this.audit({userId,action:'generate',entityType:'personnel_obligation',entityId:row.id,after:row}); return row;
    }));
  }
  getDashboard(today){
    const accounts=this.all('SELECT * FROM accounts WHERE archived_at IS NULL').map(a=>({currency:a.currency,openingMinor:a.opening_minor,archivedAt:a.archived_at}));
    const payments=this.all('SELECT * FROM payments WHERE archived_at IS NULL').map(p=>({currency:p.currency,direction:p.direction,amountMinor:p.amount_minor,archivedAt:p.archived_at}));
    const invoices=this.all('SELECT * FROM invoices WHERE archived_at IS NULL').map(i=>({id:i.id,companyId:i.counterparty_id,direction:i.direction,totalMinor:i.total_minor,dueDate:i.due_date,status:i.status,archivedAt:i.archived_at,currency:i.currency,expectedPaymentDate:i.expected_payment_date,number:i.number,invoiceDate:i.invoice_date}));
    const allocations=this.all('SELECT * FROM payment_allocations WHERE archived_at IS NULL').map(a=>({invoiceId:a.invoice_id,amountMinor:a.amount_minor,archivedAt:a.archived_at}));
    const payables=this.all("SELECT * FROM payables WHERE archived_at IS NULL AND status!='cancelled'").map(p=>({remainingMinor:p.remaining_minor,dueDate:p.due_date,currency:p.currency,archivedAt:p.archived_at,vendorName:p.vendor_name,category:p.category}));
    const personnel=this.all("SELECT * FROM personnel_obligations WHERE archived_at IS NULL AND status!='paid'").map(p=>({bankAmountMinor:p.bank_amount_minor,cashAmountMinor:p.cash_amount_minor,status:p.status,dueDate:p.due_date,currency:p.currency,archivedAt:p.archived_at}));
    const summary=dashboardSummary({accounts,transactions:payments,invoices,allocations,payables,personnelObligations:personnel,today});
    const receivables=receivablesSummary(invoices,allocations,today).rows;
    const cashflow=cashFlowProjection({openingByCurrency:summary.balances,receivables,payables,personnel,fromDate:today,horizons:[7,30,60,90]});
    return {...summary,cashflow,operations:this.operationsMetrics(today)};
  }
  getManagementReport(asOf=nowIso().slice(0,10),months=12,currency='TRY'){
    months=[1,3,6,12].includes(Number(months))?Number(months):12;
    const accounts=this.all('SELECT * FROM accounts WHERE archived_at IS NULL').map(a=>({id:a.id,currency:a.currency,openingMinor:a.opening_minor,archivedAt:a.archived_at}));
    const payments=this.all('SELECT * FROM payments WHERE archived_at IS NULL').map(p=>({id:p.id,counterpartyId:p.counterparty_id,currency:p.currency,direction:p.direction,amountMinor:p.amount_minor,paymentDate:p.payment_date,archivedAt:p.archived_at}));
    const invoices=this.all('SELECT * FROM invoices WHERE archived_at IS NULL').map(i=>({id:i.id,counterpartyId:i.counterparty_id,direction:i.direction,totalMinor:i.total_minor,invoiceDate:i.invoice_date,dueDate:i.due_date,status:i.status,currency:i.currency,archivedAt:i.archived_at}));
    const allocations=this.all('SELECT * FROM payment_allocations WHERE archived_at IS NULL').map(a=>({invoiceId:a.invoice_id,paymentId:a.payment_id,amountMinor:a.amount_minor,archivedAt:a.archived_at}));
    const expenses=this.all('SELECT * FROM expenses WHERE archived_at IS NULL').map(e=>({expenseDate:e.expense_date,category:e.category,department:e.department,currency:e.currency,totalMinor:e.total_minor,status:e.status,archivedAt:e.archived_at}));
    const counterparties=this.all('SELECT * FROM counterparties WHERE archived_at IS NULL').map(c=>({id:c.id,name:c.name,type:c.type,archivedAt:c.archived_at}));
    const monthsList=monthRange(asOf,months), fromDate=monthsList[0]+'-01';
    const monthly=managementMonthlySeries({invoices,payments,expenses,asOf,months,currency});
    const expense=expenseBreakdown(expenses,{fromDate,toDate:asOf,currency});
    const customers=customerPerformance({counterparties,invoices,allocations,payments,asOf,months,currency});
    const concentration=concentrationRisk(customers);
    const balanceTrend=accountBalanceTrend({accounts,payments,asOf,months,currency});
    const totals=monthly.reduce((a,r)=>({revenueMinor:a.revenueMinor+r.revenueMinor,collectionsMinor:a.collectionsMinor+r.collectionsMinor,cashOutMinor:a.cashOutMinor+r.cashOutMinor,expenseMinor:a.expenseMinor+r.expenseMinor,netOperatingCashMinor:a.netOperatingCashMinor+r.netOperatingCashMinor}),{revenueMinor:0,collectionsMinor:0,cashOutMinor:0,expenseMinor:0,netOperatingCashMinor:0});
    const current=monthly.at(-1)||{}, previous=monthly.at(-2)||null;
    const change=(field)=>previous&&previous[field]?((current[field]||0)-previous[field])/Math.abs(previous[field]):null;
    return {asOf,months,currency,fromDate,toDate:asOf,totals,monthly,expense,customers,concentration,balanceTrend,changes:{revenue:change('revenueMinor'),collections:change('collectionsMinor'),expense:change('expenseMinor'),cashOut:change('cashOutMinor')}};
  }
  getCounterparty360(cid,today){
    const c=this.one('SELECT * FROM counterparties WHERE id=? AND archived_at IS NULL',cid); if(!c)return null;
    const company={id:c.id,name:c.name,opportunityCompanyId:c.opportunity_company_id,currency:c.currency};
    const invoices=this.all('SELECT * FROM invoices WHERE counterparty_id=? AND archived_at IS NULL',cid).map(i=>({id:i.id,companyId:i.counterparty_id,direction:i.direction,totalMinor:i.total_minor,dueDate:i.due_date,status:i.status,archivedAt:i.archived_at,currency:i.currency,number:i.number}));
    const allocations=this.all(`SELECT a.* FROM payment_allocations a JOIN invoices i ON i.id=a.invoice_id WHERE i.counterparty_id=? AND a.archived_at IS NULL`,cid).map(a=>({invoiceId:a.invoice_id,amountMinor:a.amount_minor,archivedAt:a.archived_at}));
    const orders=this.all('SELECT * FROM orders WHERE counterparty_id=? AND archived_at IS NULL',cid).map(o=>({id:o.id,companyId:o.counterparty_id,number:o.order_no,status:o.status,opportunityOrderId:o.opportunity_order_id}));
    const contacts=this.all('SELECT * FROM contacts WHERE counterparty_id=? AND archived_at IS NULL',cid).map(x=>({id:x.id,companyId:x.counterparty_id,name:x.name,role:x.title,phone:x.phone,email:x.email}));
    return customer360({company,invoices,allocations,orders,contacts,today});
  }
  listAccounts(){ return this.all('SELECT * FROM accounts WHERE archived_at IS NULL ORDER BY name'); }
  listInvoices(){ return this.all(`SELECT i.*, COALESCE(i.total_minor-(SELECT SUM(a.amount_minor) FROM payment_allocations a WHERE a.invoice_id=i.id AND a.archived_at IS NULL), i.total_minor) remaining_minor FROM invoices i WHERE i.archived_at IS NULL ORDER BY i.invoice_date DESC`); }
  createBankImportBatch({accountId=null,sourceName='Ekstre',sourceType='csv',text,currency='TRY'},userId=null){
    const rows=parseBankCsv(text,{currency}); const ts=nowIso(), bid=id('bib');
    this.tx(()=>{
      this.run(`INSERT INTO bank_import_batches(id,account_id,source_name,source_type,imported_by,status,row_count,created_at) VALUES(?,?,?,?,?,?,?,?)`,bid,accountId,sourceName,sourceType,userId,'review',rows.length,ts);
      const cps=this.listCounterparties(), inv=this.listInvoices();
      for(const r of rows){ const m=suggestMatches(r,{counterparties:cps,invoices:inv});
        this.run(`INSERT INTO bank_import_rows(id,batch_id,row_no,txn_date,description,reference,direction,amount_minor,currency,suggested_counterparty_id,suggested_invoice_id,confidence,decision,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,id('bir'),bid,r.rowNo,r.txnDate,r.description,r.reference,r.direction,r.amountMinor,r.currency,m.counterpartyId,m.invoiceId,m.confidence,'pending',ts,ts);
      }
      this.audit({userId,action:'import',entityType:'bank_import_batch',entityId:bid,after:{sourceName,sourceType,rowCount:rows.length}});
    });
    return this.getBankImportBatch(bid);
  }
  getBankImportBatch(bid){ const batch=this.one('SELECT * FROM bank_import_batches WHERE id=? AND archived_at IS NULL',bid); if(!batch)return null; return {...batch,rows:this.all('SELECT * FROM bank_import_rows WHERE batch_id=? AND archived_at IS NULL ORDER BY row_no',bid)}; }
  listBankImportBatches(limit=50){ return this.all('SELECT * FROM bank_import_batches WHERE archived_at IS NULL ORDER BY created_at DESC LIMIT ?',Number(limit)||50); }
  decideBankImportRow(rowId,{decision,counterpartyId=null,invoiceId=null,accountId=null,category='Banka ekstresi'},userId=null){
    const before=this.one('SELECT r.*, b.account_id batch_account_id FROM bank_import_rows r JOIN bank_import_batches b ON b.id=r.batch_id WHERE r.id=? AND r.archived_at IS NULL',rowId); if(!before)return null;
    if(!['approved','rejected','edited'].includes(decision)) throw Object.assign(new Error('INVALID_DECISION'),{statusCode:400});
    const ts=nowIso(); let paymentId=before.payment_id;
    return this.tx(()=>{
      if((decision==='approved'||decision==='edited')&&!paymentId){
        const cp=counterpartyId||before.suggested_counterparty_id||null, inv=invoiceId||before.suggested_invoice_id||null;
        const pay=this.createPayment({counterpartyId:cp,accountId:accountId||before.batch_account_id||null,direction:before.direction,paymentDate:before.txn_date||ts.slice(0,10),currency:before.currency,amountMinor:before.amount_minor,category,description:before.description||before.reference||'Banka ekstresi'},userId); paymentId=pay.id;
        if(inv){ const ir=this.one(`SELECT i.total_minor-COALESCE((SELECT SUM(a.amount_minor) FROM payment_allocations a WHERE a.invoice_id=i.id AND a.archived_at IS NULL),0) remaining FROM invoices i WHERE i.id=?`,inv); const alloc=Math.max(0,Math.min(before.amount_minor,Number(ir?.remaining||0))); if(alloc>0)this.allocatePayment({paymentId,invoiceId:inv,amountMinor:alloc},userId); }
      }
      this.run(`UPDATE bank_import_rows SET decision=?,suggested_counterparty_id=?,suggested_invoice_id=?,payment_id=?,updated_at=? WHERE id=?`,decision,counterpartyId??before.suggested_counterparty_id,invoiceId??before.suggested_invoice_id,paymentId,ts,rowId);
      const after=this.one('SELECT * FROM bank_import_rows WHERE id=?',rowId); this.audit({userId,action:'review',entityType:'bank_import_row',entityId:rowId,before,after}); return after;
    });
  }
  stageDocument({sourceName,mimeType=null,documentType='unknown',counterpartyId=null,extractedText=null,extractedJson=null},userId=null){ const ts=nowIso(), did=id('doc'); const proposal=extractedJson || ((documentType==='expense_receipt'||documentType==='purchase_invoice')&&extractedText?extractExpenseProposal(extractedText,{sourceName}):null); this.run(`INSERT INTO document_staging(id,source_name,mime_type,document_type,counterparty_id,extracted_text,extracted_json,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`,did,sourceName,mimeType,documentType,counterpartyId,extractedText,proposal?JSON.stringify(proposal):null,'staged',userId,ts,ts); const row=this.one('SELECT * FROM document_staging WHERE id=?',did); this.audit({userId,action:'stage',entityType:'document',entityId:did,after:{sourceName,mimeType,documentType,proposal}}); return row; }
  getStagedDocument(did){ return this.one('SELECT * FROM document_staging WHERE id=? AND archived_at IS NULL',did); }
  analyzeStagedDocument(did,userId=null){ const before=this.getStagedDocument(did); if(!before)return null; const proposal=extractExpenseProposal(before.extracted_text||'',{sourceName:before.source_name}); const ts=nowIso(); this.run(`UPDATE document_staging SET extracted_json=?,status='reviewed',updated_at=? WHERE id=?`,JSON.stringify(proposal),ts,did); const after=this.getStagedDocument(did); this.audit({userId,action:'analyze',entityType:'document',entityId:did,before,after}); return {...after,proposal}; }
  listStagedDocuments(){ return this.all('SELECT * FROM document_staging WHERE archived_at IS NULL ORDER BY created_at DESC'); }
  createExpense(data,userId=null){ const ts=nowIso(), eid=data.id||id('exp'), total=Number(data.totalMinor)||0; this.run(`INSERT INTO expenses(id,counterparty_id,document_id,expense_date,category,department,currency,net_minor,tax_minor,total_minor,payment_mode,account_id,due_date,status,description,created_by,approved_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,eid,data.counterpartyId||null,data.documentId||null,data.expenseDate||ts.slice(0,10),data.category||'Genel gider',data.department||null,data.currency||'TRY',Number(data.netMinor)||0,Number(data.taxMinor)||0,total,data.paymentMode||'unpaid',data.accountId||null,data.dueDate||null,data.status||'draft',data.description||null,userId,data.status==='approved'?userId:null,ts,ts); const row=this.one('SELECT * FROM expenses WHERE id=?',eid); this.audit({userId,action:'create',entityType:'expense',entityId:eid,after:row}); return row; }
  listExpenses(limit=200){ return this.all(`SELECT e.*,c.name counterparty_name,d.source_name document_name FROM expenses e LEFT JOIN counterparties c ON c.id=e.counterparty_id LEFT JOIN document_staging d ON d.id=e.document_id WHERE e.archived_at IS NULL ORDER BY e.expense_date DESC,e.created_at DESC LIMIT ?`,Number(limit)||200); }
  reviewExpense(expenseId,{decision,accountId=null,dueDate=null},userId=null){ return this.tx(()=>{ const before=this.one('SELECT * FROM expenses WHERE id=? AND archived_at IS NULL',expenseId); if(!before)return null; const ts=nowIso(); if(decision==='rejected'){this.run(`UPDATE expenses SET status='rejected',approved_by=?,updated_at=? WHERE id=?`,userId,ts,expenseId);} else if(decision==='approved'){let status='approved'; let mode=before.payment_mode; let payId=null; if(['cash','bank'].includes(mode)){ const acc=accountId||before.account_id; if(!acc)throw new Error('ACCOUNT_REQUIRED'); const pay=this.createPayment({counterpartyId:before.counterparty_id,accountId:acc,direction:'out',paymentDate:before.expense_date,currency:before.currency,amountMinor:before.total_minor,category:before.category,description:before.description||'Masraf'},userId); payId=pay.id; status='paid'; } else if(mode==='payable'){ this.createPayable({counterpartyId:before.counterparty_id,category:before.category,dueDate:dueDate||before.due_date||before.expense_date,currency:before.currency,originalMinor:before.total_minor,description:before.description||'Masraf'},userId); } this.run(`UPDATE expenses SET status=?,account_id=COALESCE(?,account_id),due_date=COALESCE(?,due_date),approved_by=?,updated_at=? WHERE id=?`,status,accountId,dueDate,userId,ts,expenseId); if(before.document_id)this.run(`UPDATE document_staging SET status='posted',updated_at=? WHERE id=?`,ts,before.document_id); const after=this.one('SELECT * FROM expenses WHERE id=?',expenseId); this.audit({userId,action:'approve',entityType:'expense',entityId:expenseId,before,after:{...after,paymentId:payId}}); return after; } else throw new Error('INVALID_DECISION'); const after=this.one('SELECT * FROM expenses WHERE id=?',expenseId); this.audit({userId,action:'reject',entityType:'expense',entityId:expenseId,before,after}); return after; }); }
  createExpenseFromDocument(did,overrides={},userId=null){ const d=this.getStagedDocument(did); if(!d)return null; let p={}; try{p=JSON.parse(d.extracted_json||'{}')}catch{}; return this.createExpense({documentId:did,counterpartyId:overrides.counterpartyId||d.counterparty_id||null,expenseDate:overrides.expenseDate||p.date||nowIso().slice(0,10),category:overrides.category||p.category||'Genel gider',department:overrides.department||null,currency:overrides.currency||p.currency||'TRY',netMinor:overrides.netMinor??p.netMinor??0,taxMinor:overrides.taxMinor??p.taxMinor??0,totalMinor:overrides.totalMinor??p.totalMinor??0,paymentMode:overrides.paymentMode||'unpaid',accountId:overrides.accountId||null,dueDate:overrides.dueDate||null,status:'draft',description:overrides.description||`Belgeden: ${d.source_name}`},userId); }
  createBankImportFromText({accountId=null,sourceName='Banka ekstresi.pdf',text,currency='TRY'},userId=null){ const rows=parseBankStatementText(text,{currency}); const ts=nowIso(), bid=id('bib'); this.run(`INSERT INTO bank_import_batches(id,account_id,source_name,source_type,imported_by,status,row_count,created_at) VALUES(?,?,?,?,?,?,?,?)`,bid,accountId,sourceName,'pdf_text',userId,'review',rows.length,ts); const cps=this.listCounterparties(), inv=this.listInvoices(); rows.forEach(r=>{const m=suggestMatches(r,{counterparties:cps,invoices:inv}); this.run(`INSERT INTO bank_import_rows(id,batch_id,row_no,txn_date,description,reference,direction,amount_minor,currency,suggested_counterparty_id,suggested_invoice_id,confidence,decision,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,id('bir'),bid,r.rowNo,r.txnDate,r.description,r.reference,r.direction,r.amountMinor,r.currency,m.counterpartyId,m.invoiceId,m.confidence,'pending',ts,ts);}); this.audit({userId,action:'import',entityType:'bank_import_batch',entityId:bid,after:{sourceName,sourceType:'pdf_text',rowCount:rows.length}}); return this.getBankImportBatch(bid); }

  createInventoryItem({sku=null,name,unit='adet',category=null,minLevel=0,opportunityProductId=null},userId=null){ const ts=nowIso(), iid=id('stk'); this.run(`INSERT INTO inventory_items(id,sku,name,unit,category,min_level,opportunity_product_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)`,iid,sku,name,unit,category,Number(minLevel)||0,opportunityProductId,ts,ts); const row=this.one('SELECT * FROM inventory_items WHERE id=?',iid); this.audit({userId,action:'create',entityType:'inventory_item',entityId:iid,after:row}); return row; }
  addInventoryMovement({itemId,movementDate,direction,quantity,unitCostMinor=null,counterpartyId=null,orderId=null,description=null,sourceType=null,sourceId=null},userId=null){ const ts=nowIso(), mid=id('stm'); this.run(`INSERT INTO inventory_movements(id,item_id,movement_date,direction,quantity,unit_cost_minor,counterparty_id,order_id,description,created_by,created_at,source_type,source_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,mid,itemId,movementDate,direction,Number(quantity)||0,unitCostMinor,counterpartyId,orderId,description,userId,ts,sourceType,sourceId); const row=this.one('SELECT * FROM inventory_movements WHERE id=?',mid); this.audit({userId,action:'create',entityType:'inventory_movement',entityId:mid,after:row}); return row; }
  listInventory(){ return this.all(`SELECT i.*, COALESCE(SUM(CASE WHEN m.archived_at IS NULL THEN CASE WHEN m.direction='in' THEN m.quantity WHEN m.direction='out' THEN -m.quantity ELSE m.quantity END ELSE 0 END),0) quantity FROM inventory_items i LEFT JOIN inventory_movements m ON m.item_id=i.id WHERE i.archived_at IS NULL GROUP BY i.id ORDER BY i.name`); }

  storeFile({originalName,mimeType='application/octet-stream',buffer,category='document'},userId=null){
    if(!Buffer.isBuffer(buffer)) buffer=Buffer.from(buffer||'');
    const sha=crypto.createHash('sha256').update(buffer).digest('hex'), fid=id('fil'), ts=nowIso();
    const ext=path.extname(originalName||'').replace(/[^.A-Za-z0-9]/g,'').slice(0,10), sub=ts.slice(0,7);
    const dir=path.join(this.storageRoot,sub); fs.mkdirSync(dir,{recursive:true});
    const storagePath=path.join(dir,`${fid}${ext}`); fs.writeFileSync(storagePath,buffer,{mode:0o600});
    this.run(`INSERT INTO file_objects(id,original_name,mime_type,size_bytes,sha256,storage_path,category,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)`,fid,originalName||'dosya',mimeType,buffer.length,sha,storagePath,category,userId,ts);
    const row=this.getFile(fid); this.audit({userId,action:'upload',entityType:'file',entityId:fid,after:{...row,storage_path:'[private]'}}); return row;
  }
  getFile(fid){ return this.one('SELECT * FROM file_objects WHERE id=? AND archived_at IS NULL',fid); }
  listFiles(limit=100){ return this.all('SELECT id,original_name,mime_type,size_bytes,sha256,category,created_by,created_at FROM file_objects WHERE archived_at IS NULL ORDER BY created_at DESC LIMIT ?',Number(limit)||100); }
  readFileBytes(fid){ const f=this.getFile(fid); if(!f)return null; return {meta:f,buffer:fs.readFileSync(f.storage_path)}; }
  linkFile({fileId,entityType,entityId},userId=null){ const ts=nowIso(), lid=id('flk'); this.run('INSERT INTO file_links(id,file_id,entity_type,entity_id,created_by,created_at) VALUES(?,?,?,?,?,?)',lid,fileId,entityType,entityId,userId,ts); return this.one('SELECT * FROM file_links WHERE id=?',lid); }
  createExtractionJob({fileId,purpose='document',engine='auto'},userId=null){ const ts=nowIso(), jid=id('xtr'); this.run(`INSERT INTO extraction_jobs(id,file_id,purpose,engine,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)`,jid,fileId,purpose,engine,'queued',userId,ts,ts); return this.runExtractionJob(jid,userId); }
  runExtractionJob(jid,userId=null){ const before=this.one(`SELECT j.*,f.storage_path,f.mime_type,f.original_name FROM extraction_jobs j JOIN file_objects f ON f.id=j.file_id WHERE j.id=? AND j.archived_at IS NULL`,jid); if(!before)return null; const ts=nowIso(); this.run(`UPDATE extraction_jobs SET status='processing',updated_at=? WHERE id=?`,ts,jid); let out; try{out=extractFileText({filePath:before.storage_path,mimeType:before.mime_type});}catch(e){out={status:'failed',engine:'auto',text:'',error:e.message};} const done=nowIso(); this.run(`UPDATE extraction_jobs SET engine=?,status=?,extracted_text=?,error_message=?,updated_at=?,completed_at=? WHERE id=?`,out.engine||before.engine,out.status,out.text||null,out.error||null,done,['completed','failed','needs_external_ocr'].includes(out.status)?done:null,jid); const after=this.getExtractionJob(jid); this.audit({userId,action:'extract',entityType:'extraction_job',entityId:jid,before:{status:before.status},after:{status:after.status,engine:after.engine,error_message:after.error_message}}); if(after.status==='completed') this.applyExtractionResult(after,userId); return this.getExtractionJob(jid); }
  getExtractionJob(jid){ return this.one(`SELECT j.*,f.original_name,f.mime_type,f.category FROM extraction_jobs j JOIN file_objects f ON f.id=j.file_id WHERE j.id=? AND j.archived_at IS NULL`,jid); }
  listExtractionJobs(limit=100){ return this.all(`SELECT j.*,f.original_name,f.mime_type,f.category FROM extraction_jobs j JOIN file_objects f ON f.id=j.file_id WHERE j.archived_at IS NULL ORDER BY j.created_at DESC LIMIT ?`,Number(limit)||100); }
  supplyExtractionText(jid,text,userId=null){ const before=this.getExtractionJob(jid); if(!before)return null; const ts=nowIso(); this.run(`UPDATE extraction_jobs SET extracted_text=?,status='completed',engine='external',error_message=NULL,updated_at=?,completed_at=? WHERE id=?`,text,ts,ts,jid); const after=this.getExtractionJob(jid); this.audit({userId,action:'supply_text',entityType:'extraction_job',entityId:jid,before:{status:before.status},after:{status:after.status,engine:'external'}}); this.applyExtractionResult(after,userId); return this.getExtractionJob(jid); }
  applyExtractionResult(job,userId=null){ if(!job?.extracted_text)return null; const f=this.getFile(job.file_id); if(job.purpose==='bank_statement'){ const batch=this.createBankImportFromText({sourceName:f.original_name,text:job.extracted_text},userId); this.linkFile({fileId:f.id,entityType:'bank_import_batch',entityId:batch.id},userId); return batch; } const doc=this.stageDocument({sourceName:f.original_name,mimeType:f.mime_type,documentType:f.category==='receipt'?'expense_receipt':f.category==='invoice'?'purchase_invoice':'unknown',extractedText:job.extracted_text},userId); this.linkFile({fileId:f.id,entityType:'document',entityId:doc.id},userId); return doc; }
  operationsMetrics(asOf=nowIso().slice(0,10)){
    const month=asOf.slice(0,7), exp=this.one(`SELECT COALESCE(SUM(total_minor),0) n FROM expenses WHERE archived_at IS NULL AND status IN ('approved','paid') AND substr(expense_date,1,7)=?`,month)?.n||0;
    const pendingExpenses=this.one(`SELECT COUNT(*) n FROM expenses WHERE archived_at IS NULL AND status='draft'`)?.n||0;
    const pendingDocs=this.one(`SELECT COUNT(*) n FROM extraction_jobs WHERE archived_at IS NULL AND status IN ('queued','processing','needs_external_ocr')`)?.n||0;
    const lowStock=this.one(`SELECT COUNT(*) n FROM (${`SELECT i.id,i.min_level,COALESCE(SUM(CASE WHEN m.archived_at IS NULL THEN CASE WHEN m.direction='in' THEN m.quantity WHEN m.direction='out' THEN -m.quantity ELSE m.quantity END ELSE 0 END),0) q FROM inventory_items i LEFT JOIN inventory_movements m ON m.item_id=i.id WHERE i.archived_at IS NULL GROUP BY i.id`}) x WHERE x.q < x.min_level`)?.n||0;
    return {monthExpenseMinor:Number(exp),pendingExpenses:Number(pendingExpenses),pendingExtraction:Number(pendingDocs),lowStockCount:Number(lowStock)};
  }


  createProductionJob({jobNo=null,orderId=null,outputItemId=null,plannedQty=0,description=null},userId=null){ const ts=nowIso(), jid=id('job'); this.run(`INSERT INTO production_jobs(id,job_no,order_id,output_item_id,planned_qty,status,description,created_by,created_at,updated_at) VALUES(?,?,?,?,?,'open',?,?,?,?)`,jid,jobNo,orderId,outputItemId,Number(plannedQty)||0,description,userId,ts,ts); const row=this.one('SELECT * FROM production_jobs WHERE id=?',jid); this.audit({userId,action:'create',entityType:'production_job',entityId:jid,after:row}); return row; }
  listProductionJobs(){ return this.all('SELECT * FROM production_jobs WHERE archived_at IS NULL ORDER BY created_at DESC'); }
  issueToProduction({jobId,itemId,quantity,movementDate,unitCostMinor=null,description=null},userId=null){ const job=this.one('SELECT * FROM production_jobs WHERE id=? AND archived_at IS NULL',jobId); if(!job)throw new Error('JOB_NOT_FOUND'); this.run(`UPDATE production_jobs SET status='in_progress',started_at=COALESCE(started_at,?),updated_at=? WHERE id=?`,movementDate,movementDate,jobId); return this.addInventoryMovement({itemId,movementDate,direction:'out',quantity,unitCostMinor,description:description||'Üretime sarf',sourceType:'production_issue',sourceId:jobId},userId); }
  receiveProduction({jobId,quantity,movementDate,unitCostMinor=null,complete=false},userId=null){ const job=this.one('SELECT * FROM production_jobs WHERE id=? AND archived_at IS NULL',jobId); if(!job||!job.output_item_id)throw new Error('OUTPUT_ITEM_REQUIRED'); const m=this.addInventoryMovement({itemId:job.output_item_id,movementDate,direction:'in',quantity,unitCostMinor,description:'Üretimden giriş',sourceType:'production_output',sourceId:jobId},userId); const produced=Number(job.produced_qty||0)+Number(quantity||0), status=complete?'completed':'in_progress'; this.run(`UPDATE production_jobs SET produced_qty=?,status=?,started_at=COALESCE(started_at,?),completed_at=?,updated_at=? WHERE id=?`,produced,status,movementDate,complete?movementDate:null,nowIso(),jobId); return m; }

  createOrder({counterpartyId,orderNo=null,status='open',currency='TRY',opportunityOrderId=null,opportunityId=null,orderDate=null},userId=null){ const ts=nowIso(), oid=id('ord'); this.run(`INSERT INTO orders(id,counterparty_id,order_no,status,currency,total_minor,opportunity_order_id,opportunity_id,order_date,created_at,updated_at) VALUES(?,?,?,?,?,0,?,?,?,?,?)`,oid,counterpartyId,orderNo,status,currency,opportunityOrderId,opportunityId,orderDate,ts,ts); const row=this.one('SELECT * FROM orders WHERE id=?',oid); this.audit({userId,action:'create',entityType:'order',entityId:oid,after:row}); return row; }
  listOrders(){ return this.all(`SELECT o.*,c.name customer_name FROM orders o JOIN counterparties c ON c.id=o.counterparty_id WHERE o.archived_at IS NULL ORDER BY COALESCE(o.order_date,o.created_at) DESC`); }
  createProduct({name,sku=null,opportunityProductId=null},userId=null){ const ts=nowIso(), pid=id('prd'); this.run(`INSERT INTO products(id,name,sku,opportunity_product_id,created_at,updated_at) VALUES(?,?,?,?,?,?)`,pid,name,sku,opportunityProductId,ts,ts); const row=this.one('SELECT * FROM products WHERE id=?',pid); this.audit({userId,action:'create',entityType:'product',entityId:pid,after:row}); return row; }
  listProducts(){ return this.all(`SELECT * FROM products WHERE archived_at IS NULL ORDER BY name`); }
  addOrderItem({orderId,productId=null,description=null,quantity=0,salesUnitMinor=0,directUnitCostMinor=0},userId=null){ const ts=nowIso(), iid=id('ori'); this.run(`INSERT INTO order_items(id,order_id,product_id,description,quantity,sales_unit_minor,direct_unit_cost_minor,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)`,iid,orderId,productId,description,Number(quantity)||0,Number(salesUnitMinor)||0,Number(directUnitCostMinor)||0,ts,ts); const total=this.one(`SELECT COALESCE(SUM(quantity*sales_unit_minor),0) n FROM order_items WHERE order_id=? AND archived_at IS NULL`,orderId)?.n||0; this.run(`UPDATE orders SET total_minor=?,updated_at=? WHERE id=?`,Math.round(total),ts,orderId); const row=this.one('SELECT * FROM order_items WHERE id=?',iid); this.audit({userId,action:'create',entityType:'order_item',entityId:iid,after:row}); return row; }
  createBudgetPlan({name,currency='TRY',startMonth,endMonth,status='draft',notes=null},userId=null){ const ts=nowIso(), bid=id('bud'); this.run(`INSERT INTO budget_plans(id,name,currency,start_month,end_month,status,notes,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)`,bid,name,currency,startMonth,endMonth,status,notes,userId,ts,ts); const row=this.one('SELECT * FROM budget_plans WHERE id=?',bid); this.audit({userId,action:'create',entityType:'budget_plan',entityId:bid,after:row}); return row; }
  upsertBudgetLine({planId,month,revenueBudgetMinor=0,expenseBudgetMinor=0,cashInBudgetMinor=0,cashOutBudgetMinor=0,notes=null},userId=null){ const ts=nowIso(), existing=this.one(`SELECT * FROM budget_lines WHERE plan_id=? AND month=?`,planId,month), lid=existing?.id||id('bul'); this.run(`INSERT INTO budget_lines(id,plan_id,month,revenue_budget_minor,expense_budget_minor,cash_in_budget_minor,cash_out_budget_minor,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(plan_id,month) DO UPDATE SET revenue_budget_minor=excluded.revenue_budget_minor,expense_budget_minor=excluded.expense_budget_minor,cash_in_budget_minor=excluded.cash_in_budget_minor,cash_out_budget_minor=excluded.cash_out_budget_minor,notes=excluded.notes,updated_at=excluded.updated_at,archived_at=NULL`,lid,planId,month,Number(revenueBudgetMinor)||0,Number(expenseBudgetMinor)||0,Number(cashInBudgetMinor)||0,Number(cashOutBudgetMinor)||0,notes,ts,ts); const row=this.one(`SELECT * FROM budget_lines WHERE plan_id=? AND month=?`,planId,month); this.audit({userId,action:existing?'update':'create',entityType:'budget_line',entityId:row.id,before:existing,after:row}); return row; }
  listBudgetPlans(){ return this.all(`SELECT * FROM budget_plans WHERE archived_at IS NULL ORDER BY created_at DESC`); }
  getBudgetReport(planId,asOf=nowIso().slice(0,10)){ const plan=this.one(`SELECT * FROM budget_plans WHERE id=? AND archived_at IS NULL`,planId); if(!plan)return null; const months=Math.max(1,(Number(plan.end_month.slice(0,4))-Number(plan.start_month.slice(0,4)))*12+Number(plan.end_month.slice(5,7))-Number(plan.start_month.slice(5,7))+1); const monthly=this.getManagementReport(asOf,Math.min(12,months),plan.currency).monthly; const lines=this.all(`SELECT * FROM budget_lines WHERE plan_id=? AND archived_at IS NULL ORDER BY month`,planId).map(x=>({month:x.month,revenueBudgetMinor:x.revenue_budget_minor,expenseBudgetMinor:x.expense_budget_minor,cashInBudgetMinor:x.cash_in_budget_minor,cashOutBudgetMinor:x.cash_out_budget_minor})); return {plan,...budgetVsActual({budgetLines:lines,monthlyActual:monthly})}; }
  getProfitability(){ const orders=this.all(`SELECT id,counterparty_id counterpartyId,order_no number,archived_at archivedAt FROM orders WHERE archived_at IS NULL`); const orderItems=this.all(`SELECT id,order_id orderId,product_id productId,description,quantity,sales_unit_minor salesUnitMinor,direct_unit_cost_minor directUnitCostMinor,archived_at archivedAt FROM order_items WHERE archived_at IS NULL`); const counterparties=this.all(`SELECT id,name FROM counterparties WHERE archived_at IS NULL`); const products=this.all(`SELECT id,name FROM products WHERE archived_at IS NULL`); return profitabilityAnalysis({orders,orderItems,counterparties,products}); }
  getCashPlan13(asOf=nowIso().slice(0,10),currency='TRY',scenarios={bad:0.5,base:0.8,good:1}){ const d=this.getDashboard(asOf); const openingMinor=Number(d.balances?.[currency]||0); const invoices=this.all(`SELECT * FROM invoices WHERE archived_at IS NULL AND direction='sales' AND status!='cancelled' AND currency=?`,currency).map(i=>({id:i.id,totalMinor:i.total_minor,dueDate:i.due_date,expectedPaymentDate:i.expected_payment_date,status:i.status,archivedAt:i.archived_at})); const allocations=this.all(`SELECT * FROM payment_allocations WHERE archived_at IS NULL`).map(a=>({invoiceId:a.invoice_id,amountMinor:a.amount_minor,archivedAt:a.archived_at})); const receivables=receivablesSummary(invoices,allocations,asOf).rows; const payables=this.all(`SELECT remaining_minor remainingMinor,due_date dueDate FROM payables WHERE archived_at IS NULL AND status='open' AND currency=?`,currency); const personnel=this.all(`SELECT bank_amount_minor bankAmountMinor,cash_amount_minor cashAmountMinor,due_date dueDate FROM personnel_obligations WHERE archived_at IS NULL AND status!='paid' AND currency=?`,currency); return thirteenWeekCashFlow({openingMinor,receivables,payables,personnel,fromDate:asOf,scenarios}); }
  createCostCenter({code=null,name,kind='overhead',defaultBasis='revenue',description=null},userId=null){
    const ts=nowIso(), cid=id('cc');
    this.run(`INSERT INTO cost_centers(id,code,name,kind,default_basis,description,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)`,cid,code,name,kind,defaultBasis,description,userId,ts,ts);
    const row=this.one('SELECT * FROM cost_centers WHERE id=?',cid); this.audit({userId,action:'create',entityType:'cost_center',entityId:cid,after:row}); return row;
  }
  listCostCenters(){
    return this.all(`SELECT c.*,COALESCE((SELECT SUM(a.amount_minor) FROM expense_cost_center_allocations a WHERE a.cost_center_id=c.id AND a.archived_at IS NULL),0) assigned_minor FROM cost_centers c WHERE c.archived_at IS NULL ORDER BY c.code,c.name`);
  }
  assignExpenseCostCenter({expenseId,costCenterId,amountMinor},userId=null){
    const exp=this.one(`SELECT * FROM expenses WHERE id=? AND archived_at IS NULL`,expenseId); if(!exp)throw new Error('EXPENSE_NOT_FOUND');
    const cc=this.one(`SELECT * FROM cost_centers WHERE id=? AND archived_at IS NULL`,costCenterId); if(!cc)throw new Error('COST_CENTER_NOT_FOUND');
    const used=this.one(`SELECT COALESCE(SUM(amount_minor),0) n FROM expense_cost_center_allocations WHERE expense_id=? AND archived_at IS NULL`,expenseId)?.n||0;
    const amt=Math.round(Number(amountMinor)||0); if(amt<=0||used+amt>exp.total_minor)throw new Error('INVALID_ALLOCATION_AMOUNT');
    const aid=id('eca'),ts=nowIso(); this.run(`INSERT INTO expense_cost_center_allocations(id,expense_id,cost_center_id,amount_minor,created_by,created_at) VALUES(?,?,?,?,?,?)`,aid,expenseId,costCenterId,amt,userId,ts);
    const row=this.one(`SELECT * FROM expense_cost_center_allocations WHERE id=?`,aid); this.audit({userId,action:'assign',entityType:'expense_cost_center',entityId:aid,after:row}); return row;
  }
  linkCostCenter({costCenterId,entityType,entityId},userId=null){
    const lid=id('ccl'),ts=nowIso(); this.run(`INSERT OR IGNORE INTO cost_center_links(id,cost_center_id,entity_type,entity_id,created_by,created_at) VALUES(?,?,?,?,?,?)`,lid,costCenterId,entityType,entityId,userId,ts);
    const row=this.one(`SELECT * FROM cost_center_links WHERE cost_center_id=? AND entity_type=? AND entity_id=? AND archived_at IS NULL`,costCenterId,entityType,entityId); this.audit({userId,action:'link',entityType:'cost_center_link',entityId:row?.id,after:row}); return row;
  }
  _periodOrderMetrics(period,currency='TRY'){
    const orders=this.all(`SELECT id,counterparty_id counterpartyId,order_no number,order_date orderDate,currency FROM orders WHERE archived_at IS NULL AND substr(COALESCE(order_date,created_at),1,7)=? AND currency=?`,period,currency);
    const out=[];
    for(const o of orders){
      const items=this.all(`SELECT product_id productId,quantity,sales_unit_minor salesUnitMinor,direct_unit_cost_minor directUnitCostMinor FROM order_items WHERE order_id=? AND archived_at IS NULL`,o.id);
      const revenueMinor=Math.round(items.reduce((s,x)=>s+Number(x.quantity||0)*Number(x.salesUnitMinor||0),0));
      const directCostMinor=Math.round(items.reduce((s,x)=>s+Number(x.quantity||0)*Number(x.directUnitCostMinor||0),0));
      out.push({...o,orderId:o.id,revenueMinor,directCostMinor,productIds:[...new Set(items.map(x=>x.productId).filter(Boolean))]});
    }
    return out;
  }
  createCostAllocationRun({period,currency='TRY'},userId=null){
    const orders=this._periodOrderMetrics(period,currency),ts=nowIso(),rid=id('car');
    const expenses=this.all(`SELECT * FROM expenses WHERE archived_at IS NULL AND status IN ('approved','paid') AND substr(expense_date,1,7)=? AND currency=?`,period,currency);
    let total=0,allocated=0,unallocated=0;
    this.tx(()=>{
      this.run(`INSERT INTO cost_allocation_runs(id,period,currency,status,created_by,created_at) VALUES(?,?,?,'draft',?,?)`,rid,period,currency,userId,ts);
      for(const exp of expenses){
        const explicit=this.all(`SELECT a.*,c.default_basis FROM expense_cost_center_allocations a JOIN cost_centers c ON c.id=a.cost_center_id WHERE a.expense_id=? AND a.archived_at IS NULL AND c.archived_at IS NULL`,exp.id);
        const assigned=explicit.reduce((s,a)=>s+Number(a.amount_minor||0),0);
        const chunks=[...explicit.map(a=>({expenseId:exp.id,costCenterId:a.cost_center_id,amountMinor:a.amount_minor,basis:a.default_basis||'revenue'}))];
        if(assigned<exp.total_minor)chunks.push({expenseId:exp.id,costCenterId:null,amountMinor:exp.total_minor-assigned,basis:'revenue'});
        for(const ch of chunks){
          total+=ch.amountMinor;
          let eligible=[...orders];
          if(ch.costCenterId){
            const links=this.all(`SELECT entity_type,entity_id FROM cost_center_links WHERE cost_center_id=? AND archived_at IS NULL`,ch.costCenterId);
            if(links.length){ eligible=orders.filter(o=>links.some(l=>l.entity_type==='order'&&l.entity_id===o.id || l.entity_type==='customer'&&l.entity_id===o.counterpartyId || l.entity_type==='product'&&o.productIds.includes(l.entity_id) || l.entity_type==='department')); }
          }
          const dist=allocateMinorExact(ch.amountMinor,eligible,ch.basis);
          for(const a of dist.allocations){ this.run(`INSERT INTO cost_allocations(id,run_id,cost_center_id,expense_id,order_id,amount_minor,basis,created_at) VALUES(?,?,?,?,?,?,?,?)`,id('cal'),rid,ch.costCenterId,ch.expenseId,a.orderId,a.amountMinor,ch.basis,ts); allocated+=a.amountMinor; }
          if(dist.unallocatedMinor){ this.run(`INSERT INTO cost_allocations(id,run_id,cost_center_id,expense_id,order_id,amount_minor,basis,created_at) VALUES(?,?,?,?,NULL,?,'unallocated',?)`,id('cal'),rid,ch.costCenterId,ch.expenseId,dist.unallocatedMinor,ts); unallocated+=dist.unallocatedMinor; }
        }
      }
      this.run(`UPDATE cost_allocation_runs SET status='posted',total_overhead_minor=?,allocated_minor=?,unallocated_minor=?,posted_at=? WHERE id=?`,total,allocated,unallocated,ts,rid);
      this.audit({userId,action:'post',entityType:'cost_allocation_run',entityId:rid,after:{period,currency,total,allocated,unallocated}});
    });
    return this.getCostAllocationRun(rid);
  }
  getCostAllocationRun(runId){ const run=this.one(`SELECT * FROM cost_allocation_runs WHERE id=? AND archived_at IS NULL`,runId); if(!run)return null; return {...run,allocations:this.all(`SELECT * FROM cost_allocations WHERE run_id=? AND archived_at IS NULL`,runId)}; }
  listCostAllocationRuns(limit=24){ return this.all(`SELECT * FROM cost_allocation_runs WHERE archived_at IS NULL ORDER BY period DESC,created_at DESC LIMIT ?`,Number(limit)||24); }
  getNetProfitability(period,currency='TRY',runId=null){
    const metrics=this._periodOrderMetrics(period,currency);
    const orders=metrics.map(o=>({id:o.id,counterpartyId:o.counterpartyId,number:o.number}));
    const orderItems=[]; for(const o of metrics){ const items=this.all(`SELECT product_id productId,description,quantity,sales_unit_minor salesUnitMinor,direct_unit_cost_minor directUnitCostMinor FROM order_items WHERE order_id=? AND archived_at IS NULL`,o.id); for(const x of items)orderItems.push({...x,orderId:o.id}); }
    const counterparties=this.all(`SELECT id,name FROM counterparties WHERE archived_at IS NULL`),products=this.all(`SELECT id,name FROM products WHERE archived_at IS NULL`);
    const run=runId?this.one(`SELECT * FROM cost_allocation_runs WHERE id=?`,runId):this.one(`SELECT * FROM cost_allocation_runs WHERE period=? AND currency=? AND status='posted' AND archived_at IS NULL ORDER BY created_at DESC LIMIT 1`,period,currency);
    const overheadAllocations=run?this.all(`SELECT order_id orderId,amount_minor amountMinor FROM cost_allocations WHERE run_id=? AND archived_at IS NULL`,run.id):[];
    return {period,currency,run, ...netProfitabilityAnalysis({orders,orderItems,counterparties,products,overheadAllocations})};
  }
  getCostCenterPeriodReport(period,currency='TRY'){
    const centers=this.all(`SELECT * FROM cost_centers WHERE archived_at IS NULL ORDER BY code,name`);
    const rows=centers.map(c=>{ const assigned=this.one(`SELECT COALESCE(SUM(a.amount_minor),0) n FROM expense_cost_center_allocations a JOIN expenses e ON e.id=a.expense_id WHERE a.cost_center_id=? AND a.archived_at IS NULL AND e.archived_at IS NULL AND e.status IN ('approved','paid') AND substr(e.expense_date,1,7)=? AND e.currency=?`,c.id,period,currency)?.n||0; return {...c,periodAssignedMinor:assigned}; });
    const totalExpenses=this.one(`SELECT COALESCE(SUM(total_minor),0) n FROM expenses WHERE archived_at IS NULL AND status IN ('approved','paid') AND substr(expense_date,1,7)=? AND currency=?`,period,currency)?.n||0;
    const assigned=rows.reduce((s,r)=>s+r.periodAssignedMinor,0); return {period,currency,totalExpensesMinor:totalExpenses,assignedMinor:assigned,unassignedMinor:Math.max(0,totalExpenses-assigned),rows};
  }
  auditRows(limit=200){ return this.all('SELECT * FROM audit_log ORDER BY created_at DESC, rowid DESC LIMIT ?',Number(limit)||200); }
  importLegacy(state,userId=null){
    const ts=nowIso(); let stats={counterparties:0,contacts:0,accounts:0,invoices:0,payments:0,employees:0,adjustments:0};
    return this.tx(()=>{
      const idMap=new Map();
      for(const c of state.cariler||[]){
        const cid='legacy_'+String(c.id||id('cp')); idMap.set(c.id,cid);
        if(this.one('SELECT 1 FROM counterparties WHERE id=?',cid)) continue;
        this.run(`INSERT INTO counterparties(id,name,type,tax_no,country,currency,payment_term_days,opening_minor,opening_date,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`,cid,c.unvan||c.name||'İsimsiz',c.tur==='tedarikci'?'vendor':c.tur==='her'?'both':'customer',c.vkn||null,c.ulke||null,c.paraBirimi||'TRY',Number(c.vade)||0,toMinor(c.acilis||0),c.acilisTarih||null,c.not||null,ts,ts); stats.counterparties++;
        const contacts=Array.isArray(c.yetkililer)?c.yetkililer:(c.yetkili?[{ad:c.yetkili,telefon:c.telefon,eposta:c.eposta}]:[]);
        for(const k of contacts){ this.run(`INSERT INTO contacts(id,counterparty_id,name,title,phone,email,is_primary,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)`,id('ct'),cid,k.ad||k.name||'Yetkili',k.gorev||k.title||null,k.telefon||k.phone||null,k.eposta||k.email||null,1,ts,ts); stats.contacts++; }
      }
      for(const h of state.hesaplar||[]){ const hid='legacy_'+String(h.id||id('acc')); if(this.one('SELECT 1 FROM accounts WHERE id=?',hid))continue; this.run(`INSERT INTO accounts(id,name,type,currency,opening_minor,iban,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)`,hid,h.ad||'Hesap',h.tur==='kasa'?'cash':'bank',h.paraBirimi||'TRY',toMinor(h.acilis||0),h.iban||null,ts,ts); stats.accounts++; }
      for(const f of state.faturalar||[]){ const iid='legacy_'+String(f.id||id('inv')); if(this.one('SELECT 1 FROM invoices WHERE id=?',iid))continue; const cid=idMap.get(f.cariId)||('legacy_'+String(f.cariId)); this.run(`INSERT INTO invoices(id,counterparty_id,direction,number,invoice_date,due_date,currency,net_minor,tax_minor,total_minor,status,description,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,iid,cid,f.yon==='alis'?'purchase':'sales',f.no||null,f.tarih||ts.slice(0,10),f.vade||null,f.paraBirimi||'TRY',toMinor(f.matrah||0),toMinor(f.kdvTutar||0),toMinor(f.toplam||0),'open',f.aciklama||null,ts,ts); stats.invoices++; }
      for(const k of state.kasaHareketleri||[]){ const pid='legacy_'+String(k.id||id('pay')); if(this.one('SELECT 1 FROM payments WHERE id=?',pid))continue; const cid=k.cariId?(idMap.get(k.cariId)||('legacy_'+String(k.cariId))):null; const acc=k.hesapId?'legacy_'+String(k.hesapId):null; this.run(`INSERT INTO payments(id,counterparty_id,account_id,direction,payment_date,currency,amount_minor,category,description,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`,pid,cid,acc,k.yon==='giris'?'in':'out',k.tarih||ts.slice(0,10),k.paraBirimi||'TRY',toMinor(k.tutar||0),k.kategori||null,k.aciklama||null,ts,ts); stats.payments++; if(k.faturaId){ const iid='legacy_'+String(k.faturaId); if(this.one('SELECT 1 FROM invoices WHERE id=?',iid)) this.run(`INSERT INTO payment_allocations(id,payment_id,invoice_id,amount_minor,created_at) VALUES(?,?,?,?,?)`,id('al'),pid,iid,toMinor(k.tutar||0),ts); } }
      for(const p of state.personel||[]){ const eid='legacy_'+String(p.id||id('emp')); if(this.one('SELECT 1 FROM employees WHERE id=?',eid))continue; this.run(`INSERT INTO employees(id,name,pay_cycle,real_salary_minor,bank_sgk_minor,weekly_wage_minor,insured,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)`,eid,p.ad||p.name||'İsimsiz',p.odemeTipi==='haftalik'?'weekly':'monthly',toMinor(p.gercekMaas??p.taban??0),toMinor(p.sgkMaas??p.sgkBanka??0),toMinor(p.haftalikUcret??0),p.sigorta?1:0,p.durum==='pasif'?'inactive':'active',ts,ts); stats.employees++; }
      for(const h of state.hareketler||[]){ if(!h.personelId)continue; const typ=h.tip==='avans'?'advance':h.tip==='kesinti'?'deduction':h.tip==='mesai'?'overtime':'extra'; const period=h.ay||h.mahsupAy||(h.tarih||'').slice(0,7); if(!period)continue; const eid='legacy_'+String(h.personelId); if(!this.one('SELECT 1 FROM employees WHERE id=?',eid))continue; this.run(`INSERT INTO personnel_adjustments(id,employee_id,period,type,hours,rate_minor,amount_minor,reason,event_date,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)`,id('adj'),eid,period,typ,h.saat??null,h.saatUcreti?toMinor(h.saatUcreti):null,toMinor(h.tutar||0),h.aciklama||h.not||null,h.tarih||null,ts); stats.adjustments++; }
      this.audit({userId,action:'import',entityType:'legacy_state',entityId:'legacy',after:stats}); return stats;
    });
  }
}
