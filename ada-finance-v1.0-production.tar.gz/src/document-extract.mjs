const clean=s=>String(s??'').replace(/\r/g,'').trim();
const trNum=s=>{let x=String(s??'').replace(/[^0-9,.-]/g,''); if(!x)return 0; if(x.includes(',')&&x.includes('.')) x=x.lastIndexOf(',')>x.lastIndexOf('.')?x.replace(/\./g,'').replace(',','.'):x.replace(/,/g,''); else if(x.includes(','))x=x.replace(',','.'); return Number(x)||0;};
const minor=s=>Math.round(trNum(s)*100);
const isoDate=s=>{const m=String(s||'').match(/(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})/); return m?`${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`:null;};
export function extractExpenseProposal(text,{sourceName='belge'}={}){
  const raw=clean(text), lines=raw.split('\n').map(x=>x.trim()).filter(Boolean);
  const date=isoDate(raw);
  const vkn=(raw.match(/(?:VKN|VERG[Iİ]\s*NO|V\.D\.?\s*NO)\s*[:#-]?\s*(\d{10,11})/i)||[])[1]||null;
  const totalMatches=[...raw.matchAll(/(?:GENEL\s*TOPLAM|ÖDENECEK|TOPLAM|TOTAL)\s*[:₺TL ]*([\d.]+,?\d{0,2})/gi)];
  const taxMatches=[...raw.matchAll(/(?:KDV|VAT)\s*(?:TOPLAMI)?\s*[:₺TL ]*([\d.]+,?\d{0,2})/gi)];
  const totalMinor=totalMatches.length?minor(totalMatches.at(-1)[1]):0;
  const taxMinor=taxMatches.length?minor(taxMatches.at(-1)[1]):0;
  const vendor=(lines.find(l=>l.length>2&&!/fatura|fiş|fis|tarih|vkn|vergi|toplam|kdv/i.test(l))||sourceName).slice(0,120);
  let confidence=0; if(date)confidence+=.2;if(totalMinor)confidence+=.45;if(vendor)confidence+=.15;if(vkn)confidence+=.1;if(taxMinor)confidence+=.1;
  return {vendor,date,totalMinor,taxMinor,netMinor:Math.max(0,totalMinor-taxMinor),taxNo:vkn,currency:'TRY',category:'Genel gider',confidence:Math.min(1,confidence),rawText:raw};
}

export function parseBankStatementText(text,{currency='TRY'}={}){
  const lines=clean(text).split('\n').map(x=>x.replace(/\s+/g,' ').trim()).filter(Boolean); const out=[];
  for(const line of lines){
    const dm=line.match(/(\d{1,2}[.\/-]\d{1,2}[.\/-]\d{4})/); if(!dm)continue;
    const nums=[...line.matchAll(/[-+]?\d{1,3}(?:\.\d{3})*(?:,\d{2})|[-+]?\d+(?:,\d{2})/g)].map(m=>({raw:m[0],idx:m.index}));
    if(!nums.length)continue; const amt=nums.at(-1); const val=trNum(amt.raw); if(!val)continue;
    const desc=line.slice((dm.index||0)+dm[0].length,amt.idx).trim();
    out.push({rowNo:out.length+1,txnDate:isoDate(dm[1]),description:desc,reference:'',direction:val<0?'out':'in',amountMinor:Math.round(Math.abs(val)*100),currency});
  }
  return out;
}
