const DAY = 86400000;

export function roundMinor(n) {
  return Math.round(Number(n) || 0);
}

export function invoiceAllocatedMinor(invoiceId, allocations = []) {
  return allocations
    .filter(a => a.invoiceId === invoiceId && !a.archivedAt)
    .reduce((sum, a) => sum + roundMinor(a.amountMinor), 0);
}

export function invoiceRemainingMinor(invoice, allocations = []) {
  return roundMinor(invoice.totalMinor - invoiceAllocatedMinor(invoice.id, allocations));
}

export function invoiceComputedStatus(invoice, allocations = [], today = new Date().toISOString().slice(0, 10)) {
  if (invoice.archivedAt) return 'archived';
  if (invoice.status === 'cancelled') return 'cancelled';
  const remaining = invoiceRemainingMinor(invoice, allocations);
  if (remaining <= 0) return 'paid';
  if (invoice.dueDate && invoice.dueDate < today) return 'overdue';
  if (remaining < invoice.totalMinor) return 'partial';
  return 'open';
}

export function daysLate(dueDate, paidDate = null, today = new Date().toISOString().slice(0, 10)) {
  if (!dueDate) return 0;
  const end = new Date((paidDate || today) + 'T00:00:00Z');
  const due = new Date(dueDate + 'T00:00:00Z');
  return Math.max(0, Math.floor((end - due) / DAY));
}

export function payrollCashNet({realSalaryMinor, bankSgkMinor = 0, overtimeMinor = 0, advanceMinor = 0, deductionMinor = 0}) {
  return roundMinor(realSalaryMinor - bankSgkMinor + overtimeMinor - advanceMinor - deductionMinor);
}

export function payrollBreakdown(input) {
  const netCash = payrollCashNet(input);
  return {
    bankMinor: roundMinor(input.bankSgkMinor),
    cashMinor: Math.max(0, netCash),
    employeeDebtMinor: Math.max(0, -netCash),
    netMinor: netCash,
  };
}

export function cashFlowProjection({openingByCurrency = {}, receivables = [], payables = [], personnel = [], fromDate, horizons = [7, 30, 60, 90]}) {
  const start = new Date(fromDate + 'T00:00:00Z');
  const result = {};
  for (const horizon of horizons) {
    const end = new Date(start.getTime() + horizon * DAY);
    const totals = {};
    const add = (ccy, amount) => { totals[ccy] = roundMinor((totals[ccy] || 0) + amount); };
    for (const [ccy, amount] of Object.entries(openingByCurrency)) add(ccy, amount);
    for (const r of receivables) {
      if (r.archivedAt || r.remainingMinor <= 0) continue;
      const d = new Date((r.expectedPaymentDate || r.dueDate) + 'T00:00:00Z');
      if (d >= start && d <= end) add(r.currency, r.remainingMinor);
    }
    for (const p of payables) {
      if (p.archivedAt || p.remainingMinor <= 0) continue;
      const d = new Date(p.dueDate + 'T00:00:00Z');
      if (d >= start && d <= end) add(p.currency, -p.remainingMinor);
    }
    for (const x of personnel) {
      if (x.archivedAt || x.status === 'paid') continue;
      const d = new Date(x.dueDate + 'T00:00:00Z');
      if (d >= start && d <= end) add(x.currency || 'TRY', -(roundMinor(x.bankAmountMinor) + roundMinor(x.cashAmountMinor)));
    }
    result[horizon] = totals;
  }
  return result;
}

export function agingBuckets(invoices, allocations = [], today = new Date().toISOString().slice(0, 10)) {
  const out = {'not_due':0,'1_30':0,'31_60':0,'61_90':0,'90_plus':0};
  for (const inv of invoices) {
    if (inv.direction !== 'sales' || inv.archivedAt || inv.status === 'cancelled') continue;
    const remaining = invoiceRemainingMinor(inv, allocations);
    if (remaining <= 0) continue;
    const late = daysLate(inv.dueDate, null, today);
    if (!inv.dueDate || inv.dueDate >= today) out.not_due += remaining;
    else if (late <= 30) out['1_30'] += remaining;
    else if (late <= 60) out['31_60'] += remaining;
    else if (late <= 90) out['61_90'] += remaining;
    else out['90_plus'] += remaining;
  }
  return Object.fromEntries(Object.entries(out).map(([k,v]) => [k, roundMinor(v)]));
}

export function receivablesSummary(invoices = [], allocations = [], today = new Date().toISOString().slice(0,10)) {
  const rows = invoices
    .filter(i => i.direction === 'sales' && !i.archivedAt && i.status !== 'cancelled')
    .map(i => {
      const remainingMinor = invoiceRemainingMinor(i, allocations);
      const status = invoiceComputedStatus(i, allocations, today);
      return {...i, remainingMinor, computedStatus: status, daysLate: status === 'overdue' ? daysLate(i.dueDate, null, today) : 0};
    })
    .filter(i => i.remainingMinor > 0);
  const totals = rows.reduce((a,r)=>{
    a.totalMinor += r.remainingMinor;
    if (r.computedStatus === 'overdue') a.overdueMinor += r.remainingMinor;
    else a.notDueMinor += r.remainingMinor;
    return a;
  }, {totalMinor:0, overdueMinor:0, notDueMinor:0});
  return {...totals, rows};
}

export function payablesCalendar(payables = [], today = new Date().toISOString().slice(0,10), days = 30) {
  const start = new Date(today + 'T00:00:00Z');
  const end = new Date(start.getTime() + days * DAY);
  return payables
    .filter(p => !p.archivedAt && p.remainingMinor > 0)
    .map(p => {
      const d = new Date(p.dueDate + 'T00:00:00Z');
      const late = p.dueDate < today ? Math.max(0, Math.floor((start-d)/DAY)) : 0;
      return {...p, daysLate:late, isOverdue:p.dueDate < today};
    })
    .filter(p => p.isOverdue || new Date(p.dueDate+'T00:00:00Z') <= end)
    .sort((a,b)=>a.dueDate.localeCompare(b.dueDate));
}

export function customer360({company, invoices = [], allocations = [], orders = [], contacts = [], today}) {
  const companyInvoices = invoices.filter(i => i.companyId === company.id && !i.archivedAt);
  const companyAllocations = allocations.filter(a => companyInvoices.some(i => i.id === a.invoiceId) && !a.archivedAt);
  const salesInvoices = companyInvoices.filter(i => i.direction === 'sales');
  const totalSalesMinor = salesInvoices.reduce((s,i)=>s+roundMinor(i.totalMinor),0);
  const openReceivableMinor = salesInvoices.reduce((s,i)=>s+Math.max(0,invoiceRemainingMinor(i,companyAllocations)),0);
  const overdueMinor = salesInvoices.reduce((s,i)=>s+(invoiceComputedStatus(i,companyAllocations,today)==='overdue'?Math.max(0,invoiceRemainingMinor(i,companyAllocations)):0),0);
  return {
    company,
    contacts: contacts.filter(c=>c.companyId===company.id && !c.archivedAt),
    orders: orders.filter(o=>o.companyId===company.id && !o.archivedAt),
    invoices: companyInvoices,
    totalSalesMinor,
    openReceivableMinor,
    overdueMinor,
    opportunityCompanyId: company.opportunityCompanyId || null,
  };
}

export function dashboardSummary({accounts = [], transactions = [], invoices = [], allocations = [], payables = [], personnelObligations = [], today}) {
  const balances = {};
  for (const a of accounts.filter(x=>!x.archivedAt)) balances[a.currency] = roundMinor((balances[a.currency]||0) + roundMinor(a.openingMinor));
  for (const t of transactions.filter(x=>!x.archivedAt)) balances[t.currency] = roundMinor((balances[t.currency]||0) + (t.direction==='in'?roundMinor(t.amountMinor):-roundMinor(t.amountMinor)));
  const receivables = receivablesSummary(invoices, allocations, today);
  const due30 = payablesCalendar(payables, today, 30);
  const payable30Minor = due30.reduce((s,p)=>s+roundMinor(p.remainingMinor),0);
  const personnelOpenMinor = personnelObligations.filter(p=>!p.archivedAt && p.status!=='paid').reduce((s,p)=>s+roundMinor(p.bankAmountMinor)+roundMinor(p.cashAmountMinor),0);
  return {balances, receivables, payable30Minor, personnelOpenMinor, aging:agingBuckets(invoices, allocations, today)};
}

export function buildPersonnelObligation({id, employeeId, employeeName, dueDate, currency='TRY', realSalaryMinor, bankSgkMinor=0, overtimeMinor=0, advanceMinor=0, deductionMinor=0}) {
  const p = payrollBreakdown({realSalaryMinor, bankSgkMinor, overtimeMinor, advanceMinor, deductionMinor});
  return {id, employeeId, employeeName, dueDate, currency, bankAmountMinor:p.bankMinor, cashAmountMinor:p.cashMinor, employeeDebtMinor:p.employeeDebtMinor, netMinor:p.netMinor, status:'open'};
}

/* ---------- Package 7: management analytics ---------- */
export function monthKey(date) { return String(date || '').slice(0, 7); }

export function monthRange(asOf, months = 12) {
  const end = new Date(String(asOf).slice(0, 7) + '-01T00:00:00Z');
  const out = [];
  for (let i = Math.max(1, Number(months) || 1) - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth() - i, 1));
    out.push(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`);
  }
  return out;
}

export function managementMonthlySeries({invoices = [], payments = [], expenses = [], asOf, months = 12, currency = 'TRY'}) {
  const keys = monthRange(asOf, months);
  const map = new Map(keys.map(k => [k, {month:k,revenueMinor:0,purchaseInvoiceMinor:0,collectionsMinor:0,cashOutMinor:0,expenseMinor:0,netOperatingCashMinor:0}]));
  for (const inv of invoices) {
    if (inv.archivedAt || inv.status === 'cancelled' || inv.currency !== currency) continue;
    const row = map.get(monthKey(inv.invoiceDate)); if (!row) continue;
    if (inv.direction === 'sales') row.revenueMinor += roundMinor(inv.totalMinor);
    else if (inv.direction === 'purchase') row.purchaseInvoiceMinor += roundMinor(inv.totalMinor);
  }
  for (const p of payments) {
    if (p.archivedAt || p.currency !== currency) continue;
    const row = map.get(monthKey(p.paymentDate)); if (!row) continue;
    if (p.direction === 'in') row.collectionsMinor += roundMinor(p.amountMinor);
    else row.cashOutMinor += roundMinor(p.amountMinor);
  }
  for (const e of expenses) {
    if (e.archivedAt || !['approved','paid'].includes(e.status) || e.currency !== currency) continue;
    const row = map.get(monthKey(e.expenseDate)); if (row) row.expenseMinor += roundMinor(e.totalMinor);
  }
  return [...map.values()].map(r => ({...r, netOperatingCashMinor:roundMinor(r.collectionsMinor-r.cashOutMinor)}));
}

export function expenseBreakdown(expenses = [], {fromDate, toDate, currency='TRY'} = {}) {
  const byCategory = new Map(), byDepartment = new Map(); let totalMinor=0;
  for (const e of expenses) {
    if (e.archivedAt || !['approved','paid'].includes(e.status) || e.currency !== currency) continue;
    if (fromDate && e.expenseDate < fromDate) continue; if (toDate && e.expenseDate > toDate) continue;
    const amount=roundMinor(e.totalMinor); totalMinor+=amount;
    const cat=e.category||'Diğer'; byCategory.set(cat,(byCategory.get(cat)||0)+amount);
    const dep=e.department||'Atanmamış'; byDepartment.set(dep,(byDepartment.get(dep)||0)+amount);
  }
  const rows=m=>[...m.entries()].map(([name,amountMinor])=>({name,amountMinor:roundMinor(amountMinor),share:totalMinor?amountMinor/totalMinor:0})).sort((a,b)=>b.amountMinor-a.amountMinor);
  return {totalMinor:roundMinor(totalMinor),byCategory:rows(byCategory),byDepartment:rows(byDepartment)};
}

export function customerPerformance({counterparties = [], invoices = [], allocations = [], payments = [], asOf, months = 12, currency='TRY'}) {
  const keys=monthRange(asOf,months), from=`${keys[0]}-01`, to=String(asOf);
  const paymentById=new Map(payments.map(p=>[p.id,p]));
  const rows=[];
  for (const c of counterparties.filter(x=>!x.archivedAt && ['customer','both'].includes(x.type))) {
    const invs=invoices.filter(i=>i.counterpartyId===c.id && i.direction==='sales' && !i.archivedAt && i.status!=='cancelled' && i.currency===currency && i.invoiceDate>=from && i.invoiceDate<=to);
    if (!invs.length) continue;
    const ids=new Set(invs.map(i=>i.id));
    const salesMinor=invs.reduce((s,i)=>s+roundMinor(i.totalMinor),0);
    const alloc=allocations.filter(a=>ids.has(a.invoiceId)&&!a.archivedAt);
    const collectedMinor=alloc.reduce((s,a)=>s+roundMinor(a.amountMinor),0);
    const openMinor=invs.reduce((s,i)=>s+Math.max(0,invoiceRemainingMinor(i,alloc)),0);
    const overdueMinor=invs.reduce((s,i)=>s+(invoiceComputedStatus(i,alloc,to)==='overdue'?Math.max(0,invoiceRemainingMinor(i,alloc)):0),0);
    const paidLags=[];
    for(const a of alloc){const inv=invs.find(i=>i.id===a.invoiceId), pay=paymentById.get(a.paymentId);if(inv?.dueDate&&pay?.paymentDate) paidLags.push(Math.floor((new Date(pay.paymentDate+'T00:00:00Z')-new Date(inv.dueDate+'T00:00:00Z'))/DAY));}
    rows.push({counterpartyId:c.id,name:c.name,salesMinor,collectedMinor,openMinor,overdueMinor,collectionRate:salesMinor?collectedMinor/salesMinor:0,avgDueVarianceDays:paidLags.length?paidLags.reduce((a,b)=>a+b,0)/paidLags.length:null,invoiceCount:invs.length});
  }
  rows.sort((a,b)=>b.salesMinor-a.salesMinor);
  const totalSalesMinor=rows.reduce((s,r)=>s+r.salesMinor,0);
  return rows.map(r=>({...r,salesShare:totalSalesMinor?r.salesMinor/totalSalesMinor:0}));
}

export function concentrationRisk(customerRows = []) {
  const total=customerRows.reduce((s,r)=>s+roundMinor(r.salesMinor),0);
  const shares=customerRows.map(r=>({name:r.name,share:total?r.salesMinor/total:0,salesMinor:r.salesMinor})).sort((a,b)=>b.share-a.share);
  const hhi=shares.reduce((s,r)=>s+r.share*r.share,0)*10000;
  return {totalSalesMinor:total,top1Share:shares[0]?.share||0,top3Share:shares.slice(0,3).reduce((s,r)=>s+r.share,0),hhi:Math.round(hhi),topCustomers:shares.slice(0,5)};
}

export function accountBalanceTrend({accounts = [], payments = [], asOf, months = 12, currency='TRY'}) {
  const keys=monthRange(asOf,months), first=`${keys[0]}-01`;
  let balance=accounts.filter(a=>!a.archivedAt&&a.currency===currency).reduce((s,a)=>s+roundMinor(a.openingMinor),0);
  for(const p of payments.filter(p=>!p.archivedAt&&p.currency===currency&&p.paymentDate<first)) balance += p.direction==='in'?roundMinor(p.amountMinor):-roundMinor(p.amountMinor);
  return keys.map(k=>{const end=`${k}-31`;for(const p of payments.filter(p=>!p.archivedAt&&p.currency===currency&&monthKey(p.paymentDate)===k)) balance += p.direction==='in'?roundMinor(p.amountMinor):-roundMinor(p.amountMinor);return {month:k,balanceMinor:roundMinor(balance)};});
}

/* ---------- Package 8: budget, profitability, 13-week cash ---------- */
export function budgetVsActual({budgetLines = [], monthlyActual = []} = {}) {
  const actual = new Map(monthlyActual.map(r=>[r.month,r]));
  const rows = budgetLines.filter(x=>!x.archivedAt).map(b=>{
    const a=actual.get(b.month)||{};
    const revenueActualMinor=roundMinor(a.revenueMinor||0), expenseActualMinor=roundMinor(a.expenseMinor||0), cashInActualMinor=roundMinor(a.collectionsMinor||0), cashOutActualMinor=roundMinor(a.cashOutMinor||0);
    return {
      month:b.month,
      revenueBudgetMinor:roundMinor(b.revenueBudgetMinor), revenueActualMinor, revenueVarianceMinor:roundMinor(revenueActualMinor-b.revenueBudgetMinor),
      expenseBudgetMinor:roundMinor(b.expenseBudgetMinor), expenseActualMinor, expenseVarianceMinor:roundMinor(expenseActualMinor-b.expenseBudgetMinor),
      cashInBudgetMinor:roundMinor(b.cashInBudgetMinor), cashInActualMinor, cashInVarianceMinor:roundMinor(cashInActualMinor-b.cashInBudgetMinor),
      cashOutBudgetMinor:roundMinor(b.cashOutBudgetMinor), cashOutActualMinor, cashOutVarianceMinor:roundMinor(cashOutActualMinor-b.cashOutBudgetMinor),
    };
  }).sort((a,b)=>a.month.localeCompare(b.month));
  const totals=rows.reduce((t,r)=>{for(const k of ['revenueBudgetMinor','revenueActualMinor','revenueVarianceMinor','expenseBudgetMinor','expenseActualMinor','expenseVarianceMinor','cashInBudgetMinor','cashInActualMinor','cashInVarianceMinor','cashOutBudgetMinor','cashOutActualMinor','cashOutVarianceMinor'])t[k]+=r[k];return t;},Object.fromEntries(['revenueBudgetMinor','revenueActualMinor','revenueVarianceMinor','expenseBudgetMinor','expenseActualMinor','expenseVarianceMinor','cashInBudgetMinor','cashInActualMinor','cashInVarianceMinor','cashOutBudgetMinor','cashOutActualMinor','cashOutVarianceMinor'].map(k=>[k,0])));
  return {rows,totals};
}

export function profitabilityAnalysis({orders = [], orderItems = [], counterparties = [], products = []} = {}) {
  const cp=new Map(counterparties.map(x=>[x.id,x]));
  const prod=new Map(products.map(x=>[x.id,x]));
  const orderRows=orders.filter(o=>!o.archivedAt).map(o=>{
    const items=orderItems.filter(i=>i.orderId===o.id&&!i.archivedAt);
    const revenueMinor=items.reduce((s,i)=>s+roundMinor((Number(i.quantity)||0)*roundMinor(i.salesUnitMinor)),0);
    const directCostMinor=items.reduce((s,i)=>s+roundMinor((Number(i.quantity)||0)*roundMinor(i.directUnitCostMinor)),0);
    const grossProfitMinor=roundMinor(revenueMinor-directCostMinor);
    return {orderId:o.id,orderNo:o.number||o.orderNo||'—',counterpartyId:o.counterpartyId,customerName:cp.get(o.counterpartyId)?.name||'—',revenueMinor,directCostMinor,grossProfitMinor,grossMargin:revenueMinor?grossProfitMinor/revenueMinor:0};
  });
  const aggregate=(keyFn,nameFn)=>{
    const m=new Map();
    for(const o of orders.filter(x=>!x.archivedAt)){
      for(const i of orderItems.filter(x=>x.orderId===o.id&&!x.archivedAt)){
        const key=keyFn(o,i); if(!key) continue; const cur=m.get(key)||{id:key,name:nameFn(o,i),revenueMinor:0,directCostMinor:0};
        cur.revenueMinor+=roundMinor((Number(i.quantity)||0)*roundMinor(i.salesUnitMinor)); cur.directCostMinor+=roundMinor((Number(i.quantity)||0)*roundMinor(i.directUnitCostMinor)); m.set(key,cur);
      }
    }
    return [...m.values()].map(r=>({...r,grossProfitMinor:roundMinor(r.revenueMinor-r.directCostMinor),grossMargin:r.revenueMinor?(r.revenueMinor-r.directCostMinor)/r.revenueMinor:0})).sort((a,b)=>b.grossProfitMinor-a.grossProfitMinor);
  };
  const byCustomer=aggregate(o=>o.counterpartyId,o=>cp.get(o.counterpartyId)?.name||'—');
  const byProduct=aggregate((o,i)=>i.productId,(o,i)=>prod.get(i.productId)?.name||i.description||'—');
  const totals=orderRows.reduce((t,r)=>({revenueMinor:t.revenueMinor+r.revenueMinor,directCostMinor:t.directCostMinor+r.directCostMinor,grossProfitMinor:t.grossProfitMinor+r.grossProfitMinor}),{revenueMinor:0,directCostMinor:0,grossProfitMinor:0});
  return {orders:orderRows,byCustomer,byProduct,totals:{...totals,grossMargin:totals.revenueMinor?totals.grossProfitMinor/totals.revenueMinor:0}};
}

export function thirteenWeekCashFlow({openingMinor=0,receivables=[],payables=[],personnel=[],fromDate,scenarios={bad:0.50,base:0.80,good:1.00}}={}) {
  const start=new Date(String(fromDate)+'T00:00:00Z');
  const weeks=Array.from({length:13},(_,i)=>{const s=new Date(start.getTime()+i*7*DAY),e=new Date(s.getTime()+6*DAY);return {index:i+1,start:s.toISOString().slice(0,10),end:e.toISOString().slice(0,10),receivableMinor:0,outflowMinor:0};});
  const weekIndex=(date)=>{if(!date)return -1;const d=new Date(String(date)+'T00:00:00Z');return Math.floor((d-start)/(7*DAY));};
  for(const r of receivables){const idx=weekIndex(r.expectedPaymentDate||r.dueDate);if(idx>=0&&idx<13)weeks[idx].receivableMinor+=roundMinor(r.remainingMinor);}
  for(const p of payables){const idx=weekIndex(p.dueDate);if(idx>=0&&idx<13)weeks[idx].outflowMinor+=roundMinor(p.remainingMinor);}
  for(const p of personnel){const idx=weekIndex(p.dueDate);if(idx>=0&&idx<13)weeks[idx].outflowMinor+=roundMinor(p.bankAmountMinor)+roundMinor(p.cashAmountMinor);}
  const build=(rate)=>{let balance=roundMinor(openingMinor);return weeks.map(w=>{const inflow=roundMinor(w.receivableMinor*rate),outflow=roundMinor(w.outflowMinor);balance=roundMinor(balance+inflow-outflow);return {...w,inflowMinor:inflow,outflowMinor:outflow,endingMinor:balance};});};
  return {assumptions:scenarios,bad:build(scenarios.bad),base:build(scenarios.base),good:build(scenarios.good)};
}

export function allocateMinorExact(totalMinor, rows, basis='revenue') {
  const total = roundMinor(totalMinor);
  if (!rows?.length || total === 0) return { allocations: [], unallocatedMinor: total };
  const weighted = rows.map((r,idx)=>({
    ...r,
    _idx: idx,
    _weight: basis==='direct_cost' ? Math.max(0,Number(r.directCostMinor)||0)
      : basis==='equal' ? 1 : Math.max(0,Number(r.revenueMinor)||0)
  }));
  let sum = weighted.reduce((s,r)=>s+r._weight,0);
  if(sum<=0){ weighted.forEach(r=>r._weight=1); sum=weighted.length; }
  let used=0;
  const out=weighted.map((r,i)=>{
    const amount=i===weighted.length-1 ? total-used : Math.floor(total*r._weight/sum);
    used+=amount;
    return {orderId:r.orderId,amountMinor:amount,basis};
  });
  return {allocations:out,unallocatedMinor:roundMinor(total-used)};
}

export function netProfitabilityAnalysis({orders=[],orderItems=[],counterparties=[],products=[],overheadAllocations=[]}={}) {
  const gross=profitabilityAnalysis({orders,orderItems,counterparties,products});
  const byOrderAlloc=new Map();
  for(const a of overheadAllocations||[]){ if(a.orderId) byOrderAlloc.set(a.orderId,(byOrderAlloc.get(a.orderId)||0)+roundMinor(a.amountMinor)); }
  const orderRows=gross.orders.map(r=>{
    const overheadMinor=byOrderAlloc.get(r.orderId)||0;
    const netContributionMinor=roundMinor(r.grossProfitMinor-overheadMinor);
    return {...r,overheadMinor,netContributionMinor,netMargin:r.revenueMinor?netContributionMinor/r.revenueMinor:0};
  });
  const cm=new Map();
  for(const r of orderRows){
    const cur=cm.get(r.counterpartyId)||{id:r.counterpartyId,name:counterparties.find(c=>c.id===r.counterpartyId)?.name||r.counterpartyId,revenueMinor:0,directCostMinor:0,grossProfitMinor:0,overheadMinor:0,netContributionMinor:0};
    for(const k of ['revenueMinor','directCostMinor','grossProfitMinor','overheadMinor','netContributionMinor'])cur[k]+=Number(r[k]||0);
    cm.set(r.counterpartyId,cur);
  }
  const byCustomer=[...cm.values()].map(r=>({...r,netMargin:r.revenueMinor?r.netContributionMinor/r.revenueMinor:0})).sort((a,b)=>b.netContributionMinor-a.netContributionMinor);
  const totalOverhead=orderRows.reduce((s,r)=>s+r.overheadMinor,0);
  const netContribution=orderRows.reduce((s,r)=>s+r.netContributionMinor,0);
  return {...gross,orders:orderRows,byCustomer,totals:{...gross.totals,overheadMinor:totalOverhead,netContributionMinor:netContribution,netMargin:gross.totals.revenueMinor?netContribution/gross.totals.revenueMinor:0}};
}
