import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const textMimes=new Set(['text/plain','text/csv','text/tab-separated-values','application/json','application/xml','text/xml']);
export function extractionCapability({mimeType='',filePath=''}){
  const ext=path.extname(filePath).toLowerCase();
  if(textMimes.has(mimeType)||['.txt','.csv','.tsv','.json','.xml'].includes(ext)) return {engine:'native_text',available:true};
  if(mimeType==='application/pdf'||ext==='.pdf') return {engine:'pdftotext',available:commandExists('pdftotext')};
  if(/^image\//.test(mimeType)||['.png','.jpg','.jpeg','.webp','.tif','.tiff'].includes(ext)) return {engine:'tesseract',available:commandExists('tesseract')};
  return {engine:'unsupported',available:false};
}
function commandExists(cmd){const r=spawnSync('sh',['-lc',`command -v ${cmd}`],{encoding:'utf8'});return r.status===0;}
export function extractFileText({filePath,mimeType=''}){
  const c=extractionCapability({mimeType,filePath});
  if(c.engine==='native_text') return {status:'completed',engine:c.engine,text:fs.readFileSync(filePath,'utf8')};
  if(c.engine==='pdftotext'&&c.available){const r=spawnSync('pdftotext',['-layout',filePath,'-'],{encoding:'utf8',maxBuffer:8*1024*1024});if(r.status===0&&r.stdout.trim())return {status:'completed',engine:c.engine,text:r.stdout};return {status:'failed',engine:c.engine,text:'',error:(r.stderr||'PDF_TEXT_EXTRACTION_FAILED').trim()};}
  if(c.engine==='tesseract'&&c.available){const r=spawnSync('tesseract',[filePath,'stdout','-l','tur+eng'],{encoding:'utf8',maxBuffer:8*1024*1024});if(r.status===0&&r.stdout.trim())return {status:'completed',engine:c.engine,text:r.stdout};return {status:'needs_external_ocr',engine:c.engine,text:'',error:(r.stderr||'IMAGE_OCR_NEEDS_EXTERNAL_ENGINE').trim()};}
  if(c.engine==='pdftotext'||c.engine==='tesseract') return {status:'needs_external_ocr',engine:c.engine,text:'',error:'LOCAL_EXTRACTION_ENGINE_UNAVAILABLE'};
  return {status:'needs_external_ocr',engine:c.engine,text:'',error:'UNSUPPORTED_BINARY_FOR_LOCAL_EXTRACTION'};
}
