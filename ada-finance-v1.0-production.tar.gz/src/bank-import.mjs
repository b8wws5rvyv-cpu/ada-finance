const norm=s=>String(s??'').toLocaleLowerCase('tr-TR').replace(/[^a-z0-9çğıöşü\s]/gi,' ').replace(/\s+/g,' ').trim();
const trNumber=s=>{let x=String(s??'').trim().replace(/\s/g,''); if(!x)return 0; if(x.includes(',')&&x.includes('.')) x=x.lastIndexOf(',')>x.lastIndexOf('.')?x.replace(/\./g,'').replace(',','.'):x.replace(/,/g,''); else if(x.includes(',')) x=x.replace(',','.'); return Number(x)||0;};
const isoDate=s=>{const v=String(s??'').trim(); const m=v.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/); if(m)return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`; return /^\d{4}-\d{2}-\d{2}$/.test(v)?v:null;};
export function parseBankCsv(text,{delimiter=null,currency='TRY'}={}){
  const lines=String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean); if(!lines.length)return [];
  const d=delimiter || (lines[0].includes(';')?';':lines[0].includes('\t')?'\t':',');
  const cols=lines[0].split(d).map(norm);
  const idx=(...names)=>cols.findIndex(c=>names.some(n=>c.includes(n)));
  const di=idx('tarih','date'), ai=idx('tutar','amount'), ci=idx('açıklama','aciklama','description','işlem','islem'), ri=idx('referans','reference','ref'), deb=idx('borç','borc','debit','çıkış','cikis'), cre=idx('alacak','credit','giriş','giris');
  const dataStart=(di>=0&&(ai>=0||deb>=0||cre>=0))?1:0;
  return lines.slice(dataStart).map((line,j)=>{
    const c=line.split(d).map(x=>x.replace(/^"|"$/g,'').trim()); let amount=ai>=0?trNumber(c[ai]):0, direction=amount<0?'out':'in';
    if(deb>=0||cre>=0){const dv=deb>=0?trNumber(c[deb]):0, cv=cre>=0?trNumber(c[cre]):0; if(cv){amount=cv;direction='in';} else {amount=dv;direction='out';}}
    return {rowNo:j+1,txnDate:di>=0?isoDate(c[di]):null,description:ci>=0?c[ci]:'',reference:ri>=0?c[ri]:'',direction,amountMinor:Math.round(Math.abs(amount)*100),currency};
  }).filter(r=>r.amountMinor>0||r.description||r.txnDate);
}
export function suggestMatches(row,{counterparties=[],invoices=[]}={}){
  const hay=norm(`${row.description||''} ${row.reference||''}`); let bestCp=null,bestScore=0;
  for(const c of counterparties){const name=norm(c.name); if(!name)continue; let s=0; if(hay.includes(name))s=.86; else {const toks=name.split(' ').filter(x=>x.length>3); const hit=toks.filter(t=>hay.includes(t)).length; if(toks.length)s=Math.min(.72,(hit/toks.length)*.72);} if(s>bestScore){bestScore=s;bestCp=c;}}
  let bestInv=null,invScore=0;
  for(const i of invoices.filter(x=>!x.archived_at&&x.status!=='cancelled')){let s=0; if(i.number&&hay.includes(norm(i.number)))s=.96; if(row.amountMinor&&Number(i.remaining_minor??i.total_minor)===row.amountMinor)s=Math.max(s,.7); if(bestCp&&i.counterparty_id===bestCp.id)s+=.08; if(s>invScore){invScore=Math.min(1,s);bestInv=i;}}
  return {counterpartyId:bestCp?.id||null,invoiceId:bestInv?.id||null,confidence:Math.max(bestScore,invScore),reason:bestInv?'invoice_match':bestCp?'counterparty_match':'none'};
}
