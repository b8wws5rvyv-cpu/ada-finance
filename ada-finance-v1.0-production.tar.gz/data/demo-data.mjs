export const demoData = {
  companies:[
    {id:'c-aras',name:'Aras Kargo',type:'customer',currency:'TRY',opportunityCompanyId:'opp-aras'},
    {id:'c-kg',name:'Kolay Gelsin',type:'customer',currency:'TRY',opportunityCompanyId:'opp-kg'}
  ],
  contacts:[
    {id:'ct1',companyId:'c-aras',name:'Satın Alma Yetkilisi',role:'Procurement'},
    {id:'ct2',companyId:'c-kg',name:'Operasyon Yetkilisi',role:'Operations'}
  ],
  invoices:[
    {id:'i1',companyId:'c-aras',direction:'sales',number:'ADA-2026-091',totalMinor:42000000,currency:'TRY',invoiceDate:'2026-08-20',dueDate:'2026-09-05',status:'open'},
    {id:'i2',companyId:'c-kg',direction:'sales',number:'ADA-2026-102',totalMinor:31500000,currency:'TRY',invoiceDate:'2026-09-08',dueDate:'2026-09-30',status:'open'}
  ],
  allocations:[{id:'al1',invoiceId:'i1',amountMinor:12000000,paymentId:'pay1'}],
  payables:[
    {id:'p1',vendorName:'Kumaş Tedarikçisi',category:'Malzeme',remainingMinor:8500000,currency:'TRY',dueDate:'2026-09-18'},
    {id:'p2',vendorName:'SGK',category:'SGK',remainingMinor:15952000,currency:'TRY',dueDate:'2026-09-30'}
  ],
  accounts:[{id:'a1',name:'Merkez Banka',currency:'TRY',openingMinor:28000000},{id:'a2',name:'Merkez Kasa',currency:'TRY',openingMinor:7000000}],
  transactions:[],
  orders:[{id:'o1',companyId:'c-aras',number:'ORD-2026-41',status:'in_production',opportunityOrderId:'opp-order-41'}],
  personnelObligations:[]
};
